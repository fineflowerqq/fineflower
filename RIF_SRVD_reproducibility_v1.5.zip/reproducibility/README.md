# RIF / SRVD v1.5 — Reproducibility Package

This package contains the simulation scripts, result JSON files, and numerical
verification tools used for the appendices of *Relational Information Framework*
(RIF) v1.5 and *Structure Recursive Viability Dynamics* (SRVD) v1.5.

All scripts implement **synthetic-world numerical experiments**, not empirical
data studies. They are provided to reproduce the model computations,
pre-registered criteria, tabulated values, and figures in the books; they are
not direct validation of any real-world system.

## Related works

This package accompanies the following published records. For the two current
works the **concept DOI** is given, which always resolves to the latest
version (v1.5 at the time of writing); the two historical records are cited
by their version DOIs.

| Work | DOI |
|---|---|
| *Structure Recursive Viability Dynamics* (SRVD) v1.5, five-volume combined edition, Chinese and English | https://doi.org/10.5281/zenodo.20130775 (concept; v1.5: 10.5281/zenodo.24365889) |
| *Relational Information Framework* (RIF) v1.5, Chinese and English editions | https://doi.org/10.5281/zenodo.24365794 (concept; v1.5: 10.5281/zenodo.24365795) |
| *Structure Recursive Viability Dynamics* (SRVD), Monograph v1.0 (earlier version) | https://doi.org/10.5281/zenodo.21322552 |
| *SRVD Patch V1.1 Reading Guide* | https://doi.org/10.5281/zenodo.22027891 |

Package DOI (concept): **10.5281/zenodo.24349829** (v1.5: 10.5281/zenodo.24349831).
An OSF mirror will be listed here once it is created.

## Layout

```text
reproducibility/
  README.md
  LICENSE.md
  requirements.txt
  SHA256SUMS.txt
  batch_A/                 # simulation batch A
    00_batch_notes.md
    01_预注册协议.md                       # hash-locked Chinese original
    01_preregistration_protocol_EN.md     # English reference translation
    02_simulation_report.md
    03_v1.60_revision_notes.md
    sim/
    results/
    figure/
  batch_B/                 # simulation batch B
    00_directory_guide.md
    01_预注册协议_B.md                     # hash-locked Chinese original
    01_preregistration_protocol_B_EN.md   # English reference translation
    02_simulation_report_B.md
    03_v1.60_revision_notes.md
    04_figures_overview.md
    05_theoretical_risk_register.md
    sim/
    results/
    figures/
  m8_v1.60/                # M8 elasticity sweep
    sim/
      m8_elasticity.py
      fig_m8.py
      results_m8_elasticity.json
    figures/
  tools/
    verify_numbers.py
```

## Mapping to the books

- RIF Appendix C, Tables C-1–C-6: produced mainly by `batch_B`.
- SRVD Volume I, Appendix F, Tables F-1–F-5 and Figures F.1–F.3: produced mainly by `batch_A`.
- SRVD Volume I, Appendix F, Table F-7, Figure F.4, and main-text Figure I-8: `batch_B` and `m8_v1.60`.
- SRVD Volume I, Appendix G, table G-1–G-32: `tools/verify_numbers.py` automates the 24 cross-package checks G-9–G-32 by reading the result files of `batch_A`, `batch_B`, and `m8_v1.60`. The eight closed-form checks G-1–G-8 are computed inside `batch_A/sim/m1_math.py` and written to `batch_A/results/results_all.json`.

## Environment

Recorded development environment:

- Python 3.13.x
- numpy 2.5.4
- scipy 1.18.1
- matplotlib 3.11.2

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

## Reproduction steps

The commands below assume the current directory is the extracted package root
(the directory that contains `reproducibility/`).

Each block runs in a subshell, so the commands can be pasted in sequence from
the package root without changing the working directory:

```bash
(cd reproducibility/batch_A/sim && python run_all.py)
(cd reproducibility/batch_B/sim && python run_all.py)
(cd reproducibility/m8_v1.60/sim && python m8_elasticity.py)
```

Then run the cross-batch numerical verification:

```bash
(cd reproducibility && python tools/verify_numbers.py)
```

Expected outputs:

- `batch_A/results/results_all.json`
- `batch_B/results/SUMMARY.json` and the per-module JSON files
- `m8_v1.60/sim/results_m8_elasticity.json`
- `m8_v1.60/sim/results_verify.json`

## Verifying package integrity

`SHA256SUMS.txt` lists every file under the path prefix `reproducibility/`. Run the check from the directory that contains `reproducibility/` (not from inside it):

```bash
sha256sum -c reproducibility/SHA256SUMS.txt
```

On Windows PowerShell, the equivalent check is:

```powershell
Get-Content reproducibility\SHA256SUMS.txt | ForEach-Object {
  $h, $p = $_ -split '  ', 2
  if ((Get-FileHash $p -Algorithm SHA256).Hash -ne $h) { "MISMATCH $p" }
}
```

`batch_A/SHA256SUMS.txt` is a nested manifest for that batch only; it uses `./` paths and must be checked from inside `batch_A/`.

## Notes

1. With a fixed random seed, results should agree within the same environment and the same number of BLAS threads; bitwise agreement across environments is not guaranteed. Within one environment the full pipeline is deterministic, including the figures: PDF/SVG outputs are written without embedded timestamps (and the SVG element ids are normalized), so re-running does not invalidate `SHA256SUMS.txt`.
2. `batch_A/sim/run_all.py` requires `batch_A/results/prereg.sha256` on first run; this file is included in the package.
3. `batch_B/sim/run_all.py` writes `batch_B/results/prereg_B.sha256` on first run; if the file is already present it is verified, not overwritten.
4. `m8_elasticity.py` is deterministic and draws no random numbers.
5. Results produced by these synthetic-world experiments must not be read as measured data.
6. `m8_v1.60/sim/results_verify.json` is an output, not a pre-supplied input: `verify_numbers.py` regenerates and overwrites it on every run. Its absence from a distribution does not affect reproduction.
7. The package is distributed under three licenses; see `LICENSE.md` (code: MIT; result data: CC0 1.0; documents: CC BY 4.0).
8. The two pre-registration protocols are hash-locked to the original run records (`results/prereg.sha256`, `results/prereg_B.sha256`), so their Chinese originals are kept byte-for-byte; `01_preregistration_protocol_EN.md` and `01_preregistration_protocol_B_EN.md` are reference translations. Every other document is in English.
