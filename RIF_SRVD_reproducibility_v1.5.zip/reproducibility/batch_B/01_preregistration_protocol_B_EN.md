> Reference translation. The Chinese file `01_预注册协议_B.md` is the hash-locked original; in case of any discrepancy the Chinese original governs.

# Pre-registration Protocol B (v1.59 simulation patch B)

**LiangRuifeng** | 2026 | Companion to `batch_B/` (this directory, hereinafter "patch B")

> This file was written before any experimental code was run. The decision thresholds, grids, random seeds, refutation conditions, **and the author's prior predictions** are all locked here. `02_simulation_report_B.md` only fills in results and does not change criteria. If a criterion is changed after the run, the time of the change and the reason must be flagged separately in the report; silent re-judging is not permitted.

---

## 0　Division of labour between this protocol and `batch_A/`

The same v1.59 text, two independent simulation routes, **which neither cite nor modify each other**:

| | `batch_A/` (the other route) | **this directory (patch B)** |
| :-- | :-- | :-- |
| Main target layer | arithmetic layer and dynamical notation (closed-form solutions, bifurcation locations, reduced equivalence, gating rules) | **measurement layer and protocol layer** (how readings are taken, how boundaries are drawn, how verdicts are made, how depth is estimated) |
| Main objects | equations (5.1c)(5.1d)(5.13)(5.15)(5.19) of Volume I §5 | RIF Chapters 12–14, Volume I §5.1.2 / §5.6, Volume II §2.4 |
| Testing method | analytic solutions against numerical integration | **synthetic worlds + ground truth + null models + mutation tests** |
| Output | criterion tables, revision notes | criterion tables, revision notes, **figures** (v1.59 has 0 figures throughout) |

If the two reach different conclusions on the same proposition, that is not a contradictory verdict; it only means the proposition behaves differently in different model families — which is itself information to be written into v1.60.

**This patch touches no file of `batch_A/`.** All output of this round is written in `batch_B/`.

## 0.1　Evidence grading: how far this patch can speak

RIF itself makes a methodological commitment: the order "**measurement science first, hypothesis testing second**" cannot be reversed. This patch is the construction work for that sentence. Testability is split into four layers:

| Layer | Proposition type | Simulation can decide | Simulation cannot decide |
| :-: | :-- | :-- | :-- |
| **L1** | definitional identities, algebraic transformations (e.g. the uniformity of §12.1, the equivalence-band conversion of §13.3.3) | whether something is miscalculated | whether the definition is well chosen |
| **L2** | protocol **decidability**: running the procedure as written, can it separate different cases (§12.8's S1/F1–F4, the depth estimation of §14.6) | whether the procedure **has resolving power**, whether it **reaches the verdict the text promises** | whether real objects actually have that structure |
| **L3** | statistical **operating characteristics**: false-positive rate, power, estimation bias, required sample size (§13.3, §12.9.3, HR-4/6/7) | numerical values under a specified model family and sample size | the effect size of a real experiment |
| **L4** | extrapolation: whether nature / society is like this | **cannot at all** | — |

**Explicit declaration: this patch does not prove RIF or SRVD true, nor does it refute them.** It does four things only: (i) find numbers that are written elegantly but computed wrongly; (ii) find procedures that are written down but break when followed; (iii) find places where "following the text yields a conclusion, but the conclusion depends on unstated additional assumptions"; (iv) turn each such place into one replaceable sentence. Any appearance of "the theory has been verified" in these reports is a breach of this declaration.

## 0.2　Why this patch is not window dressing: the negative specimen of Appendix X in the 0.0 edition

At lines 2260–2274 of `00_0.0版/中文_卷Ⅰ_0.0.md` there is an "Appendix X: fivefold recursive numerical simulation", deleted in v1.59. Its three conclusions are:

1. "In **all** parameter configurations that lead to structural disintegration, $T_{\mathrm{pred}}$ collapse strictly precedes $E_{\mathrm{flow}}$ falling below threshold";
2. "Removing **any one** recursive loop **completely prevents** structural disintegration";
3. "Dormant state: $T_{\mathrm{pred}}$ collapses but $E_{\mathrm{flow}}$ stays below threshold".

These three **are designed so that they cannot fail**: the first is directly implied by $E_{\mathrm{flow}}=E_{\mathrm{survival}}+E_{\mathrm{causal}}+k_s/T_{\mathrm{pred}}$ in (5.5) ($T_{\mathrm{pred}}$ falls, so $E_{\mathrm{flow}}$ must rise) — an algebraic identity, not a discovery; the second treats "removing the feedback" and "preventing collapse" as two things, whereas in this system of equations removing the feedback leaves no amplifier, so the conclusion is written into the model; the third is the other side of the same parameter inequality. The parameters are a hand-picked set of numbers, with no null model, no repetitions, no power calibration.

**This patch makes "reconstruct Appendix X and prove it unfalsifiable" the first module, M0.** First show that this kind of simulation can deceive, then show why every criterion in this patch cannot deceive (each must be able to fail, and the failure must be attributable to a specific sentence of v1.59).

---

## 1　Module list

| ID | Module | Object examined (location) | Layer | Risk borne |
| :-: | :-- | :-- | :-: | :-- |
| **M0** | Counterexample reconstruction and power calibration | the Appendix X simulation (0.0 edition); every criterion of this protocol | — | whether the testing itself has resolving power |
| **M1** | Three numerical assertions of the rarity protocol | RIF §12.1, §12.2, §12.1.1 | L1 | whether the 1 bit baseline and the "order of magnitude" promise hold |
| **M2** | Decidability of the boundary identification procedure | all of RIF §12.8 (S1/S2, F1–F4) | L2 | whether "the boundary is decided by pairing" is a slogan |
| **M3** | Persistence resolution and coarsening order | RIF §12.9.3, HR-4, HR-6 | L2/L3 | whether "drop the smallest $\lvert\delta_r\rvert$ first" is true |
| **M4** | Operating characteristics of the two-step causal-reading test | RIF §13.3.3, §13.6 | L3 | what the 3 bit threshold actually screens out |
| **M5** | Decoding discrepancy as a predictor of error | HR-7 (end of §13) | L3 | whether "still predicts after controlling the shock magnitude" is identifiable |
| **M6** | Measurability of rule depth and compression gain | RIF §14.4 / §14.6; Volume II §2.4 / §6.2 | L2 | whether depth can be estimated from an object |
| **M7** | Terminal phase diagram and the "moving target" | Volume I §5.1.2 / §5.6 / §5.19; §5.2.3 | L1/L2 | the usability of the three-case classification and the bistable basin |

---

## 2　General conventions (all locked)

- **Random seeds**: master seed `20261103`; module $i$ uses `SeedSequence(20261103).spawn(8)[i]`, so that no stream is shared between modules.
- **Repetition counts**: Monte Carlo $n_{\mathrm{rep}}=2000$ (M1, M3, M4, M5); $n_{\mathrm{rep}}=500$ (M2, M6, where a single run is heavier); deterministic computations (M7 phase diagram, M0 reconstruction) use no repetitions.
- **Three verdict states**: each item receives exactly one of **pass** / **fail (text must change)** / **undecidable**. "Undecidable" must state what is missing (samples, compute, uncalibrated parameters); "consistent in trend" may not be substituted.
- **Interval conventions**: every point value is accompanied by a 95% interval; bootstrap uses BCa with 5000 resamples (10000 when sample size <200), and the results state whether it degenerated.
- **Numerical tolerances**: analytic vs. numerical comparisons use relative error $10^{-9}$ (closed form) / $10^{-6}$ (integration); statistics vs. theoretical values use 3 times the Monte Carlo standard error.
- **Prediction registration**: each module writes "the author's prior predictions" first. **If measurement contradicts the prediction, the report must state "the author's reading of v1.59 was wrong"; it may not merely report the result.**
- **Code and results**: one file per module under `sim/`; `results/` holds JSON (for verdicts) and CSV (for plotting); `figures/` holds PNG (300 dpi) with same-named PDF.
- **Pre-registration hash**: before its first run, `sim/run_all.py` computes the SHA-256 of this file and writes it to `results/prereg_B.sha256`; during runs the file is read-only.

---

## 3　M0　Counterexample reconstruction and power calibration

### M0.1　Appendix X reconstruction

Reconstructed from the parameters given in the 0.0 edition ($I_0=1.0$, $T_0=10.0$, $E_{\mathrm{base}}=1.0$, $k=0.5$, $\lambda=0.08$, $\gamma_0=1.2$, $V_{\max}=10.0$, $E_{\mathrm{thresh}}=5.0$, $\delta=5.0$, $\Delta t=0.2$, 150 steps) and the discrete recursions of (5.1)(5.5)(5.6).

| ID | Criterion | Pass | Fail |
| :-: | :-- | :-- | :-- |
| **X1** | Reproduce conclusion 1 of Appendix X ($T_{\mathrm{pred}}$ collapse strictly precedes $E_{\mathrm{flow}}$ falling below threshold) | reproduction rate 100% (otherwise the reconstruction is wrong and M0's conclusion does not hold) | <100% |
| **X2** | The conclusion is a by-product of a parameter inequality, not a discovery | one can write analytically "the conclusion holds ⟺ an explicit inequality between $k_s/(E_{\mathrm{thresh}}-E_{\mathrm{floor}})$ and the collapse threshold", and the conclusion flips when $k_s$ is swept so that the inequality flips | no such flipping interval can be found |
| **X3** | Adding a null model (all feedback couplings removed, same-distribution random driving retained) makes the conclusion disappear | under the null model the "precedes" relation disappears ($\lvert$timing-agreement rate $-0.5\rvert<0.15$) | still holds under the null model (indicating it is necessary in the model structure rather than the coupling mechanism) |
| **X4** | Information content of conclusion 2, "removing any loop prevents collapse" | counted over a perturbation set: compared with "reduce the driving strength at random", the ablation is not specific (specificity ratio within $[0.5,2]$) | specificity ratio $>2$ (then the conclusion has content and this protocol must be rewritten) |

**Role of X2/X4**: giving "what counts as unfalsifiable" a computable criterion rather than an evaluative sentence.

### M0.2　Mutation testing across all modules

For each of M1–M7, construct at least one mutant that **gets that sentence of v1.59 wrong**, and test whether this patch's criteria can judge it a failure. The mutation detection rate is denoted $\pi_{\mathrm{mut}}$.

| Mutant | Text mutated | Module expected to detect it |
| :-- | :-- | :-: |
| $\mu_1$ tail-probability rarity median = 2 bit | §12.1 | M1 |
| $\mu_2$ the two backgrounds may be added / ranked | §12.1.1 Rule 3 | M1 |
| $\mu_3$ replace iterative delimiting with "take the carrier connected component" | §12.8 | M2 |
| $\mu_4$ coarsening order by signal strength | HR-6 | M3 |
| $\mu_5$ the 3 bit threshold used alone suffices | §13.3.3(4) | M4 |
| $\mu_6$ decoding discrepancy equals the error rate directly (no need to control shock magnitude) | HR-7 | M5 |
| $\mu_7$ a general-purpose compressor can directly estimate rule depth | §14.6 | M6 |
| $\mu_8$ threshold triggering means $V\to0$ | Volume I §5.1.2 / §5.19 | M7 |

- **Criterion**: $\pi_{\mathrm{mut}}\ge 7/8$ (i.e. at least 7 mutants judged as failures).
- **Failure**: $\pi_{\mathrm{mut}}\le 6/8$. In that case the report must explain item by item which criterion lacks resolving power for which mutant, and that criterion is downgraded to "not counted in conclusions".
- **Undecidable**: a mutant cannot be implemented within the specified model family (the reason must be stated).

---

## 4　M1　Three numerical assertions of the rarity protocol

### 4.1　Assertions and models

**Q1 (1 bit baseline, §12.1).** Original: "Under the assumptions that the background is i.i.d., the statistic is continuous and there are no ties, the tail probability of a randomly drawn reading follows a uniform distribution on $(0,1)$, so the rarity $-\log_2 p$ has median exactly 1 bit and mean $1/\ln2\approx1.44$ bit. These two numbers depend only on the three assumptions above; **when the background has tied values or the statistic is discrete, uniformity fails**, and the values must be recomputed from the actual distribution."

**Model**: reading $X$ drawn from background $B$. (a) continuous: $B=\mathcal N(0,1)$ and $B=\mathrm{Exp}(1)$, one setting each; (b) **uniformly discrete**: $B$ takes $K$ equiprobable values, $K\in\{2,4,8,16,64,256,1024\}$; (c) **non-uniformly discrete**: binomial $\mathrm{Bin}(100,1/2)$ (exactly the "number of black cells" reading used in §12.2); (d) ties: continuous readings quantized at resolution $\Delta$, $\Delta\in\{10^{-3},10^{-2},10^{-1},10^{0}\}$ times the standard deviation.

**Q2 (two forms of a typical reading, §12.2).** Original: "At the last row, $k\approx50$, the discrete-result form is about 3.65 bit, close to the background entropy; the tail-probability form is about 0.9 bit, close to the baseline of 'median 1 bit'."

**Q3 (orders of magnitude of the two backgrounds, §12.1.1).** Original: "A reading that computes to 0.3 bit against the habitat background may compute to 12 bit against the protocol baseline." And Rule 3: "the rarities computed under the two calibers must not be subtracted, ranked, or plotted on the same axis."

**Model**: two named worked examples — (i) daylight for a diurnal holder: reading = "spectral type", $B^{\mathrm{env}}$ gives daylight a natural frequency of 0.9, $B^{\max}$ is uniform over $K=12$ spectral classes; (ii) perfect crystal: a $N=12$-cell binary array, $B^{\max}$ has each cell equiprobable and independent, $B^{\mathrm{env}}$ gives an "all-0" frequency of 0.05 in the holder's habitat. A separate **rank-reversal** example is also constructed: three readings $A,B,C$, with rarity order $A>B>C$ under $B^{\mathrm{env}}$ and $C>B>A$ under $B^{\max}$.

### 4.2　Criteria

| ID | Criterion (pass) | Refutation (fail) | Author's prior prediction |
| :-: | :-- | :-- | :-- |
| **Q1a** | Under continuous backgrounds the KS test of the tail probability gives $p>0.01$; median $\in[0.99,1.01]$; mean $\in[1.42,1.46]$ | any item out of bounds | all hold (this is the identity of a probability integral transform) |
| **Q1b** | Under uniform discreteness with $K\le1024$ the median is still in $[0.98,1.02]$ and the mean in $[1.40,1.48]$ | out of bounds | **holds** — i.e. "discreteness makes uniformity fail" does **not** hold for uniform discreteness |
| **Q1c** | Under non-uniform discreteness ($\mathrm{Bin}(100,\tfrac12)$) the median is $<0.97$ bit or the mean is $<1.35$ bit | neither out of bounds, so the discrete offset is negligible | median $\approx0.93$, mean $\approx1.28$, $\mathbb E[p_{\mathrm{tail}}]=(1+\sum p^2)/2\approx0.5399$ |
| **Q1d** | When quantization creates ties, the offset of the median relative to the continuous case increases monotonically with $\Delta$ | non-monotone or offset $<0.01$ bit | offset $>0.05$ bit at $\Delta=1\sigma$ |
| **Q2** | Compute both forms of the reading at $k=50$ exactly from $\mathrm{Bin}(100,\tfrac12)$; the "0.9 bit" of the tail-probability form is explained by discreteness and agrees with the Q1c median (difference $<0.05$ bit) | the two differ by $\ge0.05$ bit (showing that 0.9 has another source and my explanation is wrong) | the two accounts agree; the reading "0.9 is close to the 1 bit baseline" mistakes the **discrete offset** for the baseline |
| **Q3a** | Both worked examples show a cross-caliber gap of $\ge1$ order of magnitude ($\ge10$ times) | gap $<10$ times | holds ($0.15$ bit vs. $>10$ bit; $4.3$ bit vs. $12$ bit) |
| **Q3b** | A rank-reversal example exists, and the reversal is robust within the parameter neighbourhood (still reversed $\ge95\%$ after ±10% perturbation) | no reversal found, or the reversal disappears under perturbation | holds |

**If Q1c passes**: the sentence "when the background has tied values or the statistic is discrete, uniformity fails" in §12.1 of v1.60 must be changed to a directional quantitative statement (discreteness makes the median **too low**, with the computable correction $\mathbb E[p_{\mathrm{tail}}]=(1+\sum p^2)/2$ given). This is the main output of M1.

---

## 5　M2　Decidability of the boundary identification procedure

### 5.1　Synthetic world (constructed independently of the RIF equations)

$N=64$ units arranged in an $8\times8$ grid. Two "self-sustaining clusters" (the ground-truth boundary):

- cluster $\mathcal A$: $4\times4=16$ cells, with its own energy–activity closed loop (activities $x_i\in\{0,1\}$ are inputs to one another, metabolism replenished according to $x_i$);
- cluster $\mathcal B$: $3\times3=9$ cells, isomorphic but with different parameters (weaker internal coupling);
- the remaining 39 cells are "environment units": no closed loop, activity driven at random from external sources, decaying when the driving is withdrawn.

Dynamics: $x_i(t+1)=\mathbf 1[\sum_{j\in\partial i}w_{ij}x_j(t)+\xi_i(t)>\theta_i]\wedge(e_i>0)$; $e_i(t+1)=e_i(t)-\kappa x_i(t)+g_i(x_i)+\epsilon_i$, where within a cluster $g_i$ is proportional to total loop activity and for environment units $g_i=0$.

**Independent definition of the ground-truth boundary** (using no RIF quantity): for each unit perform a single-point ablation and record "the time for system activity to fall below 10% of steady state" (cap $T_{\max}$). **Core = the set of units whose removal makes that time below 50% of baseline.** The ground-truth boundaries $\mathcal A^{*},\mathcal B^{*}$ are computed this way, independently of RIF's I–T–E criteria.

**Decoder**: resolution $\theta$ (one "activity-cell count" read per $\theta\times\theta$ block), reading $r$ a discrete level of block activity; backgrounds (i) $B^{\mathrm{env}}$ = long-range habitat frequency (including environment units), (ii) $B^{\max}$ = equiprobable independence within a block. $\iota_D\in\{0.5,1,2,3\}$ bit.

**Three candidate sources** (as in §12.8 ①):
- carrier boundary: the connected components of the adjacency graph (dense within a cluster, sparse between clusters and towards the environment), plus sub-candidates cut by the declared partitioning rule;
- functional boundary: the closed subgraph of the "who supplies energy to whom" dependency graph whose output cannot be replaced by an external equivalent;
- observer-reachable: the intersection of $\operatorname{Dom}(D)$ with the measurement-reachable set, i.e. units whose block reading under $\theta$ is $\ge\iota_D$.

**Iteration update rule R1 (must be fixed in advance; §12.8 gives no default rule, so this protocol adds one and declares that it is an addition)**: for a candidate $P^{(k)}$, any unit $u$ adjacent to $P^{(k)}$ is included if $T_{\mathrm{struct}}$ of $P^{(k)}\cup\{u\}$ exceeds that of $P^{(k)}$ by $>5\%$ and the three items I–T–E still all take values; if after inclusion $I_{\mathrm{struct}}<\iota_D$ or $E$ cannot be allocated, the unit is excluded. $N_{\mathrm{iter}}=5$. Stopping follows S1/S2 (S1 = member sets in two consecutive rounds differ by $\le1$ unit and all three items take values).

**Injection of failure classes**: to make F1–F4 testable, four controlled scenarios are added: (F1) set $\iota_D$ above the readings of the boundary units; (F2) make the two clusters share one energy source that cannot be allocated; (F3) create two candidates that are both geometrically plausible but mutually incompatible (connected component and functional closure disagree and no prior can rule one out); (F4) make the inclusion rule oscillate between two configurations (set the 5% threshold so that a certain unit falls on either side).

### 5.2　Criteria

| ID | Criterion (pass) | Refutation (fail) | Prediction |
| :-: | :-- | :-- | :-- |
| **B1** | At high resolution ($\theta=1$, $\iota_D=1$), the Jaccard of the iterated result with the ground-truth core is $\ge0.80$ (median, $n_{\mathrm{rep}}=500$ worlds) | $<0.80$ | 0.85–0.95 |
| **B2** | Iteration **must** beat the "union of three sources, no iteration" baseline: $\Delta J\ge0.10$ | $\Delta J<0.10$ — then the iteration step of §12.8 contributes nothing to the result and must be downgraded to a "candidate generation rule" | $\Delta J\approx0.05$–$0.15$ (**this is the item in this module most likely to fail**) |
| **B3** | Iteration beats the "carrier connected component only" baseline: $\Delta J\ge0.15$ | $<0.15$ | holds |
| **B4** | As resolution degrades, $J$ decreases monotonically, and is $<0.5$ at $\theta=4,\iota_D=3$ | non-monotone, or does not fall below 0.5 | holds |
| **B5** | The proportion of injected failure types judged correctly is $\ge0.75$ (diagonal of the four-class confusion matrix) | $<0.75$ | F1 high (easy to judge), F3/F4 low (hard to judge) |
| **B6** | On normal worlds with no injected failure, the false-alarm rate of "boundary undecidable" is $\le0.10$ | $>0.10$ | 0.02–0.08 |

**If B2 fails**: §12.8 of v1.60 must demote "iterative delimiting" from a [Definition] to two steps, "candidate generation + consistency check", and explicitly delete the implication of "convergence to a unique admissible boundary". This is the heaviest revision this patch may produce.

---

## 6　M3　Persistence resolution and coarsening order

### 6.1　Model

The holder faces $K=24$ ordered cues $\xi_1<\cdots<\xi_{24}$ (one-dimensional and ordered, so that the optimal partition can be computed exactly). Response library $A=\{a_1,\dots,a_6\}$; payoff matrix $U(\xi,a)$ generated by "the optimal response changes in steps with $\xi$" (3 true steps). $\mathrm{sv}$ is measured in payoff.

- **Reading partition**: cut $\{1..24\}$ into contiguous blocks, one response per block. The **decoding cost** of the partition is $C=\sum_{b}c_b$, where $c_b$ is the readout cost of block $b$, $c_b=c_0(1+\sigma_c z_b)$, $z_b\sim\mathrm{Unif}(-1,1)$, and $\sigma_c$ is the cost heterogeneity.
- **Optimal partition**: $\max\ \mathbb E[\mathrm{sv}]-\lambda C$, solved exactly by one-dimensional DP ($O(K^2\cdot\lvert A\rvert)$).
- $\delta_r$ defined as in §12.9.5: $\delta_r(b)=\mathbb E[\mathrm{sv}\mid b,a^{*}]-\mathbb E_{B^{\mathrm{env}}}[\mathrm{sv}]$.
- **Signal strength** $S_b$: when block $b$ and its neighbour have different optimal responses, the payoff difference between the two blocks ($\lvert\Delta U\rvert$); zero when the responses are the same.

**Key design (to guarantee power)**: construct $U$ so that the orderings by $\lvert\delta_r\rvert$ and by $S$ are **negatively correlated** (Spearman $\rho\le-0.5$); otherwise "ordering by $\lvert\delta_r\rvert$" and "ordering by signal strength" cannot be distinguished and the test has no resolving power. This is written into criterion B0.

### 6.2　Criteria

| ID | Criterion (pass) | Refutation (fail) | Prediction |
| :-: | :-- | :-- | :-- |
| **R0 (power precondition)** | In the generated world, the Spearman $\rho$ between $\mathrm{rank}(\lvert\delta_r\rvert)$ and $\mathrm{rank}(S)$ is $\le-0.5$ | $\rho>-0.5$ → the world is not counted in R1 and must be redrawn (at most 200 times; if still unsatisfied, judge "undecidable") | satisfiable |
| **R1 (HR-4)** | As the persistence constraint tightens ($\lambda$ from small to large, equivalent to a falling decoding budget), the Kendall $\tau$ between the ordering of threshold-change magnitudes across distinctions and the ordering by $\lvert\delta_r\rvert$ is $\ge0.6$, and clearly higher than the $\tau$ against the $S$ ordering (difference $\ge0.2$) | $\tau<0.6$ against $\lvert\delta_r\rvert$, or the $\tau$ against $S$ is not lower | $\tau\approx0.5$–$0.8$ against $\lvert\delta_r\rvert$; $\tau\approx0$–$0.3$ against $S$ |
| **R2 (literal version of HR-6)** | Raising $\lambda$ step by step, the order in which distinctions are discarded agrees completely with "ascending $\lvert\delta_r\rvert$" in a proportion $\ge0.80$ (with homogeneous cost $\sigma_c=0$) | $<0.80$ | $=1.00$ at $\sigma_c=0$ (the two rules are then equivalent) |
| **R3 (HR-6, heterogeneous cost)** | When $\sigma_c/\bar c\ge0.5$, the agreement rate of the literal order with "ascending $\lvert\delta_r\rvert$" drops significantly ($<0.5$), while the agreement rate with "ascending $\delta_r/c$" is $=1.00$ | the literal order still $\ge0.8$ under heterogeneous cost (then cost heterogeneity does not affect the order and my mechanism analysis is wrong) | agreement rate $\approx0.2$–$0.4$ |
| **R4** | With $\sigma_c/\bar c$ on the horizontal axis, the agreement rate of the literal order decreases monotonically; report the 50% crossing point $\sigma_c^{*}$ | non-monotone | $\sigma_c^{*}\approx0.2$–$0.35$ |

**If R3 passes and R2 holds only at $\sigma_c=0$**: HR-6 of v1.60 must be written as "**when the decoding cost is roughly the same for all distinctions**, drop the smallest $\lvert\delta_r\rvert$ first; when costs are heterogeneous, drop the smallest $\delta_r/c$ first", and "how to measure $c$" must be listed as an open problem. This is not a rephrasing; it turns an ordering treated as a law into an **ordering with premises**.

---

## 7　M4　Operating characteristics of the two-step causal-reading test

### 7.1　Model

Control distribution $B_0=\mathcal N(0,1)$ (effect-size scale); treatment-group truth $\mathcal N(d,1)$. $d\in\{0,0.2,0.5,0.8,1.2,2.0\}$ ($d=0$ is the null effect). $n_{\mathrm{ctrl}}=n_{\mathrm{trt}}=n\in\{20,50,100,200,500\}$. $n_{\mathrm{rep}}=2000$ per cell.

- **First step**: Welch $t$ test, two-tailed, $\alpha_0=0.05$ (also report $0.01$); a TOST equivalence test is run at the same time with $\delta_{\mathrm{eq}}=0.2$ (standardized mean difference, the conventional value in the text).
- **Second step**: $p_{\mathrm{tail}}=\Pr_{B_0}(e'\ge e_{\mathrm{obs}})$, $I=-\log_2 p_{\mathrm{tail}}$; the interval uses BCa bootstrap ($B=5000$, resampling control samples), converted to bits by the **endpoint exchange** rule of §13.3.2(3).
- **Admission** (as in §13.3.3(4)): first step, corrected $p\le\alpha_0$ and the effect-size interval does not overlap the equivalence band; second step, $I\ge3$ bit and **its lower bound** holds at the 95% level (this text takes the reading "the 95% lower bound of $I$ $\ge3$", and also reports in the results the outcome of the looser reading "the point estimate of $I$ $\ge3$", both given).

### 7.2　Criteria

| ID | Criterion (pass) | Refutation (fail) | Prediction |
| :-: | :-- | :-- | :-- |
| **T1** | With $d=0$ and both steps done, the admission rate is $\le0.05$ (whole grid) | $>0.05$ | 0.00–0.02 (because the 3 bit lower bound is strict) |
| **T2** | With $d=0$ and **skipping** the first step, the admission rate is $\approx1/8$ ($\in[0.09,0.16]$) | out of bounds | 0.10–0.14; this is the quantitative version of what that sentence in §13.6 "wanted to stop and did not" |
| **T3** | Conditional bias of the reported $I$ (winner's curse): $\mathbb E[\hat I\mid\text{admitted}]-\ I_{\mathrm{true}}$ grows as $n$ decreases, and is $>1.0$ bit at $n=20$ | bias $<0.5$ bit or not monotone | 1.5–3 bit at $n=20$ |
| **T4** | Sample size needed to reach the bar: with $I_{\mathrm{true}}=3$ bit, the smallest $n$ at which the pass rate of "95% lower bound $\ge3$" is $\ge0.8$ | no such $n\le500$ exists (then the 3 bit threshold is unreachable for small samples under that reading and the text must change) | $n\approx300$–$500$ |
| **T5** | With $I_{\mathrm{true}}=3$, the pass rate of the point-estimate reading is already $\ge0.5$ at $n=100$; the two readings differ by $>0.3$ | no difference | holds |
| **T6** | Equivalence-band conversion check: at $q=0.05$, $[1-\log_2(1.1),\,1-\log_2(0.9)]$ agrees with "$1\pm0.14$ bit" in the text (error $<0.01$ bit); at $q=0.10$ it agrees with "$1\pm0.29$" | error $\ge0.01$ bit | holds (this is an L1 identity) |
| **T7** | Joint probability of "judged equivalent" but point estimate of $I$ $\ge3$ is $<0.01$ (showing the two criteria do not conflict) | $\ge0.01$ | $<0.005$ |

---

## 8　M5　Decoding discrepancy predicts error (HR-7)

### 8.1　Model

The environment has $K=8$ categories of cues; true frequencies $\pi_t$ change over time (shock or drift). The holder's internal model $B_{\mathrm{int}}$ is estimated by exponential weighting: $\hat\pi_{t+1}=(1-\eta)\hat\pi_t+\eta\,\mathbf 1[\xi_t]$, learning rate $\eta\in\{0.01,0.05,0.2,1.0\}$ ($1.0$ means instantaneous). Decision: take the Bayesian posterior under $\hat\pi$ and the optimal action; the action set $A$ has 4 elements, and the payoff matrix makes "using the wrong $\pi$" produce a measurable loss. $\mathrm{sv}=\mathbb E[\text{payoff}]$; error rate = proportion of suboptimal actions.

- Discrepancy $G_t=D_{\mathrm{KL}}(\pi_t\,\|\,\hat\pi_t)$ (this report uniformly takes "true ‖ internal"; the convention is fixed in the code and does not change with results).
- Shock magnitude $\Delta$: push $\pi$ from $\pi_0$ to $\pi_0+\Delta\cdot v$ ($v$ a fixed direction), $\Delta\in\{0.05,0.1,0.2,0.4\}$; a separate drift speed $\omega\in\{0,0.01,0.05\}$.
- $T=400$ steps, $n_{\mathrm{rep}}=2000$.

### 8.2　Criteria

| ID | Criterion (pass) | Refutation (fail) | Prediction |
| :-: | :-- | :-- | :-- |
| **D1** | Pooled correlation of $G_t$ with the subsequent error rate is $r\ge0.6$ (whole grid, $p<10^{-6}$) | $<0.6$ | 0.7–0.9 (contemporaneous) |
| **D2 (core)** | **After controlling shock magnitude and learning rate**, the partial correlation of $G_t$ with the error rate is still $r_{\mathrm{partial}}\ge0.3$, and significant in $\ge$ half the cells | $r_{\mathrm{partial}}<0.3$ or significant cells $<50\%$ | **$r_{\mathrm{partial}}\approx0.1$–$0.3$, may fail** ($G_t$ is a lagged function of $\Delta$ and $\eta$, with high collinearity) |
| **D3** | Held-out prediction: a model using $G$ alone has lower RMSE on the error rate of held-out worlds than a model using $\Delta$ alone (difference $\ge5\%$) | no advantage | difference 0–10% (uncertain) |
| **D4** | The "decision-relevant projection" $G^{\mathrm{rel}}_t$ (restricting the KL to the subset of cues that affect the action) explains the error rate significantly better than the full KL $G_t$ ($\Delta R^2\ge0.05$) | $<0.05$ | $\Delta R^2\approx0.1$–$0.3$ |

**If D2 fails**: "still predicts after controlling the shock magnitude" in HR-7 is **not identifiable** within the online-learning model family, and v1.60 must change it to "the gap between $B_{\mathrm{int}}$ and $B^{\mathrm{env}}$ is a **contemporaneous** state reading, whose predictive power over error comes mainly from its collinearity with the shock magnitude", or add "a version using the first difference of $G$ as the predictor". **If D4 passes**, additionally suggest listing the "decision-relevant projection" as a candidate operationalization of the $B_{\mathrm{int}}$ discrepancy (labelled as a candidate, not a main-text definition).

---

## 9　M6　Measurability of rule depth and compression gain

### 9.1　Model

**(a) Depth estimability.** On a $32\times32$ binary grid, generate objects from a **declared rule library** (periodic stripes, checkerboard, monochrome blocks, runs, embedded subgraphs), with true depth $n^{*}\in\{0,1,2,3,4\}$ ($n^{*}=0$ is pointwise random). Two routes to estimate depth: (i) description length from a general-purpose compressor (zlib level 9 / lzma); (ii) **in-library MDL fitting** (enumerate rule combinations within the declared library and take the shortest description). The criterion compares the recovery rates of the two routes and measures performance on **out-of-library rules** (a generative mode inexpressible in the library, e.g. pseudo-random linear-congruential positions).

**(b) One-sided discriminating power of compression gain (§14.4).** $N=400$, $k=20$ defects, four placements: periodic, equally spaced + jitter, random, pseudo-random rule (short description that the compressor cannot capture). $L_D$ is upper-bounded by compressing the "difference sequence of positions". Criterion: the distribution and sign of $\hat G_{\mathrm{comp}}$.

**(c) Calibration assumption $b=1$ (Volume II §2.4).** Generate an "evolutionary history": $m\in\{0..6\}$ transitions, each adding $\Delta n\sim\{1,2,3\}$ independent rules (probabilities $0.5,0.3,0.2$), and with probability $0.2$ only recombining without adding rules. This gives $D^{\mathrm{stat}}=n^{*}$ and $\#\{\mathcal T\}=m$; regress $D^{\mathrm{stat}}=a+b\,\#\{\mathcal T\}$ and test $b=1,a=1$ ($t$ test, $\alpha=0.05$).

### 9.2　Criteria

| ID | Criterion (pass) | Refutation (fail) | Prediction |
| :-: | :-- | :-- | :-- |
| **K1** | In-library MDL depth recovery ($n^{*}$ hit exactly) $\ge0.85$ | $<0.85$ | 0.9–1.0 |
| **K2** | Recovery rate of the general-purpose compressor (zlib) $\le0.30$ | $>0.30$ (then "depth can be estimated by general compression" and my reading is wrong) | 0.0–0.15 |
| **K3** | On out-of-library rules, in-library MDL recovery $\le0.20$, and errors are mainly "underestimates" (systematic rather than random) | recovery $>0.5$ or errors without direction | holds |
| **K4** | Correct-judgement rate of $\hat G_{\mathrm{comp}}>0$ for "a rule really exists" $\ge0.95$ (periodic and equally spaced + jitter) | $<0.95$ | 0.97–1.0 |
| **K5** | On random placement the proportion with $\hat G_{\mathrm{comp}}\le0$ is $\ge0.90$ | $<0.90$ | 0.9–0.99 |
| **K6** | On pseudo-random rules the proportion with $\hat G_{\mathrm{comp}}\le0$ is $\ge0.80$ (i.e. the false-negative rate is high) — this **supports** "$\approx0$ cannot confirm the absence of a rule" | $<0.80$ (then the compressor captures the rule and the rule must be changed) | 0.85–1.0 |
| **K7** | Regression gives $\hat b\in[1.7,2.4]$, $b=1$ rejected ($p<0.001$), $a=1$ rejected | $\hat b<1.3$ or $b=1$ not rejected | $\hat b\approx1.9$–$2.1$ |

**If K7 passes**: the calibration test of Volume II §2.4 **is executable and will fail** — precisely its value. v1.60 must pre-write "if $b\ne1$, then $D^{\mathrm{dyn}}$ serves only as an ordinal scale", and put this simulation's $\hat b$ into a footnote as an example of "expected magnitude" (not as an empirical value).

---

## 10　M7　Terminal phase diagram, robustness of the damaged equilibrium, bistable basin

### 10.1　Model

**(a) Three-case classification (§5.1.2 / §5.6 / §5.19).** Take the constant-parameter version of (5.2)/(5.3), $\dot V=V(g_0)(1-V/V_{\max})-\delta_{\mathrm{dam}}V\mathbf 1[E_{\mathrm{eff}}>E_{\mathrm{thresh}}]$, $g_0=r_{\mathrm v}-\gamma_0$. Integrate to $t=500$ on a $(g_0,\delta_{\mathrm{dam}})$ grid and classify by the text's convention ($V<10^{-3}V_{\max}$ reset to zero; $\lvert V-V^{*}\rvert/V^{*}<10^{-2}$ reduced order; $\lvert V-V_{\max}\rvert/V_{\max}<10^{-2}$ saturated), then compare with the analytic three cases.

**(b) Moving target ("any time-varying parameter turns the fixed point into a moving target", end of the same section).** Let $r_{\mathrm v}(t)=r_{\mathrm v0}(1+\varepsilon t)$, $\varepsilon\in[10^{-4},10^{-1}]$, and measure the maximum relative deviation of the actual trajectory from the fixed-point trajectory $V^{*}(t)$ under frozen parameters. Criterion: find the critical $\varepsilon^{*}$ at which the deviation exceeds 10%, and align it with the dimensionless quantity $\varepsilon/g_0$.

**(c) Bistable basin (§5.2.3 category (4)).** With $\alpha_{\mathrm{eff}}=3$, $\chi=0.9\chi_{\mathrm c}$, integrate a $200\times200$ grid of initial values in the $(I,V)$ plane and measure the proportion that diverge ($V$ exceeding $10^3 V^{*}$), giving the basin measure.

### 10.2　Criteria

| ID | Criterion (pass) | Refutation (fail) | Prediction |
| :-: | :-- | :-- | :-- |
| **P1** | Agreement rate between the numerical terminal classification and the analytic three cases is $\ge0.99$ (excluding grid points in the boundary band $\lvert g_0-\delta_{\mathrm{dam}}\rvert/\delta_{\mathrm{dam}}<10^{-3}$; the number excluded must be reported) | $<0.99$ | holds |
| **P2** | Relative numerical error of the damaged equilibrium $V^{*}=V_{\max}(1-\delta_{\mathrm{dam}}/g_0)$ is $<10^{-3}$ | $\ge10^{-3}$ | holds |
| **P3** | The critical $\varepsilon^{*}$ of the moving target satisfies $\varepsilon^{*}/g_0\in[0.05,0.5]$ (i.e. "piecewise approximation" applies when the driving drift is far slower than the net growth rate, and "far slower" is of order $O(0.1)$, not $O(10^{-3})$) | $\varepsilon^{*}/g_0<0.01$ or $>2$ | $0.1$–$0.3$ |
| **P4** | The divergent proportion of the bistable basin is $\in[0.05,0.6]$ (i.e. "$\chi<\chi_{\mathrm c}$ must not be treated uniformly as path one" has real content, and not almost everything diverges) | $<0.01$ (the warning has no content) or $>0.9$ (almost all diverge, over-warning) | $0.1$–$0.4$ |

---

## 11　Verdict summary and reporting discipline

1. Each item receives one of three states: **pass** / **fail (text must change)** / **undecidable**.
2. **All failing items go into `03_v1.60_revision_notes.md`**, each with: location, current text, proposed text, evidence, and "the refutation you must supply if the author disagrees".
3. **Passing items must not be written as "the theory is verified"**; only "no error under that reading was detected within this model family".
4. Every module must first report the **mutation detection rate of M0.2**; a module that fails M0.2 has its conclusions labelled "criterion lacks resolving power, not counted".
5. The report must have a separate section "where the author's predictions went wrong" — every case where measurement contradicts the prediction of §3–§10, listed one by one.
6. Each figure must state "what this figure lets one see, and what it does not"; purely decorative figures with no information content are prohibited.

---

*The SHA-256 of this file is in `results/prereg_B.sha256`, written by `sim/run_all.py` before its first run.*
