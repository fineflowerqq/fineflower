# Simulation report B (v1.59 measurement layer and protocol layer)

**LiangRuifeng** | 2026 | Companion to `batch_B/`
Verdict conventions are given in `01_预注册协议_B.md` (reference English translation: `01_preregistration_protocol_B_EN.md`); the text changes corresponding to the 13 failures are in `03_v1.60_revision_notes.md`.

---

## 0　Summary

**What was done.** Seven groups of reading protocols and criteria that are **written on paper and never run** in v1.59 were transplanted into synthetic worlds and carried out literally:
the three protocols and two backgrounds for rarity (M1), the §12.8 boundary identification procedure (M2), persistence resolution and coarsening order (M3),
the §13.3 two-step test (M4), HR-7's decoding-discrepancy prediction (M5), rule depth and compression gain (M6),
and the terminal classification and bistable basin of Volume I (M7). M0 additionally reconstructs Appendix X of the 0.0 edition as a specimen of "unfalsifiability",
providing a reference for what every later criterion must not be.

**Conclusions fall into three classes.**

| Class | Items | Representative |
| :-- | :-: | :-- |
| **Established** | 31 | the 1 bit baseline is a limit as $K\to\infty$, not a finite value (M1); one-sided discriminating power of compression gain (M6); three-case terminal classification and $V^*$ (M7) |
| **Failed** | 13 | the §12.8 pairing criterion passes even for the full set and cannot delimit a boundary (M2); the "3 bit lower bound" is actually a 6–7 bit gate (M4); HR-6's coarsening order needs the "homogeneous cost" premise (M3) |
| **Undecidable** | 2 | the F1–F4 failure classification of §12.8 was not implemented as a decidable injection (M2 B5/B6) |

**The three heaviest** (details in Group A of `03_v1.60_revision_notes.md`):

1. **The "admissible boundary" of §12.8 is not a boundary.** The pairing criterion is a **conjunction of existence** of the three items and is monotone with respect to supersets:
   in 100% of synthetic worlds, **all 64 units of the full grid** pass I–T–E pairing. The criterion therefore defines at most an "admissible description".
   The four compliant inclusion rules yield boundary Jaccard values of only 0.34–0.44, while the simplest "functional closure only" gives 0.73 and
   "carrier connected component only" gives 0.46 — **three sources plus iteration did not beat one naive sentence**.
2. **For "$I_{\mathrm{causal}}\ge3$ bit and this lower bound holds at the 95% confidence level" in §13.3.3(4),
   the actual threshold is 6.0–7.2 bit.** With a true value of exactly 3 bit, raising $n$ from 50 to 1200 keeps the pass rate at 0.35–0.47,
   and it never reaches 0.8. Either delete the lower-bound clause, or admit that 3 bit is only a **point-estimate** threshold.
3. **"Drop the distinctions with the smallest $|\delta_r|$ first" in HR-6 is missing a premise.** With homogeneous costs, the order and $|\delta_r|$
   have Kendall $\tau=0.72$ (not 1); with heterogeneous costs, $\tau$ against $\delta_r/c$ is 0.74, clearly above
   0.56 against $\delta_r$. What sets the order is **the ratio of gain to cost**, not the gain itself.

---

## 1　Method and verdict conventions

### 1.1 Four layers of evidence

| Layer | Proposition type | How far this patch goes |
| :-: | :-- | :-- |
| **L1** | definitional identities, algebraic conversions | uniformity in M1, equivalence-band conversion in M4 |
| **L2** | protocol **decidability**: what can be obtained by following the text literally | M2, M6 |
| **L3** | statistical **operating characteristics**: false positives, power, sample size | M3, M4, M5 |
| **L4** | extrapolation to reality | **not attempted at all** |

Any "M2 pass" is read as "this protocol can separate the cases in this synthetic world", not as "it can do so in reality".

### 1.2 Verdicts and session discipline

- Each item receives only one of **pass / fail / undecidable**; "undecidable" must state what is missing. This round has 46 items in total: 31 passes (four of them M0 items, worded "diagnosis established"
  because what is judged is the defect of Appendix X, not the truth of the theory), 13 failures, 2 undecidable.
- Each module reports a **power precondition** first: M3's R0 requires "the two orderings are genuinely separable", M2's B0 requires "the structure is genuinely redundant".
  Cells where the precondition fails are excluded from the conclusions.
- Each module writes "the author's prior predictions" first (see the pre-registration). **Predictions that turned out wrong are listed separately in §10.**

### 1.3 Environment

Python 3.13.13, numpy 2.5.4, scipy 1.18.1, matplotlib 3.11.2; single-machine CPU; no external data;
master seed `20261103`; `run_all.py` takes about 3 minutes end to end (M2/M4 are the heaviest).

---

## 2　M0　First, the counterexample: why Appendix X of the 0.0 edition is not a simulation

> This section is not score-settling. v1.59 has already deleted Appendix X, but **deleting an appendix is not the same as growing the correct practice**.
> M0 reconstructs that appendix as a computable diagnostic object in order to set a floor for the 46 criteria that follow:
> **a criterion that cannot possibly fail is not a criterion.**

### 2.1 Subject under examination

The "Appendix X: fivefold recursive numerical simulation" at lines 2260–2274 of `00_0.0版/中文_卷Ⅰ_0.0.md`, and the equations
(5.1†)–(5.6†) it cites (lines 877–941 of the same book). Its three conclusions are:

1. "In **all** parameter configurations that lead to structural disintegration, $T_{\mathrm{pred}}$ collapse strictly precedes $E_{\mathrm{flow}}$ falling below threshold";
2. "Removing **any one** recursive loop **completely prevents** structural disintegration";
3. "Dormant state: $T_{\mathrm{pred}}$ collapses but $E_{\mathrm{flow}}$ stays below threshold".

### 2.2 Four diagnoses (all established)

**D1　Not reproducible.** The parameter block given in the appendix contains only 11 symbols
($I_0,T_0,E_{\mathrm{base}},k,\lambda,\gamma_0,V_{\max},E_{\mathrm{thresh}},\delta,\Delta t$, steps),
whereas the (5.1†)–(5.6†) it claims to implement requires another **8** symbols that are never assigned:
$\chi$, $V_0$, $E_{\mathrm{structure}}$, $k_s$, $T_{\min}$, $I_{\mathrm{struct}}$, $T_{\mathrm{static}}$, $E_{\mathrm{causal}}$.
$k_s$ matters in particular — the $k=0.5$ in the parameter block is already taken by $r_v=kV$ in (5.2†), and $k_s$ is a different quantity.
In addition, the appendix states that "$V^{\mathrm{virt}}$ is computed with $\alpha_{\mathrm{eff}}=2.5$", whereas $\alpha_{\mathrm{eff}}$
appears only in the (5.12)/(5.13) group of v1.59 and **not in the (5.1†)–(5.6†) the appendix claims to implement** — it cites a state variable from another model.

**D2　The "universal proposition" is really a rewriting of a parameter condition.** Along the trajectory of (5.6†), $T_{\mathrm{pred}}$ decreases monotonically, so
"$T_{\mathrm{pred}}$ collapses first, $E_{\mathrm{flow}}$ falls below threshold later" is decided only by the sizes of the two thresholds, independent of how fast the trajectory runs and of $\chi$:

$$
E_{\mathrm{flow}}>E_{\mathrm{thresh}}\iff T_{\mathrm{pred}}<\tau_E\equiv\frac{k_s}{E_{\mathrm{thresh}}-E_{\mathrm{structure}}},
\qquad \text{the proposition holds}\iff \tau_E<3.0\iff k_s<3\,(E_{\mathrm{thresh}}-E_{\mathrm{structure}}).
$$

Numerical bisection gives the flip point $k_s^*=12.000$, consistent with the analytic value $3\times(5-1)=12$ (difference $<10^{-9}$).
The reported $k_s=0.5$ lies inside this domain, while in the parameter box I fixed ($k_s\in[0,40]$, $E_{\mathrm{structure}}/E_{\mathrm{thresh}}\in[0,1]$),
**81.2% of the region lies outside** — that is, the proposition is false at those values. So the sentence "holds in all parameter configurations"
happens to hold near its own parameter point and fails over most of the parameter space.

**D3　The failure domain is a narrow slit.** At the reported $k_s=0.5$, failure of the proposition requires
$E_{\mathrm{structure}}>4.833$, i.e. the structural energy cost must rise above **96.7%** of the threshold.
In other words, near the reported point every attempt will "hold", and that is not evidence in itself.

**D4　It does not even depend on that mechanism.** Replacing (5.5†) with four different monotonically decreasing forms
($k_s/T$, $k_s/T^2$, $e^{k_s/T}$, affine decrease), the proposition still holds in **3 of 4**.
All it really depends on is the sentence "$E_{\mathrm{flow}}$ decreases monotonically with $T_{\mathrm{pred}}$", and that sentence is written into the functional form.
The affine form $6.5-0.35T$ gives $\tau_E=4.29>3$ at the reported parameters, so the proposition does not hold —
showing that "which decreasing form is used" can itself change the conclusion, and the appendix gives no reason for the choice.

### 2.3 The diagnostic figure (F3)

![F3](figures/F3_不可证伪性诊断_附录X.png)

> **Figure F3**　(a) The parameter domain where the proposition holds (green) and where it can fail (red); the white line is the analytic boundary
> $k_s=3(E_{\mathrm{thresh}}-E_{\mathrm{structure}})$ and the diamonds are the report points of Appendix X.
> (b) The supremum of $E_{\mathrm{flow}}$ as a function of the unreported $T_{\min}$: the damage channel is reachable only when $T_{\min}<0.125$ s,
> and $T_{\min}$ was never assigned. **What this figure shows**: that "holds in all configurations" conclusion is a parameter condition.
> **What it does not show**: what the real fivefold recursive dynamics looks like.

### 2.4 What this section is for

Every criterion that follows must be able to answer two questions: **"what result counts as its failure"** and **"would changing that sentence change the result"**.
D2/D4 of M0 are the negative samples for both: a conclusion that follows necessarily from the functional form will not change no matter how many times it is run.

---

## 3　M1　Three numerical assertions of the rarity protocol

### 3.1 Sentences examined

| ID | Location | Key wording of the original |
| :-: | :-- | :-- |
| Q1 | §12.1 | "Under the assumptions that the background is i.i.d., the statistic is continuous and there are no ties, the tail probability of a randomly drawn reading follows a uniform distribution on $(0,1)$, so the rarity $-\log_2p$ has median exactly 1 bit and mean $1/\ln2\approx1.44$ bit. These two numbers depend only on the three assumptions above; when the background has tied values or the statistic is discrete, uniformity fails and the values must be recomputed from the actual distribution." |
| Q2 | §12.2 | "At the last row, $k\approx50$ … the tail-probability form is about 0.9 bit, close to the baseline of 'median 1 bit'." |
| Q3 | §12.1.1 | "A reading that computes to 0.3 bit against the habitat background may compute to 12 bit against the protocol baseline"; Rule 3: "the rarities computed under the two calibers must not be subtracted, ranked …" |

### 3.2 Results

**(a) Continuous backgrounds: all established (L1 identities).** For three continuous backgrounds ($\mathcal N(0,1)$, exponential, uniform),
the KS test of the tail probability gives $p>0.01$, and $I$ has median 1.000 and mean 1.4427. This is a probability integral transform; it has to be so.

**(b) But 1 bit / 1.44 bit are limits as $K\to\infty$, not values on a finite support.** Under a uniform support of size $K$,
the mean of $I$ has the closed form

$$
\mathbb E[I]=\log_2K-\frac1K\log_2(K!),
$$

| $K$ | 2 | 4 | 8 | 16 | 64 | 256 | 1024 |
| :-- | --: | --: | --: | --: | --: | --: | --: |
| Mean | 0.500 | 0.854 | 1.088 | 1.234 | 1.375 | 1.422 | 1.437 |

The error between the closed form and exact enumeration is $<10^{-12}$. That is, the sentence in §12.1, "the median is exactly 1 bit, the mean 1/ln2",
**is exact only in the continuous limit**; on a finite support the mean is systematically low — only 1.088 at $K=8$ (25% low).

**(c) The discrete offset is caused not by "discreteness" but by "non-equiprobability".** Under uniform discreteness the median stays near 1 bit;
but with the binomial reading $\mathrm{Bin}(100,\tfrac12)$ that §12.2 itself uses, the median drops to **0.890 bit** (unique value) and the
mean to **1.318 bit**. The reason is the identity

$$
\mathbb E_B[p_{\mathrm{tail}}]=\tfrac12\left(1+\textstyle\sum_r \Pr_B(r)^2\right)\ \ge\ \tfrac12 ,
$$

with equality if and only if the background is continuous. For the binomial, $\sum p^2=0.0563$ and $\mathbb E[p_{\mathrm{tail}}]=0.528$,
so the tail probability is systematically pushed towards 1 and rarity is thereby low. **This identity is the correct form of the "recompute" sentence that §12.1 ought to add.**

> **Disclosure of a criterion failure.** Pre-registration Q1b says "under uniform discreteness the median $\in[0.98,1.02]$".
> Measurement showed that **the median can be non-unique** on a discrete support (at $K=2$ both 0 and 1 are medians), so the criterion is formally unexecutable.
> This is a failure of the criterion, not of the result. Q1b was accordingly changed to "the mean agrees with the closed form and converges monotonically with $K$",
> at 2026-11-03 16:14, for the reason above. Q1d had a sign convention written wrongly (the offset should be taken in absolute value),
> disclosed and corrected likewise. Neither change alters the order-of-magnitude conclusions.

**(d) "0.9 is close to the 1 bit baseline" in §12.2 reads a discrete offset as the baseline.** By exact computation, the
tail-probability rarity at $k=50$ is **0.890 bit**, exactly equal to the median 0.890 under binomial discreteness (difference 0.000).
So 0.9 is not "close to 1" but **already 11% off**: the median $p_{\mathrm{tail}}=0.540$ gives 0.890 bit,
while the continuous baseline is 1 bit, a difference of $=1-\log_2(2\times0.540)=0.111$ bit. This difference can be predicted directly from $\Sigma p^2$.
The four numbers in §12.2 (100 / 93.4 / 87.7 / 3.65) are themselves correct; what is wrong is the reading "close to the baseline".

**(e) The order-of-magnitude gap between the two backgrounds, and the rank reversal, both hold.** Daylight example: $B^{\mathrm{env}}$ gives 0.15 bit,
$B^{\max}$ ($K=4096$ spectral bins) gives 12.00 bit, a ratio of **×3686**; perfect crystal example: 4.32 vs 12.00, a ratio of **×205**.
More troublesome, **the ranking reverses**: the rarity order of four readings under $B^{\mathrm{env}}$ is the opposite of that under $B^{\max}$,
and the reversal still holds under ±10% perturbation in a proportion of 1.000. This is not "the two calibers give different values" but "the two calibers can give opposite conclusions".

### 3.3 Figures

![F1](figures/F1_稀有度基准与离散偏移.png)

> **Figure F1**　(a) Cumulative distribution of the tail probability: a continuous background lies strictly on the diagonal, a discrete background falls **below** it as a whole,
> i.e. tail probabilities grow and rarity is systematically low; the grey text gives the identity $\mathbb E[p]=(1+\Sigma p^2)/2$.
> (b) Convergence of the mean with $K$ under uniform discreteness: 0.50 at $K=2$, 1.09 at $K=8$, 1.437 at $K=1024$;
> the blue band is the interval in which the median is **not unique**; the two horizontal dashed lines mark 1 bit and $1/\ln2$, and the red dotted line is the actual value for the binomial background.
> (c) Ties caused by quantization: each order of magnitude added to the step drops the median further, leaving only 0.25 bit at $\Delta=2\sigma$.
> **What it shows**: the baseline is a limit, the offset has a direction, ties are the main source. **What it does not show**: which $\Delta$ a real reading sits on.

![F2](figures/F2_两种背景的量级差与排序反转.png)

> **Figure F2**　(a) The same reading, two backgrounds: daylight 0.15 vs 12.00, crystal 4.32 vs 12.00.
> (b) The same set of readings gives opposite rankings under the two calibers (reading D is the rarest under $B^{\mathrm{env}}$
> and falls to third under $B^{\max}$). **What it shows**: Rule 3 of §12.1.1 is not formalism.
> **What it does not show**: which caliber is "more correct" — they answer two different questions.

### 3.4 Verdicts

| ID | Verdict | In one sentence |
| :-: | :-: | :-- |
| Q1a | pass | Under continuous backgrounds the median is 1 and the mean 1.44; it is an identity |
| Q1b | pass (criterion changed) | But these two numbers are limits as $K\to\infty$; on a finite support the mean drops to 1.09 |
| Q1c | pass | Only non-equiprobable discreteness produces an offset: binomial readings have median 0.890 and mean 1.318 |
| Q1d | pass (criterion changed) | Quantization ties drive the median monotonically low, by 0.75 bit at $\Delta=2\sigma$ |
| Q2 | pass | The 0.9 in §12.2 is precisely the median of that discrete background and should not be read as "close to the 1 bit baseline" |
| Q3a | pass | Cross-caliber ratios ×3686 and ×205; the order-of-magnitude promise holds |
| Q3b | pass | A robust rank reversal exists |

---

## 4　M2　Can the boundary identification procedure of §12.8 delimit a boundary

### 4.1 Sentences examined

> "② In round $k$, for each candidate $P^{(k)}$ decide whether I–T–E can be paired … and generate $P^{(k+1)}$ according to the pre-declared inclusion/exclusion rule."
> "(S1) Pairing stable: the member set of some candidate is the same in two consecutive rounds … and the three items $I$, $T$, $E$ all take values on that candidate. Call this candidate an **admissible boundary**."

### 4.2 The two things to test

**(i) The pairing criterion is a conjunction of existence of the three items.** Adding units to a candidate cannot make any of the three items "unavailable" —
$I$ is computable, $T$ is computable, $E$ is computable. The criterion is therefore **monotone with respect to supersets**: if $P$ is admissible, so is any $P'\supset P$.
If the inclusion rule requires only that "the new candidate still passes pairing", the candidate expands monotonically along the adjacency graph until it reaches the reachable set.

**(ii) If the structure is redundant, first-order marginals carry no boundary information.** Redundancy means members are interchangeable, none individually necessary.
Then removing any member changes $T_{\mathrm{struct}}$ only by $O(1/n)$, below any reasonable threshold,
so the "minimal sufficient set" rule either peels the boundary down to a skeleton — or, conversely, cannot peel anything off.

### 4.3 Synthetic world

$8\times8=64$ units. The ground-truth boundary is given by the **generative process**, independent of the I–T–E criteria:
cluster A has 12 members plus 4 remote energy-supply units $D_A$, **16** in total; there are also 10 free-rider shell units, cluster B (9+2) as a distractor,
and the rest are environment units. The remote energy-supply units connect to A via long-range energy-supply edges, yet they form a separate connected component in the **carrier graph**.

Three candidate sources are generated as in §12.8 ①: the **carrier connected component**, the **functional closure** (upward tracing of the observed energy-supply graph + co-varying activity companions),
and the **observer-reachable** set (units whose single-point reading in the left half-field reaches $\iota_D$).
All three "compliant" inclusion rules are implemented: **pairing test only**, **minimal sufficient set (by $T$)**, **maximal-$I$ expansion**,
plus "union of the three sources without iteration" as a control. 80 repetitions per world, two world types (homogeneous redundancy / heterogeneous redundancy), $\iota_D\in\{0.5,1,2\}$.

### 4.4 Results

**Ground-truth boundary: 16 units. Jaccard of each method ($\iota_D=1$, homogeneous-redundancy world, median):**

| Method | Jaccard | Members |
| :-- | --: | --: |
| **Functional closure** only | **0.727** | 22 |
| **Carrier connected component** only | 0.462 | 22 |
| Union of the three sources $C_0$ (no iteration) | 0.381 | 42 |
| **Pairing test** only (iterated) | 0.432 | — |
| **Minimal sufficient set** (by $T$, iterated) | 0.338 | 35 |
| **Maximal-$I$ expansion** (iterated) | 0.348 | — |

**Of the five criteria, four fail, one passes, two are undecidable:**

- **B7 (fail): the pairing criterion cannot delimit a boundary.** In **100%** of worlds, **all 64 units of the full grid** pass the I–T–E pairing test.
  This is not a parameter issue: as long as the three items are computable, the full set is admissible. So an "admissible boundary" is at most an "admissible description".
- **B2 (fail): the iteration step contributes too little.** The best of the four compliant outputs is only 0.051 above $C_0$ ($<0.10$) —
  all the discriminating power comes from candidate generation in ①, not from iteration in ③.
- **B3 (fail): it does not beat the most naive sentence.** The best compliant output is 0.432, below "carrier connected component only" at 0.462,
  and far below "functional closure only" at 0.727.
- **B1 (fail): the absolute level is insufficient.** The best compliant output has a Jaccard of only 0.43, far below the pre-registered 0.80.
- **B4 (fail, and the author's prediction was wrong)**: $J$ **rises** with $\iota_D$ (0.38→0.38→0.52),
  contrary to the intuition that "the coarser the resolution, the worse". The reason is explicable: the observer-reachable source is the main source of over-reporting,
  and raising the detection floor happens to narrow it. **This is itself a usable conclusion**: in boundary identification,
  "raising the detection floor" is not necessarily bad, because it doubles as a knob for **precision**.
- **B0 (pass): the redundancy precondition holds**: after removing any A member, the median relative change of $T_{\mathrm{struct}}$ is **0.000**.
- **B5/B6 (undecidable)**: the injection-style failure classification F1–F4 and the "undecidable false-alarm rate" are not implemented in this version; the shared-energy-cost allocation protocol of F2
  and the oscillation criterion of F4 are missing.

### 4.5 Figure

![F4](figures/F4_边界识别_候选源与合规产出.png)

> **Figure F4**　The four panels on the left are membership maps of the same world (black dashed box = ground-truth boundary): truth 16, carrier 22 (extra shell, missing remote supply),
> functional closure 22 (contains most of the truth), observer-reachable 24 (almost everything in the left half-field).
> The bars on the right are each method's Jaccard: all four compliant outputs (blue) lie in 0.34–0.44, below the carrier baseline (grey, 0.46),
> and far below the functional closure (not drawn, 0.727); the red dashed line is the pre-registered 0.80 threshold.
> **What it shows**: the discriminating power lies in "which candidate source is chosen", not in "how many rounds of iteration".
> **What it does not show**: whether the boundary of a real organism likewise falls on the functional closure.

### 4.6 What this means

The [Definition] of §12.8 is underdetermined at the step "inclusion/exclusion rule", and that step **is exactly what decides the answer**.
The text does require the rule to be "pre-declared", so this is not self-contradictory; but a definition that outsources all its discriminating power to an unspecified step
cannot simultaneously claim that "the boundary is decided by pairing". **What pairing can do is reject (missing one of the three disqualifies), not select.**
For a workable fix see A1 of `03`: demote "admissible boundary" to "admissible description", raise the multi-solution reporting rule ④ from an edge case to the main case,
and explicitly require a minimality or optimality criterion.

---

## 5　M3　Persistence resolution and coarsening order

### 5.1 Sentences examined

> HR-6 "As cost rises, resolution coarsens, and the distinctions with the smallest $|\delta_r|$ are dropped first."
> §12.9.3 (ii) "A distinction is retained only when **the persistence gain it brings exceeds the persistence equivalent of its decoding cost**."

### 5.2 Design

24 ordered cues, 6 actions, 3 action steps — but to be **testable**, "ordering by $|\delta_r|$" and
"ordering by signal strength" must first be separable. So the 12 steps are deliberately placed at the positions with the smallest stimulus difference $|\Delta s|$,
and the action amplitudes are made random, so that the gain magnitudes differ across distinctions. Power precondition R0: the Spearman of $\mathrm{rank}(|\delta_r|)$ and
$\mathrm{rank}(S)$ must be below −0.5 — measured **−0.80 to −0.82**, so the precondition holds.

The optimal coarsening path is computed exactly by one-dimensional DP ($\max\ \mathbb E[\mathrm{sv}]-\lambda\sum c_i$),
recording for each $\lambda$ the critical value $\lambda_{\mathrm{crit}}$ at which each distinction "last appears";
its ordering is the optimal discard order. Cost heterogeneity $\sigma_c/\bar c\in\{0,\dots,1\}$ is varied separately.

### 5.3 Results

| $\sigma_c/\bar c$ | $\tau$ vs. $|\delta_r|$ | $\tau$ vs. $\delta_r/c$ | $\tau$ vs. signal strength $S$ |
| --: | --: | --: | --: |
| 0.0 | **0.720** | 0.720 | −0.604 |
| 0.2 | 0.689 | 0.707 | −0.589 |
| 0.4 | 0.690 | 0.749 | −0.585 |
| 0.6 | 0.663 | 0.788 | −0.572 |
| 0.8 | 0.562 | 0.672 | −0.422 |
| 1.0 | **0.555** | **0.741** | −0.447 |

**Three conclusions:**

1. **The direction is right** (R1 partly holds): agreement of the coarsening order with $|\delta_r|$ is clearly higher than with signal strength
   ($\tau\approx0.6$–$0.7$ vs. $\approx-0.5$). HR-4's "order by $|\delta_r|$, not by signal strength"
   is supported in direction.
2. **But "drop the smallest $|\delta_r|$ first" is not the optimal order** (R2 fails): even with fully homogeneous costs,
   $\tau$ is only **0.72**, not 1. The reason is that **gains are non-additive**: the joint benefit is 1.26–1.35 times the sum of pairwise gains,
   adjacent steps interact, and pairwise $\delta_r$ cannot produce the true order.
3. **Once costs are heterogeneous, what decides the order is $\delta_r/c$** (R3 fails): at $\sigma_c=1$, $\tau$ against $\delta_r/c$ is
   0.741 and against $|\delta_r|$ only 0.555, a difference of 0.19 (pre-registration required a difference ≥0.2 for a pass,
   so it misses by 0.01 — but the direction is clear and consistent once $\sigma_c\ge0.2$).

### 5.4 Figure

![F5](figures/F5_粗化顺序由增益代价比决定.png)

> **Figure F5**　(a) $\tau$ of three orderings against the optimal discard order as a function of cost heterogeneity: green ($\delta_r/c$) is always above blue ($|\delta_r|$),
> and red (signal strength) is negative. The gap opens up once $\sigma_c\ge0.6$.
> (b) Scatter of $|\delta_r|$ against signal strength in the same world, $\rho=-0.81$ — the anticorrelation is the precondition for power.
> (c) Scatter of the critical $\lambda$ against $|\delta_r|$, $\tau=0.69$: the larger the gain, the later it is discarded, but the points spread widely.
> **What it shows**: the denominator cannot be omitted. **What it does not show**: in what unit a real decoding cost should be converted.

### 5.5 Fix

HR-6 should become two sentences with premises:
"**When the decoding cost is roughly the same for all distinctions**, drop the smallest $|\delta_r|$ first; **when costs are heterogeneous**, drop the smallest $\delta_r/c$ first."
And "how to measure $c$" should be listed as an open problem (v1.59 already lists domain values for $\delta_{\mathrm{eq}}$,
but not a measurement protocol for decoding cost).

---

## 6　M4　Operating characteristics of the §13.3 two-step test

### 6.1 Sentences examined

> §13.3.3(4) "First step, after correction $p\le\alpha_0$ … Second step, $I_{\mathrm{causal}}\ge3$ bit (corresponding to $p_{\mathrm{tail}}\le1/8$),
> **and this lower bound holds at the 95% confidence level**."
> §13.6 "All effects for which 'no difference was detected' enter step 5 by default and are assigned a middling rarity (close to 1 bit) …"

### 6.2 Conventions

Effect size is the standardized mean difference; $B_0=\mathcal N(0,1)$; treatment group $\mathcal N(d,1)$.
**The first step is run on two samples of $n$ versus $n$** (is there an effect), while **the $e_{\mathrm{obs}}$ of the second step is a single observation,
with $B_0$ estimated from $n$ control samples** (how rare is this effect) — the two steps do not use the same samples, which is exactly what §13.3 means by separating two things.
The tail probability uses the empirical count $\hat p=k/n$, intervals use the exact Clopper–Pearson method, converted to bits by the "endpoint exchange" rule.

> **Disclosure of one easy error.** If the second step compares "the treatment-group mean" with "raw control samples", then $p_{\mathrm{tail}}$ is systematically inflated,
> $I$ is underestimated by about $\tfrac12\log_2 n$ bit, and the tail probability under a null effect is no longer uniform (measured $P(I\ge3)=0.000$).
> This is not a theoretical error but an **implementation trap**: $B_0$ must be "the distribution of the same statistic under control", not "the distribution of the raw response".
> v1.60 should add a sentence in §13.3.2. This also explains why the 1 bit baseline of §12.1 cannot be applied directly to "mean-type effects".

### 6.3 Results

| ID | Result | Verdict |
| :-: | :-- | :-: |
| T1 | Under a null effect (both steps done) the admission rate is **0.005** (maximum over the grid) | pass |
| T2 | Under a null effect, **using the 3 bit condition alone** gives an admission rate of **0.119** (≈1/8) | pass |
| T3 | Conditional bias after admission: **4.39 bit** at $n=20$ | pass |
| T4 | With a true value of 3 bit, as $n$ goes from 50 to 1200 the pass rate stays at **0.35–0.47**, never reaching 0.8 | **fail** |
| T5 | Power difference between the lenient and strict readings ≤0.3 | fail |
| T6 | Equivalence-band conversion agrees with "1±0.14 / 1±0.29 bit" in the text (error 0.0048 bit) | pass |
| T7 | Joint frequency of "judged equivalent" yet reporting $I\ge3$ is 0.0000 | pass |

**A side finding of T3 (the resolution ceiling).** With $+0.5$ smoothing, $\hat p\ge0.5/(n+1)$, so
$I$ is capped at $\log_2 2(n+1)$: only **5.4 bit** at $n=20$. That is, small samples **cannot** report high rarity —
this is not conservatism but the estimator's own ceiling. It also shows that the "detection floor $\iota_D$" of §12.1 and the second step's sample size are
**the same problem**: $n$ determines how high you can report, $\iota_D$ determines how high you must report at least.

**T4 is the core of this section.** Equivalent thresholds (the true $I$ needed for the strict reading to reach power 0.8):

| $n$ | 50 | 100 | 200 | 500 |
| :-- | --: | --: | --: | --: |
| Equivalent threshold (bit) | **7.20** | **6.77** | **6.23** | **6.03** |

That is: **the sentence "$I\ge3$ and its 95% lower bound $\ge3$" in practice screens for effects of 6–7 bit.**
The number 3 holds only under the reading "point estimate $\ge3$". The two readings are not lenient versus strict;
they are **two thresholds inside one sentence**, and the text gives only one number.

### 6.4 Figure

![F6](figures/F6_两步检验的操作特性.png)

> **Figure F6**　(a) Admission rates in a zero-effect world: 3 bit alone (red) sits on the 1/8 line, both steps (green) push it down to 0.005.
> Between them lies the 12.5% that "that sentence wanted to stop and did not".
> (b) Power curve of the strict reading: with a true value of exactly 3 bit, even $n=1200$ gives only 0.44.
> (c) Selection bias: the $I$ reported in admitted samples is systematically above the true value, by 4.4 bit at $n=20$.
> **What it shows**: 3 bit is not a gate but the distance between two gates. **What it does not show**: where a real experiment's effect size falls.

### 6.5 Fix

See A2 of `03`. Choose one of two routes:
**(i)** delete "and this lower bound holds at the 95% confidence level", keep only the point-estimate threshold, and add a separate weak requirement "interval lower bound ≥1 bit";
**(ii)** keep the lower-bound reading but change the threshold to "the 95% lower bound of $I$ $\ge 6$ bit", and state what effect size and sample size this requires.
Do not put 3 and "95% lower bound" in one sentence with only one number given.

---

## 7　M5　HR-7: decoding discrepancy predicts error

### 7.1 Sentences examined

> HR-7 "After a habitat-distribution shock, the gap between $B_{\mathrm{int}}$ and $B^{\mathrm{env}}$ should predict error and a decline in persistence."
> Test method "Artificially shock the frequency distribution, measure the KL gap between the two, and see whether it predicts the subsequent error rate; **control the shock magnitude**."

### 7.2 Design

8 categories of cues, 4 actions; the holder estimates $B_{\mathrm{int}}$ by exponential weighting (learning rate $\eta$), computes the expected payoff from $B_{\mathrm{int}}$
and takes the optimal action; $\pi_t$ is shocked at $t=200$ (magnitude $\Delta$) or drifts uniformly (rate $\omega$).
The consequence reading is the **expected-payoff loss** (less noisy than a 0/1 error rate), with a look-ahead window of 10 steps.
Two candidate predictors: $G=D_{\mathrm{KL}}(\pi_t\|\hat\pi_t)$ (as written in HR-7)
and $A=D_{\mathrm{KL}}\big(p(a|\pi_t)\|p(a|\hat\pi_t)\big)$ (the same-structure quantity $I_{\mathrm{pragmatic}}$ of §13.9).

### 7.3 Results

| ID | Result | Verdict |
| :-: | :-- | :-: |
| D1 | Pooled correlation of $G$ with the consequence $r=-0.185$; dose–response Spearman $-0.16$; $\mathrm{AUC}(G)=0.394$ | **fail** |
| D2 | After controlling $\Delta,\eta,\omega$, the residual $G$ has $\mathrm{AUC}=0.757$ (partial correlation 0.130) | pass |
| D3 | Held-out prediction: adding $G$ lowers RMSE by only $-1.1\%$ | fail |
| D4 | $\mathrm{AUC}(A)=0.880$ vs. $\mathrm{AUC}(G)=0.394$, a difference of **0.487** | pass |

**Reading.** The AUC of $G$ is below 0.5 — ranking by it is worse than chance. This is not noise but mechanism:
just after a shock $G$ is large, yet **the action has not changed** (the argmax is insensitive to a perturbation of the distribution), so the loss is zero;
when an error does occur, $G$ is often already small — it just "happens to be wrong exactly at the edge".
**The full KL measures "how badly wrong the model is", not "how badly wrong the decision is"** — the latter is what $A$ measures.

The contradiction between D2 and D1 (residual AUC 0.757 vs. raw AUC 0.394) demonstrates collinearity:
almost all of $G$'s discriminating power comes from its shared component with $\Delta,\eta$; once removed, the sign flips,
but that component brings no gain in held-out prediction (D3).

### 7.4 Figure

![F7](figures/F7_解码偏差与失误.png)

> **Figure F7**　(a) One world ($\Delta=0.4,\eta=0.05$): $G$ jumps at the shock and the error rate rises only afterwards,
> and the two are not synchronized. (b) The pooled scatter is almost a cloud ($r=-0.19$).
> (c) After removing $\Delta,\eta,\omega$, the residuals correlate positively ($r=0.13$) — a **sign reversal**,
> showing that the raw negative correlation came from "large $G$ coinciding with harmless model error".
> **What it shows**: model error and decision error are not the same thing. **What it does not show**: which is more common in a real ecology.

### 7.5 Fix

See A5 of `03`: HR-7 should change "the gap between $B_{\mathrm{int}}$ and $B^{\mathrm{env}}$" to
"the gap **at the level of the action distribution** (the $I_{\mathrm{pragmatic}}$ of §13.9)", or state explicitly that "$G$ is a state reading,
and testing whether it predicts error does not hold within this model family". Both fixes preserve the candidate status of §13.9 —
this simulation has in fact given it one piece of supporting evidence (AUC 0.880 vs. 0.394).

---

## 8　M6　Measurability of rule depth and compression gain

### 8.1 Sentences examined

> §14.6 step 3 "Search for the shortest hierarchical description in the description language of $D$"; step 5 "Read out $D_{\mathrm{depth}}$".
> §14.4 "$\hat G_{\mathrm{comp}}>0$ can confirm the existence of a rule; $\approx0$ cannot confirm its absence".
> Volume II §2.4 "Regress $D^{\mathrm{stat}}=a+b\cdot\#\{\mathcal T\}$ and test $b=1,a=1$".

### 8.2 Design

A 32×32 binary grid; the rule library contains all-0 / all-1, vertical and horizontal stripes (four periods × two phases), checkerboard, blocks, diagonals — 30 rules in total.
GF(2) linear independence is used first to ensure that "how many rules were used to generate" equals "how few can express it" — otherwise the XOR of three might equal one,
and the ground-truth depth would be undefined (this step was the root of the 0.77 recovery rate in the first version).
Objects are generated as the XOR of 1–3 basic rules; inversion uses in-library MDL exhaustive search up to depth 3.
**Out-of-library rules** (linear-congruential positions, whose description is extremely short but not expressible in the library) and a **general-purpose compressor** serve as controls.

### 8.3 Results

| ID | Result | Verdict |
| :-: | :-- | :-: |
| K1 | In-library MDL depth recovery **1.00** | pass |
| K2 | In-library Kendall $\tau$ between length and depth is 0.41; a purely random object has length 139 bytes (in-library max 44) but depth 0 | pass |
| K3 | With out-of-library rules the recovery rate is **0.00**, all 25/25 **underestimates** | pass |
| K4 | On the two rule-bearing types, the proportion with $\hat G_{\mathrm{comp}}>0$ is 1.00 / 0.98 | pass |
| K5 | On random placement the proportion with $\hat G\le0$ is 1.00 | pass |
| K6 | On **pseudo-random rules** the proportion with $\hat G\le0$ is 1.00 | pass |
| K7 | Regression gives $\hat b=1.29$, $b=1$ rejected ($p=9.2\times10^{-7}$) | pass |

**Three conclusions:**

1. **Depth is estimable in-library and not out-of-library.** The recovery rate falls from 1.00 to 0.00, and the errors all point the same way (all underestimates).
   This is not "a bad algorithm" but a property of §14.6 step 3 itself: the shortest description can only be sought relative to a **declared language**.
   v1.60 should upgrade "a depth report must state language and tolerance" from a "reminder" to "not measured if these two are missing".
2. **Length cannot serve as a proxy for depth, but is not entirely unrelated** ($\tau=0.41$). The counterexample is decisive:
   a purely random object has the largest length (139 bytes) and depth 0, while the longest in-library object is only 44 bytes.
   The division of labour among the three quantities in §14.4 (depth / length / size) holds up in this worked example.
3. **The one-sided discriminating power of compression gain holds** (K4–K6). K6 in particular: on pseudo-random rules the proportion with $\hat G\le0$ is 1.00,
   and this is exactly the false negative that "$\approx0$ cannot confirm the absence of a rule" is meant to guard against. **This is one of the rare results in this round that positively supports the wording of v1.59.**
4. **The calibration test will fail, and that is precisely what makes it useful.** $\hat b=1.29$ (pre-registered prediction 1.7–2.4, **the prediction missed**),
   and $b=1$ is strongly rejected. Volume II §2.4 already pre-wrote "if it fails, fall back to an ordinal scale" — this simulation shows that fallback is necessary,
   not a courtesy.

### 8.4 Figure

![F9](figures/F9_规则深度与压缩增益.png)

> **Figure F9**　(a) Length vs. true depth: within one depth, length can vary 3-fold; out-of-library points (×) have the largest length but depth recorded as 0.
> (b) $\hat G_{\mathrm{comp}}$ for the four placements: periodic and equally spaced + jitter are positive (rules confirmed), random and pseudo-random rules are zero
> (**cannot** confirm the absence of a rule — the latter's description is in fact extremely short).
> (c) Calibration regression: $\hat b=1.29$ clearly departs from the dashed line $b=1$.
> **What it shows**: each of the three quantities has its own job. **What it does not show**: which class of rule language a real object belongs to.

---

## 9　M7　Terminal phase diagram and the "moving target"

### 9.1 Sentences examined

> §5.1.2 three-case classification (reset-to-zero / reduced-order / accelerated collapse) and $V^*=V_{\max}(1-\delta_{\mathrm{dam}}/g_0)$.
> §5.1.2 end "any time-varying parameter turns the fixed point into a moving target, and only piecewise approximation is then possible".
> §5.2.3 category (4) "when $\chi<\chi_{\mathrm c}$ the system is bistable … $\chi<\chi_{\mathrm c}$ must not be treated uniformly as path one".

### 9.2 Results

| ID | Result | Verdict |
| :-: | :-- | :-: |
| P1 | On 600 sampled grid points, agreement of the numerical terminal state with the analytic three cases is **1.0000** (81 points classified "undetermined" are excluded, as is the neighbourhood of $g_0=\delta$) | pass |
| P2 | Relative numerical error of $V^*$ is $1.53\times10^{-7}$ | pass |
| P3 | The critical drift of the moving target is $\varepsilon^*/g_0=0.0077$, an order of magnitude below the pre-registered [0.05,0.5] | **fail (prediction wrong)** |
| P4 | At $\chi=0.9\chi_{\mathrm c}$, divergent initial values account for **29.3%** | pass |

**What P3 means.** The applicability condition of "piecewise approximation" is far harsher than one would think: once the drift of the driving rate reaches
**0.8%** of the net growth rate (per unit time), the frozen-fixed-point deviation from the trajectory exceeds 10%. The reason is that near the damaged equilibrium
$\partial V^*/\partial g_0=\delta/g_0^2$ is large, and $V^*$ is extremely sensitive to $g_0$.
So "treat parameters as constants and extrapolate with the fixed point" is almost always wrong over long windows, **unless the drift rate is below the $10^{-2}g_0$ scale**.
v1.60 should write out this scale; otherwise "only piecewise approximation is possible" is a sentence without operational content.

**What P4 means.** $\chi=0.9\chi_{\mathrm c}< \chi_{\mathrm c}$, yet 29.3% of initial values still diverge.
The warning "$\chi<\chi_{\mathrm c}$ must not be treated uniformly as path one" **does have substance**; it is not defensive phrasing.

### 9.3 Figure

![F8](figures/F8_终局相图与双稳盆地.png)

> **Figure F8**　(a) Phase diagram of the terminal $V/V_{\max}$ in the $(g_0,\delta_{\mathrm{dam}})$ plane, white dashed line $g_0=\delta_{\mathrm{dam}}$:
> the upper-right corner is the reduced-order plateau $V^*>0$, the rest is reset to zero. **This figure makes "threshold triggering ≠ reset to zero" visible at a glance** —
> everything to the right of the white line is operation with damage, not death.
> (b) Moving target: the maximum deviation from the frozen fixed point as a function of drift rate; the black dotted line is the acceptable drift ceiling.
> (c) Bistable basin: $29\%$ of initial values diverge, the rest converge to the lower branch.
> **What it shows**: the four terminal regimes are not four points but a region with internal structure. **What it does not show**: the real value of $E_{\mathrm{thresh}}$.

---

## 10　Where the author's predictions went wrong

Pre-registration requires these to be listed one by one. This round, **4 predictions were contradicted by the results**, all kept:

| ID | What I predicted | Measured | Who should revise |
| :-: | :-- | :-- | :-- |
| M2 B4 | $J$ falls as $\iota_D$ rises | **rises** (0.38→0.52). The observer source is the main over-reporting source; raising the floor narrows it | my intuition was wrong; the conclusion becomes "$\iota_D$ is also a precision knob" |
| M3 R2 | with homogeneous costs the order agrees exactly with $|\delta_r|$ ($\tau=1$) | $\tau=0.72$. Gains are non-additive (joint/pairwise = 1.3) | I underestimated step interaction; the conclusion is stronger |
| M5 D1 | pooled correlation $r\ge0.6$ | $r=-0.185$, AUC 0.394 | I mistook "model error" for "decision error" |
| M7 P3 | $\varepsilon^*/g_0\in[0.05,0.5]$ | 0.0077 | I underestimated the sensitivity of $V^*$ to $g_0$ |

There were also **two errors in the criteria themselves** (disclosed per discipline): M1's Q1b assumed a unique median, and Q1d's sign convention was inverted.
These are failures of criteria, not of results; the times and reasons for the changes are in the disclosure box of §3.2.

---

## 11　What this patch did not achieve

1. **The F1–F4 failure classification of §12.8 was not made into a decidable injection** (M2 B5/B6 undecidable). Two things are missing:
   an allocation protocol for shared energy cost (F2) and a criterion for iterative oscillation (F4). These are themselves open problems of v1.59,
   and this patch cannot supply them.
2. **Operationalization of $W_{\mathrm{sv}}$ and $\iota_D$ in §12.9** was only a parameter sweep; no protocol was given.
   In the simulation $\iota_D$ was simply set to 0.5/1/2/3 bit; what that corresponds to in reality, this patch cannot answer.
3. **Of RIF's nine falsifiable predictions, only HR-4 / HR-6 / HR-7 were touched.** HR-1 to HR-3 are the social-deprivation class,
   requiring real population data; HR-8 is a definitional identity (with the object fixed, the trajectory is determined by the update of $B_0$, nearly tautological);
   HR-9 requires an action-binning protocol for $I_{\mathrm{pragmatic}}$. None of these is within reach of simulation.
4. **Cross-scale extrapolation was not done at all.** Every "pass" is confined to the synthetic model family.
5. **The decoder game of Volume IV and the offline compilation computation of Volume III** were not simulated — they require another model setting,
   and time and space did not allow it this round.

---

## 12　In one sentence

The measurement layer of v1.59 is by and large **executable**: the reading protocols compute, the one-sided discriminating power of compression gain holds,
and the three-case terminal classification matches the damaged plateau. The real problems cluster in **three places where something is "written down but not pinned down"**:
the inclusion rule of §12.8, the double threshold of §13.3, and the implicit premises of HR-6 / HR-7.
These are not typos; they are cases of **discriminating power being outsourced to an unspecified step** — and the point of simulation is to make that visible.
