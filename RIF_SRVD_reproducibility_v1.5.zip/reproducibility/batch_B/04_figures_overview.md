# Figures overview and insertion points

**LiangRuifeng** | 2026 | 11 figures, PNG 300 dpi + same-named PDF (for print) | all in `figures/`

> The six volumes of v1.59 contain **0** figures (the count of "Figure $N$" citations in the whole text is 0). These 11 are purely additive.
> Each entry states: **what it shows, where it goes, what one can see in it, what one cannot**.
> The last two are discipline: if a figure can be deleted without the reader losing anything, it should not exist.

---

## 1. Summary table

| ID | Title | Type | Suggested insertion point | See `03` |
| :-: | :-- | :-: | :-- | :-: |
| F1 | Rarity baseline and discrete offset | diagnostic | end of RIF §12.1 (after the third protocol) | A3 |
| F2 | Magnitude gap and rank reversal between two backgrounds | diagnostic | RIF §12.1.1, after Rule 3 | C1 |
| F3 | Unfalsifiability diagnosis · Appendix X | methodological | **not in the main text**; patch documentation only | — |
| F4 | Boundary identification: candidate sources and admissible outputs | diagnostic | RIF §12.8, after ④ | A1 |
| F5 | Coarsening order is set by the gain-to-cost ratio | diagnostic | RIF §12.9.3, after Rule 1 | A6 |
| F6 | Operating characteristics of the two-step test | diagnostic | RIF §13.3.3(4), after that paragraph | A2 |
| F7 | Decoding discrepancy and error | diagnostic | RIF §13.9, inside the candidate-operationalization box | A5 |
| F8 | Terminal phase diagram and bistable basin | semi-conceptual | Volume I §5.1.2, after the three-case classification | B4 |
| F9 | Rule depth and compression gain | diagnostic | end of RIF §14.4; reusable in Volume II §2.4 | B2 / B3 |
| F10 | I–T–E triple record and pairing structure | conceptual | RIF Part II ("Symbolic Constitution") §5, after that section | — |
| F11 | Rarity and polarity as orthogonal axes | conceptual | RIF §12.9.5, after that section | — |

**The two conceptual figures (F10, F11) come first.** They depend on no simulation data; they merely draw, as figures, what the text already presents as tables. Zero risk, largest payoff — and a first-time reader needs exactly these two.

---

## 2. Figure-by-figure notes

### F10　I–T–E triple record and pairing structure

**What it depicts**: two rows by three columns. The rows are the structural channel and the causal channel; the columns are the three quantities $I$, $T$, $E$. Each cell gives the symbol and a one-sentence definition. A bracket on the right states the pairing conditions (same $P$, same $D$, same $W$, compatible attribution rules), and a dashed box at the bottom marks "$E$ unavailable (giving only the barrier height ≠ giving the cost)".

![F10](figures/F10_ITE三元记录与配对结构.png)

**Where it goes**: RIF Part II ("Symbolic Constitution") §5, **after** the table on the I–T–E pairing relation of the two kinds of information. That spot currently has only a three-row, two-column table; what the figure adds is **the location of the pairing conditions** — they belong to no single cell but to the whole row.

**What it shows**: why "all three items present" is not the same as "the three items compose"; why a missing $E$ is **the normal case** (§12.11's storage array is one).
**What it does not show**: which cell the readings of a particular system fall into — there are no numbers in the figure.

---

### F11　Rarity and polarity as orthogonal axes

**What it depicts**: horizontal axis is scarcity $I$ (bit), vertical axis is polarity $\delta_r$ (signed). Each quadrant holds an example: background cue (low scarcity, high $\delta_r$), common but harmful (low scarcity, negative $\delta_r$), rare but useless (high scarcity, zero $\delta_r$), rare and useful (high scarcity, positive $\delta_r$); the lower right additionally marks HR-9's "rare misleading signal".

![F11](figures/F11_稀有度与极性正交平面.png)

**Where it goes**: RIF §12.9.5, after that section. There stands a key sentence — "**rarity and importance are two orthogonal dimensions; this book records them with two separate symbols and does not allow one to stand in for the other**" — the sentence in the whole book that readers most easily skip and most easily misuse.

**What it shows**: why "only things with a lot of information are important" is false (the upper-right and lower-left cells refute it at once); why HR-9 singles out the cell with high $I_{\mathrm{pragmatic}}$ and $\delta_r<0$.
**What it does not show**: how to measure the value of $\delta_r$ — the figure has signs only, no units.

---

### F1　Rarity baseline and discrete offset

**What it depicts**: (a) cumulative distribution of the tail probability: a continuous background lies exactly on the diagonal, a discrete background falls **below** it as a whole, annotated with the identity $\mathbb E[p]=(1+\Sigma p^2)/2$; (b) convergence of the mean with the support $K$ under uniform discreteness, the blue band marking the interval in which "the median is not unique", the red dotted line the actual value for a binomial background; (c) the relation between quantization step and median.

![F1](figures/F1_稀有度基准与离散偏移.png)

**Where it goes**: RIF §12.1, after the third protocol and before the paragraph "on typical values". Recommended: place the §12.2 table after the figure, so the reader first sees "the baseline is a limit" and then "0.89 is the median after the offset".

**What it shows**: 1 bit and 1.44 bit are limits as $K\to\infty$; the offset has a direction (low); ties are its main source.
**What it does not show**: what resolution a real instrument should adopt — that is a protocol question, not a mathematical one.

---

### F2　Magnitude gap and rank reversal between two backgrounds

**What it depicts**: (a) cross-caliber rarity for two named worked examples (daylight, perfect crystal), with ×3686 and ×205 marked; (b) the same set of readings giving **opposite rankings** under $B^{\mathrm{env}}$ and $B^{\max}$.

![F2](figures/F2_两种背景的量级差与排序反转.png)

**Where it goes**: §12.1.1, after Rule 3. Rule 3 is currently a prohibition; this figure is its **justification**.

**What it shows**: the two calibers differ not merely in "value" but can yield opposite conclusions.
**What it does not show**: which caliber is "more correct" — they answer two different questions (rare for whom / formally how special).

---

### F3　Unfalsifiability diagnosis · Appendix X

**What it depicts**: (a) the parameter domain where the proposition holds (green) and where it can fail (red), the white line being the analytic boundary and the diamonds the report points of Appendix X; (b) reachability of the damage channel as a function of the unreported $T_{\min}$.

![F3](figures/F3_不可证伪性诊断_附录X.png)

**Where it goes**: **not in the six volumes**. It belongs to the methodological documentation of the patch (`02_simulation_report_B.md` §2), or to a future "simulation methods" chapter. Putting it in the main text would make readers think the current text is under discussion, whereas Appendix X has already been deleted.

**What it shows**: a conclusion that "holds in all configurations" is in fact a parameter condition; the failure domain can be as narrow as 3%.
**What it does not show**: what the real fivefold-recursive dynamics looks like — it was never run.

---

### F4　Boundary identification: candidate sources and admissible outputs

**What it depicts**: the four panels on the left are membership maps of the same synthetic world (ground truth 16, carrier 22, functional closure 22, observer-reachable 24), with a black dashed box marking the ground-truth boundary; the bar chart on the right is each method's Jaccard.

![F4](figures/F4_边界识别_候选源与合规产出.png)

**Where it goes**: §12.8, after ④. Item ④ now discusses "how to report several admissible boundaries"; this figure shows "how much the candidate sources differ".

**What it shows**: the discriminating power lies in "which candidate source is chosen" (functional 0.73 vs. carrier 0.46), not in "how many rounds of iteration" (0.34–0.44).
**What it does not show**: whether the boundary of a real organism also falls on the functional closure — the ground truth of the synthetic world was planted.

---

### F5　Coarsening order is set by the gain-to-cost ratio

**What it depicts**: (a) Kendall $\tau$ of three orderings against the optimal discard order as a function of cost heterogeneity; (b) scatter of $|\delta_r|$ against signal strength ($\rho=-0.81$; the anticorrelation is the precondition for power); (c) scatter of the critical $\lambda$ against $|\delta_r|$.

![F5](figures/F5_粗化顺序由增益代价比决定.png)

**Where it goes**: §12.9.3, after Rule 1. Rule 1 is the "proposition"; this figure is its **boundary condition**.

**What it shows**: the denominator cannot be omitted — once costs are heterogeneous, $\delta_r/c$ clearly beats $|\delta_r|$; and even with homogeneous costs, $\tau$ is only 0.72.
**What it does not show**: in what unit a real decoding cost should be converted (J? time? opportunity cost?).

---

### F6　Operating characteristics of the two-step test

**What it depicts**: (a) admission rate in a zero-effect world: 3 bit alone stabilizes at 1/8, doing both steps pushes it down to 0.005; (b) power curve of the strict reading (with a true value of 3 bit, even $n=1200$ gives only 0.44); (c) selection bias (the $I$ reported by admitted samples is systematically above the true value).

![F6](figures/F6_两步检验的操作特性.png)

**Where it goes**: §13.3.3(4), after that paragraph. This is the place in the book most likely to be skipped as "statistical common sense", and it is precisely where a threshold gets miscalculated.

**What it shows**: 3 bit is not a gate but the distance between two gates (between 1/8 and 1/1000).
**What it does not show**: where the effect size of a real experiment falls — that is a domain question.

---

### F7　Decoding discrepancy and error

**What it depicts**: (a) the time series of one world ($\Delta=0.4,\eta=0.05$): $G$ jumps at the shock, and the error rate rises only afterwards; (b) pooled scatter ($r=-0.19$); (c) residual scatter after removing $\Delta,\eta,\omega$ ($r=+0.13$, sign reversed).

![F7](figures/F7_解码偏差与失误.png)

**Where it goes**: inside the "candidate operationalization" box of §13.9. It is the **first piece of supporting evidence** for $I_{\mathrm{pragmatic}}$, but by §13.9's own labelling it remains a candidate.

**What it shows**: model error ($G$) and decision error ($A$) are not the same thing, and the former can even reverse sign.
**What it does not show**: which is more common in a real ecology.

---

### F8　Terminal phase diagram and bistable basin

**What it depicts**: (a) phase diagram of the terminal $V/V_{\max}$ in the $(g_0,\delta_{\mathrm{dam}})$ plane, with the white dashed line $g_0=\delta_{\mathrm{dam}}$; (b) the deviation curve for the moving target and the acceptable drift ceiling; (c) the bistable basin at $\chi=0.9\chi_{\mathrm c}$ (29% divergent region).

![F8](figures/F8_终局相图与双稳盆地.png)

**Where it goes**: Volume I §5.1.2, after the three-case classification. **This is the most "textbook" figure of the set** — it turns "threshold triggering ≠ reset to zero" into something visible at a glance: everything to the right of the white line is operation with damage.

**What it shows**: the four terminal regimes are not four points but a region with internal structure; the damaged plateau $V^*>0$ occupies a large area.
**What it does not show**: the real value of $E_{\mathrm{thresh}}$, or where a real system sits in $(g_0,\delta)$.

---

### F9　Rule depth and compression gain

**What it depicts**: (a) description length vs. true depth (length varies 3-fold within one depth; out-of-library points have the largest length but depth recorded as 0); (b) $\hat G_{\mathrm{comp}}$ for the four placements (periodic and equally spaced + jitter positive, random and pseudo-random zero); (c) the calibration regression $\hat b=1.29$ against $b=1$.

![F9](figures/F9_规则深度与压缩增益.png)

**Where it goes**: end of RIF §14.4; panel (c) is reusable in Volume II §2.4.

**What it shows**: the three quantities (depth, length, size) each do their own job; $\hat G\approx0$ really cannot confirm the absence of a rule.
**What it does not show**: which class of rule language a real object belongs to — and that is precisely the conclusion of K3.

---

## 3. Layout conventions

- Figure widths are designed for a single column of 82 mm / double column of 170 mm; PNG at 300 dpi, PDF vector, ready to place.
- Text in the figures uses Microsoft YaHei; mathematical symbols go through mathtext, keeping the same notation as the LaTeX in the text
  ($I_{\mathrm{struct},D}$, $B^{\mathrm{env}}$, $\delta_r$, $D_{\mathrm{depth}}$).
- Color semantics are fixed: blue = habitat background / primary quantity, red = protocol baseline / failure, green = pass / ground truth,
  orange = intermediate state, grey = baseline or "useless", purple = third-class objects. Semantics do not change across figures.
- For each caption, take the "what it shows / what it does not show" sentences from this file and compress them to two lines.

## 4. Figures still missing (left for later)

1. **A survival-resolution schematic for §12.9**: draw "cue → persistence-equivalence blocks → reading" as three stages. M3 this round did the quantitative part only,
   not a conceptual figure.
2. **An iteration-trajectory figure for §12.8**: the time course of the candidate set being added to and removed from over rounds (membership maps like F4, ×5 rounds). Not produced this round.
3. **A layout figure for the holder-level reading table of §13.4**: how one table is arranged, where the four aggregation claims sit. This is a typesetting design, not a data figure.
4. **A decoder-game schematic for Volume IV**: not touched at all this round (see report §11).

None of these is hard, but each requires first deciding "for whom" — main-text readers or patch readers. This round addresses only the latter.
