# batch_B (v1.59 simulation patch B) · Directory guide

**LiangRuifeng** | 2026 | Companion to the six volumes of v1.59 (internal working path `13_v1.59/`, not part of this package) | Everything produced here is new material; no text of v1.59 is modified

---

## In one sentence

This directory performs **simulations of the measurement layer and the protocol layer**: the reading protocols and criteria of RIF Chapters 12–14, Volume I §5.1.2 / §5.6 / §5.2.3 and Volume II §2.4 — the ones that were "written down but never run" — are transplanted into synthetic worlds and carried out literally, to see **whether they can fail, and whether following them literally breaks down**. Each breakdown is then turned into one replacement sentence and paired with figures of a kind that v1.59 does not contain at all.

It is **mutually independent** of `batch_A/` (the other route, which targets the arithmetic layer and dynamical notation): neither cites nor modifies the other.

## Which file to read first

| Order | File | Purpose | Length |
| :-: | :-- | :-- | --: |
| 1 | `01_预注册协议_B.md` (hash-locked original) / `01_preregistration_protocol_B_EN.md` | Criteria, refutation conditions, random seeds, **the author's prior predictions**. Written before any code was run | medium |
| 2 | `02_simulation_report_B.md` | Module-by-module results, the 46 verdicts, where the author's predictions went wrong | long |
| 3 | `03_v1.60_revision_notes.md` | The 12 concrete changes for v1.60 (location / current text / proposed text / evidence / refutation condition) | long |
| 4 | `04_figures_overview.md` | What each of the 11 figures shows, which section it belongs in, how to caption it | medium |
| 5 | `05_theoretical_risk_register.md` | For each claim examined: verdict, residual risk, what would actually close it | short |

## Verdict summary (46 items)

| Module | Subject | Pass | Fail | Undecidable |
| :-: | :-- | :-: | :-: | :-: |
| M0 | Unfalsifiability of Appendix X in the 0.0 edition (diagnosis) | 4 (diagnosis established) | — | — |
| M1 | Three numerical assertions of the rarity protocol | 7 | 0 | 0 |
| M2 | The §12.8 boundary identification procedure | 1 | 5 | 2 |
| M3 | §12.9.3 / HR-4 / HR-6: resolution and coarsening order | 2 | 3 | 0 |
| M4 | The §13.3.3 two-step test | 5 | 2 | 0 |
| M5 | HR-7: decoding discrepancy as a predictor of error | 2 | 2 | 0 |
| M6 | §14: rule depth and compression gain | 7 | 0 | 0 |
| M7 | §5.1.2 / §5.6 / §5.2.3: terminal outcome and basins | 3 | 1 | 0 |
| **Total** | | **31** (including the four M0 "diagnosis established" items) | **13** | **2** |

**All 13 failures are carried into `03_v1.60_revision_notes.md`.** That is the only output form of this patch.

## Directory structure

```
batch_B/
├── 00_directory_guide.md          ← this file
├── 01_预注册协议_B.md             ← hash-locked Chinese original (do not edit)
├── 01_preregistration_protocol_B_EN.md   ← reference English translation
├── 02_simulation_report_B.md
├── 03_v1.60_revision_notes.md
├── 04_figures_overview.md
├── 05_theoretical_risk_register.md
├── sim/                         ← code (12 files, 3679 lines)
│   ├── common.py                shared utilities: random streams, BCa, file output, fonts
│   ├── m0_power.py              Appendix X reconstruction + unfalsifiability diagnosis
│   ├── m1_rarity.py             rarity baseline and discrete offset
│   ├── m2_boundary.py           §12.8 boundary identification (synthetic world + ground-truth boundary)
│   ├── m3_resolution.py         persistence resolution and coarsening order (optimal DP vs. literal rule)
│   ├── m4_twostep.py            operating characteristics of the two-step test
│   ├── m5_bias.py               decoding discrepancy vs. information gain of the action distribution
│   ├── m6_depth.py              rule depth, compression gain, calibration slope
│   ├── m7_dynamics.py           terminal phase diagram, moving target, bistable basin
│   ├── fig_concept.py           two conceptual figures (no data required)
│   ├── run_all.py               one-command reproduction; writes the pre-registration hash before the first run
│   └── show_verdicts.py         reads SUMMARY.json and prints the verdict table
├── results/                     ← JSON (verdicts) + CSV (plotting) + SUMMARY.json
└── figures/                     ← F1–F11, PNG 300 dpi + same-named PDF
```

## Reproducing

```powershell
cd reproducibility/batch_B/sim
python run_all.py        # about 3 minutes, single-machine CPU, no external data
```

Run this from the root of the extracted package. Dependencies: Python ≥3.13, numpy, scipy, matplotlib (no pandas, no network, no GPU).
The hash-locked protocol `01_预注册协议_B.md` still uses the original file names: `02_仿真报告_B.md` is now `02_simulation_report_B.md`, and `03_v1.60修改意见.md` is now `03_v1.60_revision_notes.md`.

On its first run, `run_all.py` writes the SHA-256 of `01_预注册协议_B.md` to `results/prereg_B.sha256`;
if a later run finds a different hash, it prints a warning.

## Three honest declarations

1. **This patch does not prove RIF or SRVD true, nor does it refute them.** It only identifies: numbers that are computed wrongly, procedures that fail when followed literally, and conclusions that hold only under unstated assumptions. Any appearance of "the theory has been verified" in these reports is a breach of this declaration.
2. **Synthetic worlds are not reality.** Every "pass" may only be read as "no error under that reading was detected within this model family"; every "fail" as "the sentence as written does not hold in this model family", which does not mean it fails in reality. Extrapolation (L4) is not attempted at all in this patch.
3. **This is logical pre-registration, not institutional pre-registration.** The protocol and the code were written by the same author in the same working session, with no third-party timestamp. It can prevent "changing the criteria after seeing the results"; it cannot prevent "the author already knew the answer". Readers should discount accordingly.

## Relation to the v1.59 text

All citations in this directory point to the six volumes of the v1.59 working draft (internal path `13_v1.59/`, not included in this package); section and equation numbers are kept as they stand, with no renumbering.
Specific locations involved: RIF §12.1, §12.1.1, §12.2, §12.8, §12.9.3, §12.9.5, §13.3, §13.3.3,
§13.6, §13.9, §14.4, §14.6; Volume I §5.1.2, §5.2.3, §5.6, §5.19; Volume II §2.4, §6.2.
