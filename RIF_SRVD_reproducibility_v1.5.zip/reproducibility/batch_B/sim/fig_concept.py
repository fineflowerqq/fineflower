﻿# -*- coding: utf-8 -*-
"""
F10／F11　概念插图（不依赖仿真数据，用于把理论本身画直）

F10：I–T–E 三元记录与两通道的配对结构，含"E 不可得"的缺项情形。
F11：稀有度 × 极性（δ_r）平面——§12.9.5 说这两个读数正交，这张图把"正交"画成四个象限。
"""
from __future__ import annotations

import numpy as np

import common as K


def figure_f10():
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    K.setup_mpl()

    fig, ax = plt.subplots(figsize=(10.2, 4.6))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.6)
    ax.axis("off")

    cols = [1.5, 4.4, 7.3]
    w, h = 2.5, 1.0
    rows = [(2.55, "Structural channel", K.C["env"]), (0.85, "Causal channel", K.C["acc"])]
    heads = ["$I$  Information (bit)", "$T$  Time (s)", "$E$  Energy (J)"]
    cells = [
        ["$I_{\\mathrm{struct},D}(P)$\nRarity vs. the background",
         "$T_{\\mathrm{struct},D}(P)$\nTime above floor, same class",
         "$E_{\\mathrm{struct},D}(P)$\nEnergy to hold the readout"],
        ["$I_{\\mathrm{causal},D}(P)$\nRarity vs. control baseline",
         "$T_{\\mathrm{causal},D}(P)$\nIdentifiable and answered",
         "$E_{\\mathrm{causal},D}(P)$\nDecoding energy to identify"],
    ]
    for c, head in zip(cols, heads):
        ax.text(c + w / 2, 4.15, head, ha="center", va="center", fontsize=10.5,
                color=K.C["ink"])

    for (y, name, col), row in zip(rows, cells):
        ax.text(0.05, y + h / 2, name, ha="left", va="center", fontsize=10,
                color=col, rotation=90)
        for c, txt in zip(cols, row):
            box = FancyBboxPatch((c, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                 fc=col, ec=col, alpha=0.10, lw=1.2)
            ax.add_patch(box)
            ax.text(c + w / 2, y + h / 2, txt, ha="center", va="center",
                    fontsize=7.6, color=K.C["ink"])

    # 配对括号
    for y in (2.55, 0.85):
        ax.annotate("", xy=(cols[-1] + w + 0.55, y), xytext=(cols[-1] + w + 0.55, y + h),
                    arrowprops=dict(arrowstyle="<->", lw=1.0, color=K.C["grey"]))
    ax.text(cols[-1] + w + 0.72, 3.05,
            "Same $P$, same $D$,\nsame window $W$,\ncompatible attribution rules\n— omit one and it is not a record",
            fontsize=8, color=K.C["ink"], va="center")

    # 缺项情形
    ax.add_patch(FancyBboxPatch((cols[2], -0.05), w, 0.5,
                                boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc=K.C["bad"], ec=K.C["bad"], alpha=0.12, lw=1.2,
                                ls="--"))
    ax.text(cols[2] + w / 2, 0.2, "$E$ unavailable (a barrier height is not a cost)",
            ha="center", va="center", fontsize=7.4, color=K.C["bad"])

    ax.text(0.05, 0.45, "A record needs all three; one missing is the norm, not an anomaly.",
            fontsize=8.5, color=K.C["grey"], ha="left")
    return K.savefig(fig, "F10_ITE三元记录与配对结构")


def figure_f11():
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle
    K.setup_mpl()

    fig, ax = plt.subplots(figsize=(7.4, 5.0))
    ax.axhline(0, color=K.C["ink"], lw=1.0)
    ax.axvline(1.0, color=K.C["grey"], lw=1.0, ls="--")
    ax.set_xlim(-0.4, 14)
    ax.set_ylim(-3.6, 3.2)
    ax.set_xlabel("Rarity $I$ (bit) — how far above the background")
    ax.set_ylabel("Polarity $\\delta_r$ (same units as $\\mathrm{sv}$) — direction and weight for persistence")
    ax.set_title("Rarity and importance are two orthogonal readings (§12.9.5)", fontsize=10)

    pts = [
        (0.15, 2.6, "Background cues\ndaylight, gravity", K.C["ok"], 1),
        (0.35, -2.4, "Common but harmful\nmisleading normality", K.C["warn"], 1),
        (11.5, 0.05, "Rare but useless\na random string", K.C["grey"], 1),
        (9.6, 2.5, "Rare and useful\ntrue signal", K.C["env"], 2),
        (10.8, -2.6, "Rare misleading signal\nhigh $I_{\\mathrm{pragmatic}}$, $\\delta_r<0$\n(HR-9)", K.C["bad"], 2),
    ]
    for x, y, lab, col, sz in pts:
        ax.scatter([x], [y], s=60 * sz, color=col, alpha=0.85, zorder=3,
                   edgecolors="white", linewidths=0.8)
        dx = 0.35 if x < 8 else -0.4
        ha = "left" if x < 8 else "right"
        ax.text(x + dx, y, lab, fontsize=7.8, va="center", ha=ha, color=col)

    ax.annotate("", xy=(13.6, 0.0), xytext=(0.0, 0.0),
                arrowprops=dict(arrowstyle="->", lw=0.8, color=K.C["grey"]))
    ax.text(6.0, 0.18, "\"knowing\" direction", fontsize=8, color=K.C["grey"], ha="center")
    ax.text(1.15, -1.05, "\"acquiring\" direction", fontsize=8, color=K.C["grey"], rotation=90)

    ax.text(0.0, -3.0,
            "The two axes are not interchangeable: a background cue of rarity near 0\n"
            "can matter most; a random string of rarity near $N$ bits, not at all.",
            fontsize=7.6, color=K.C["ink"])
    ax.grid(alpha=0.18)
    return K.savefig(fig, "F11_稀有度与极性正交平面")


if __name__ == "__main__":
    p1 = figure_f10()
    p2 = figure_f11()
    print(p1.name)
    print(p2.name)
