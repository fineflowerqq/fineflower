﻿# -*- coding: utf-8 -*-
"""
run_all.py　runs M0-M7 in order and writes SUMMARY.json.

Before the first run it writes the SHA-256 of `01_预注册协议_B.md` into
`results/prereg_B.sha256`; afterwards it only reads that file back — this is
the verifiable part of what "logical pre-registration" can provide.
"""
from __future__ import annotations

import json
import sys

import common as K

PREREG = K.ROOT / "01_预注册协议_B.md"

VERDICT_EN = {"通过": "PASS", "失败": "FAIL", "不可判": "UNDEC",
              "诊断成立": "DIAG"}


def ensure_prereg_hash() -> str:
    p = K.RESULTS / "prereg_B.sha256"
    digest = K.file_sha256(PREREG)
    if not p.exists():
        with open(p, "w", encoding="utf-8") as f:
            f.write(f"{digest}  01_预注册协议_B.md\n")
        print(f"[prereg] wrote {p.name}: {digest[:16]}…")
    else:
        old = p.read_text(encoding="utf-8").split()[0]
        if old != digest:
            print(f"[prereg] **WARNING**: hash of the pre-registration file "
                  f"differs from the first run. First run {old[:16]}…, "
                  f"now {digest[:16]}…")
    return digest


def main() -> dict:
    ensure_prereg_hash()
    import m0_power, m1_rarity, m2_boundary, m3_resolution
    import m4_twostep, m5_bias, m6_depth, m7_dynamics, fig_concept

    order = [
        ("M0", m0_power, ("D1", "D2", "D3", "D4")),
        ("M1", m1_rarity, ("Q1a", "Q1b", "Q1c", "Q1d", "Q2", "Q3a", "Q3b")),
        ("M2", m2_boundary, ("B0", "B1", "B2", "B3", "B4", "B5", "B6", "B7")),
        ("M3", m3_resolution, ("R0", "R1", "R2", "R3", "R4")),
        ("M4", m4_twostep, ("T1", "T2", "T3", "T4", "T5", "T6", "T7")),
        ("M5", m5_bias, ("D1", "D2", "D3", "D4")),
        ("M6", m6_depth, ("K1", "K2", "K3", "K4", "K5", "K6", "K7")),
        ("M7", m7_dynamics, ("P1", "P2", "P3", "P4")),
    ]

    summary = {"env": K.env_record(), "modules": {}}
    for tag, mod, keys in order:
        print(f"\n=== {tag} ===")
        out = mod.main()
        res = out["results"]
        summary["modules"][tag] = {
            k: {"verdict": res[k]["verdict"], "criterion": res[k]["criterion"]}
            for k in keys if k in res
        }
        for k in keys:
            if k in res:
                print(f"  {k:4s} {VERDICT_EN.get(res[k]['verdict'], res[k]['verdict']):4s} "
                      f"{res[k]['criterion'][:90]}")

    fig_concept.figure_f10()
    fig_concept.figure_f11()

    K.save_json("SUMMARY.json", summary)
    print("\nsummary written to results/SUMMARY.json")
    return summary


if __name__ == "__main__":
    s = main()
    n_pass = sum(1 for m in s["modules"].values()
                 for v in m.values() if v["verdict"] == "通过")
    n_fail = sum(1 for m in s["modules"].values()
                 for v in m.values() if v["verdict"] == "失败")
    n_na = sum(1 for m in s["modules"].values()
               for v in m.values() if v["verdict"] == "不可判")
    n_diag = sum(1 for m in s["modules"].values()
                 for v in m.values() if v["verdict"] == "诊断成立")
    print(f"\ntotal: PASS {n_pass}, DIAG {n_diag} (M0, different wording), "
          f"FAIL {n_fail}, UNDEC {n_na}; "
          f"{n_pass + n_diag + n_fail + n_na} items")
