# -*- coding: utf-8 -*-
r"""
M2　边界识别程序的可判性（RIF §12.8）

被检句
------
「② 第 k 轮对每个候选 P^(k) 判定 I–T–E 能否配对……并按预先声明的纳入／排除规则生成 P^(k+1)。」
「(S1) 配对稳定：某个候选连续两轮的成员集合相同……且 I、T、E 三项在该候选上同时取到值。
  记该候选为"合格边界"。」

要检验的两件事
--------------
(1) 配对判据是**存在性合取**（三项都取到值即通过），对超集单调：往候选里加单元不会让任何一项
    "取不到值"。因此"合格边界"若只由配对判据定义，就不唯一——它至多定义一个"合格描述"。
(2) 当结构是**冗余**的（成员可互换、无单点必需），I–T–E 的一阶边际无法定位边界：
   去掉任一成员，T_struct 只变化 O(1/n)，低于任何合理门槛，于是"最小充分集"规则会把边界剥光。
    这一条与规则选得好不好无关，是聚合量的结构性后果。

世界
----
合成世界，真值边界由生成过程给定：团 A 的 12 个成员 + 4 个远端供能单元 D_A = 16。
另有团 B（9+2）作干扰、5 个搭便车壳层 S_A、其余为环境单元。
动力学与候选集无关，故整个世界只积一次；I、T、E 由同一轨迹在各子集上读出。
"""
from __future__ import annotations

import numpy as np

import common as K

MOD = 2
rng = K.rng_for(MOD)

T_MAX = 600
N_SIDE = 8
N = N_SIDE * N_SIDE

C_ACT = 0.05
A_ACT = 0.034
A_SRC = 0.0045
E0 = 1.0
E_MAX = 3.0

# ---------------------------------------------------------------------------
# 世界
# ---------------------------------------------------------------------------


def idx(r, c):
    return r * N_SIDE + c


def build_masks():
    A = [idx(r, c) for r in range(1, 4) for c in range(1, 5)]      # 3×4 = 12
    S = ([idx(0, c) for c in range(0, 5)] +
         [idx(4, c) for c in range(1, 6)])                          # 10 个壳层
    DA = [idx(r, c) for r in (6, 7) for c in (6, 7)]                # 4 个远端供能
    B = [idx(r, c) for r in range(5, 8) for c in range(1, 4)]       # 3×3 = 9
    DB = [idx(0, 7), idx(1, 7)]                                     # 2 个远端供能
    used = set(A) | set(S) | set(DA) | set(B) | set(DB)
    ENV = [i for i in range(N) if i not in used]
    return A, S, DA, B, DB, ENV


A_IDX, S_IDX, DA_IDX, B_IDX, DB_IDX, ENV_IDX = build_masks()
TRUTH_A = set(A_IDX) | set(DA_IDX)


def neighbours(i):
    r, c = divmod(i, N_SIDE)
    out = []
    for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        rr, cc = r + dr, c + dc
        if 0 <= rr < N_SIDE and 0 <= cc < N_SIDE:
            out.append(idx(rr, cc))
    return out


def build_bonds():
    """**物质键**图：只有同一载体内的物理连接才是键。环境单元之间没有键。

    这是上一版把载体图取成"整格 4-邻接"的错误修正——那会让任何单元的分量都是全格，
    「载体连通分量」这一候选源就退化为全集。
    """
    groups = [A_IDX, S_IDX, B_IDX, DA_IDX, DB_IDX]
    bonded = np.zeros((N, N), dtype=bool)
    for g in groups:
        gs = set(g)
        for i in g:
            for j in neighbours(i):
                if j in gs:
                    bonded[i, j] = bonded[j, i] = True
    # A 与 S 之间的载体粘结（壳层贴在团上）
    gs = set(A_IDX) | set(S_IDX)
    for i in S_IDX:
        for j in neighbours(i):
            if j in set(A_IDX):
                bonded[i, j] = bonded[j, i] = True
    return bonded


BOND = build_bonds()


def supply_edges() -> np.ndarray:
    M = np.zeros((N, N), dtype=bool)     # M[i,j] = i 向 j 供能
    for e, t in zip(DA_IDX, A_IDX[:4]):
        M[e, t] = True
    for e, t in zip(DB_IDX, B_IDX[:2]):
        M[e, t] = True
    return M


SUPPLY = supply_edges()


def observed_supply(rng_local, p_miss=0.2, p_false=0.02) -> np.ndarray:
    """持有者对供能图的观测：漏检 p_miss、虚检 p_false（虚检只发生在近距对上——
    解码器不会凭空推断远距离的能量流）。"""
    M = SUPPLY.copy()
    for i in range(N):
        for j in range(N):
            if i == j:
                continue
            if SUPPLY[i, j]:
                if rng_local.random() < p_miss:
                    M[i, j] = False
            else:
                ri, ci = divmod(i, N_SIDE)
                rj, cj = divmod(j, N_SIDE)
                if abs(ri - rj) + abs(ci - cj) <= 3 and rng_local.random() < p_false:
                    M[i, j] = True
    return M


def activity_companions(X, max_dist=2, r_thr=0.80) -> np.ndarray:
    """从轨迹里可观测到的"活动共变"耦合：相关系数高且距离近。

    这是解码器能从数据里看到的东西（活动同步），不是把真值图直接给它。
    对常值单元（方差为 0）不判定——常值之间的相关无意义。
    """
    C = np.zeros((N, N), dtype=bool)
    sd = X.std(axis=0)
    valid = sd > 1e-9
    with np.errstate(invalid="ignore", divide="ignore"):
        R = np.corrcoef(X[:, valid].T) if valid.sum() > 1 else np.zeros((0, 0))
    idx_valid = np.where(valid)[0]
    for a in range(len(idx_valid)):
        for b in range(a + 1, len(idx_valid)):
            i, j = int(idx_valid[a]), int(idx_valid[b])
            ri, ci = divmod(i, N_SIDE)
            rj, cj = divmod(j, N_SIDE)
            if abs(ri - rj) + abs(ci - cj) <= max_dist and abs(R[a, b]) >= r_thr:
                C[i, j] = C[j, i] = True
    return C


# ---------------------------------------------------------------------------
# 动力学（与候选集无关）
# ---------------------------------------------------------------------------


def simulate(world, t_max=T_MAX):
    A, S, DA, B, DB, ENV = (world["A"], world["S"], world["DA"],
                            world["B"], world["DB"], world["ENV"])
    cost = world["cost"]           # 每个单元的代谢系数（异质版本不同）
    rng_local = world["rng"]
    e = np.full(N, E0)
    x = np.zeros(N, dtype=bool)
    x[A] = True
    x[DA] = True
    x[B] = True
    x[DB] = True
    for i in S + ENV:
        x[i] = rng_local.random() < 0.5

    X = np.zeros((t_max, N), dtype=bool)
    nA = max(len(A), 1)
    nB = max(len(B), 1)
    for t in range(t_max):
        X[t] = x
        intake = np.zeros(N)
        n_da_on = int(x[DA].sum())
        n_db_on = int(x[DB].sum())
        intake[A] = A_ACT * (int(x[A].sum()) / nA) + A_SRC * n_da_on
        intake[B] = A_ACT * (int(x[B].sum()) / nB) + A_SRC * n_db_on
        # 远端供能单元自身缓慢耗尽：这样团 A 的轨迹在观察窗内一定发生变化
        # （若供能单元永存，团 A 全程常值，活动共变就无法被观测到）
        # 远端供能单元自身缓慢耗尽；乘 x 是为了让"已死"的单元不再回充（否则会在 0 附近振荡）
        intake[DA] = (cost[DA] - 0.004) * x[DA]
        intake[DB] = (cost[DB] - 0.004) * x[DB]
        e = np.clip(e - cost * x + intake, 0.0, E_MAX)

        xn = np.zeros(N, dtype=bool)
        src = list(DA) + list(DB)
        xn[src] = e[src] > 0
        Aset, Bset = set(A), set(B)
        for i in list(A) + list(B):
            if e[i] > 0:
                grp = Aset if i in Aset else Bset
                xn[i] = any(x[j] for j in neighbours(i) if j in grp)
        for i in S + ENV:
            xn[i] = rng_local.random() < 0.5
        x = xn
    return X


# ---------------------------------------------------------------------------
# 读数
# ---------------------------------------------------------------------------

_PTAIL_CACHE = {}


def _ptail_table(nP: int) -> np.ndarray:
    tab = _PTAIL_CACHE.get(nP)
    if tab is None:
        from scipy.stats import binom
        tab = binom.sf(np.arange(nP + 1) - 1, nP, 0.5)
        _PTAIL_CACHE[nP] = tab
    return tab


def readout(X, P, iota_D):
    """返回 (I0, T, E)。

    T 的口径：读数仍属 t0 时的辨识类（$\lvert k-k_0\rvert\le10\%k_0$）且 $I\ge\iota_D$ 的总步数。
    注意容差按 **k0** 而非 |P| —— 按 |P| 会让"加进更多单元"自动放宽辨识类，从而奖励扩张，
    那样任何"最小充分集"规则都会退化为"全集"。
    """
    P = np.asarray(sorted(P), dtype=int)
    nP = P.size
    if nP == 0:
        return 0.0, 0.0, 0.0
    k = X[:, P].sum(axis=1)
    k0 = int(k[0])
    if k0 == 0:
        return 0.0, 0.0, 0.0
    tab = _ptail_table(nP)
    p_tail = np.clip(tab[k], 1e-300, 1.0)
    I = -np.log2(p_tail)
    in_class = np.abs(k - k0) <= 0.10 * k0
    T = float(np.sum(in_class & (I >= iota_D)))
    E = float(X[:, P].sum() * 0.05)
    return float(I[0]), T, E


def jaccard(a, b) -> float:
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if (a or b) else 1.0


# ---------------------------------------------------------------------------
# 候选三源
# ---------------------------------------------------------------------------


def source_carrier(seed):
    seen, stack = {seed}, [seed]
    while stack:
        u = stack.pop()
        for v in np.where(BOND[u])[0]:
            v = int(v)
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return seen


def source_functional(seed, M_obs, companions):
    """功能闭包：沿观测供能图的上游（谁向我供能）+ 可观测的活动共变同伴。"""
    seen = {seed}
    changed = True
    while changed:
        changed = False
        for u in list(seen):
            # 上游供能者
            for v in np.where(M_obs[:, u])[0]:
                v = int(v)
                if v not in seen:
                    seen.add(v)
                    changed = True
            # 活动共变同伴
            for j in np.where(companions[u])[0]:
                j = int(j)
                if j not in seen:
                    seen.add(j)
                    changed = True
    return seen


def source_observer(seed, X, iota_D, field_cols=(0, 1, 2, 3)):
    out = {seed}
    for i in range(N):
        _, c = divmod(i, N_SIDE)
        if c in field_cols:
            I1, T1, _ = readout(X, {i}, iota_D)
            if I1 >= iota_D and T1 > 0:
                out.add(i)
    return out


# ---------------------------------------------------------------------------
# 三条"都合法"的声明规则
# ---------------------------------------------------------------------------


def rule_pairing_only(seed, X, iota_D, adj, max_iter=4):
    """R_A：只做配对检验。相邻且三项都取到值即纳入。"""
    P = {seed}
    for _ in range(max_iter):
        add = set()
        for u in P:
            for v in np.where(adj[u])[0]:
                v = int(v)
                if v in P:
                    continue
                I, T, E = readout(X, P | {v}, iota_D)
                if I >= iota_D and T > 0 and E > 0:
                    add.add(v)
        if not add:
            break
        P |= add
    return P


def rule_min_T(seed, C0, X, iota_D, max_iter=8, tol=0.10):
    """R_minT：最小充分集——剔除后 T 变化不足 tol 的成员。"""
    P = set(C0)
    for _ in range(max_iter):
        _, T_P, _ = readout(X, P, iota_D)
        if T_P <= 0:
            break
        drop = None
        for u in sorted(P):
            if u == seed:
                continue
            _, T_m, _ = readout(X, P - {u}, iota_D)
            if abs(T_m - T_P) <= tol * T_P:
                drop = u
                break
        if drop is None:
            break
        P = P - {drop}
    return P


def rule_max_I(seed, C0, X, iota_D, adj):
    """R_maxI：扩张到读数最稀有的极大集合（也是文本允许的"纳入规则"之一）。"""
    P = set(C0)
    for _ in range(6):
        add = set()
        I_P = readout(X, P, iota_D)[0]
        for u in P:
            for v in np.where(adj[u])[0]:
                v = int(v)
                if v in P:
                    continue
                I_new, T, E = readout(X, P | {v}, iota_D)
                if I_new > I_P:
                    add.add(v)
        if not add:
            break
        P |= add
    return P


# ---------------------------------------------------------------------------
# 单世界
# ---------------------------------------------------------------------------


def one_world(rng_local, iota_D=1.0, use_functional=True, heterogeneous=False,
              seed=None, p_miss=0.2):
    """seed 默认取团 A 内部的一个单元（t0 时活跃）。若取到壳层单元，其 k0=0，读数无定义。"""
    if seed is None:
        seed = idx(2, 2)
    cost = np.full(N, C_ACT)
    if heterogeneous:                       # 成员寿命错开，等价于"有强弱之分"
        cost[A_IDX] = C_ACT * (0.85 + 0.30 * rng_local.random(len(A_IDX)))
    world = {"A": A_IDX, "S": S_IDX, "DA": DA_IDX, "B": B_IDX, "DB": DB_IDX,
             "ENV": ENV_IDX, "rng": rng_local, "cost": cost}
    X = simulate(world)
    M_obs = observed_supply(rng_local, p_miss=p_miss)
    if not use_functional:
        M_obs = np.zeros_like(M_obs)
    comp = activity_companions(X)
    if not use_functional:
        comp = np.zeros_like(comp)
    adj = BOND | M_obs | M_obs.T

    car = source_carrier(seed)
    fun = source_functional(seed, M_obs, comp)
    obs = source_observer(seed, X, iota_D)
    C0 = car | fun | obs

    P_A = rule_pairing_only(seed, X, iota_D, adj)
    P_T = rule_min_T(seed, C0, X, iota_D)
    P_I = rule_max_I(seed, C0, X, iota_D, adj)

    out = {
        "J_C0": jaccard(C0, TRUTH_A),
        "J_pairing": jaccard(P_A, TRUTH_A),
        "J_minT": jaccard(P_T, TRUTH_A),
        "J_maxI": jaccard(P_I, TRUTH_A),
        "J_carrier": jaccard(car, TRUTH_A),
        "J_functional": jaccard(fun, TRUTH_A),
        "J_observer": jaccard(obs, TRUTH_A),
        "n_C0": len(C0), "n_pairing": len(P_A), "n_minT": len(P_T),
        "n_maxI": len(P_I), "n_truth": len(TRUTH_A),
    }
    I_C0, T_C0, E_C0 = readout(X, C0, iota_D)
    I_all, T_all, E_all = readout(X, set(range(N)), iota_D)
    out["pairing_ok_C0"] = bool(I_C0 >= iota_D and T_C0 > 0 and E_C0 > 0)
    out["pairing_ok_all"] = bool(I_all >= iota_D and T_all > 0 and E_all > 0)
    # 冗余性见证：去掉任一 A 成员后 T 的相对变化
    _, T_full, _ = readout(X, TRUTH_A, iota_D)
    rels = []
    for u in A_IDX[:6]:
        _, T_m, _ = readout(X, TRUTH_A - {u}, iota_D)
        rels.append(abs(T_m - T_full) / max(T_full, 1.0))
    out["redundancy_max_rel_T_change"] = float(np.max(rels))
    out["redundancy_med_rel_T_change"] = float(np.median(rels))
    out["T_truth"] = T_full
    out["sets"] = {
        "truth": sorted(TRUTH_A), "carrier": sorted(car), "functional": sorted(fun),
        "observer": sorted(obs), "C0": sorted(C0), "pairing": sorted(P_A),
        "minT": sorted(P_T), "maxI": sorted(P_I),
        "A": list(A_IDX), "S": list(S_IDX), "DA": list(DA_IDX),
        "B": list(B_IDX), "DB": list(DB_IDX), "ENV": list(ENV_IDX),
    }
    return out


def figure_f4(cells, ex):
    """M2 插图：候选三源与四条合规产出的成员图 + 各方法的 Jaccard。"""
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    from matplotlib.colors import ListedColormap
    K.setup_mpl()

    fig = plt.figure(figsize=(12.6, 4.0))
    gs = fig.add_gridspec(2, 4, width_ratios=[1, 1, 1, 1.5],
                          height_ratios=[1, 1], wspace=1.05, hspace=0.30)

    sets = ex["sets"]
    truth = set(sets["truth"])
    panels = [("True boundary (16)", truth, K.C["ok"]),
              ("Carrier component (%d)" % len(sets["carrier"]), set(sets["carrier"]), K.C["env"]),
              ("Functional closure (%d)" % len(sets["functional"]), set(sets["functional"]), K.C["acc"]),
              ("Observer-reachable (%d)" % len(sets["observer"]), set(sets["observer"]), K.C["warn"])]

    for j, (title, S, col) in enumerate(panels):
        ax = fig.add_subplot(gs[j // 2, j % 2])
        grid = np.zeros((N_SIDE, N_SIDE))
        for i in range(N):
            r, c = divmod(i, N_SIDE)
            grid[r, c] = 1.0 if i in S else 0.0
        ax.imshow(grid, cmap=ListedColormap(["#f2f4f5", col]), vmin=0, vmax=1)
        # 标出真值边界
        for i in truth:
            r, c = divmod(i, N_SIDE)
            ax.add_patch(Rectangle((c - 0.5, r - 0.5), 1, 1, fill=False,
                                   ec=K.C["ink"], lw=0.5, ls=(0, (1.5, 1.5))))
        ax.set_xticks([])
        ax.set_yticks([])
        ax.grid(False)
        ax.set_title(title, fontsize=8.5)

    # (e)(f) 放在右侧：柱状图
    ax = fig.add_subplot(gs[:, 2:])
    w1 = next(c for c in cells if c["variant"].startswith("W1") and c["iota_D"] == 1.0)
    items = [("Carrier component only", w1["J_carrier_med"], K.C["grey"]),
             ("Union of three sources C0", w1["J_C0_med"], K.C["grey"]),
             ("Pairing test only", w1["J_pairing_med"], K.C["env"]),
             ("Minimal sufficient set (T)", w1["J_minT_med"], K.C["env"]),
             ("Max-$I$ expansion", w1["J_maxI_med"], K.C["env"]),
             ("Truth", 1.0, K.C["ok"])]
    ypos = np.arange(len(items))[::-1]
    for y, (lab, v, col) in zip(ypos, items):
        ax.barh(y, v, height=0.6, color=col, alpha=0.85)
        ax.text(v + 0.015, y, "%.2f" % v, va="center", fontsize=8)
    ax.set_yticks(ypos)
    ax.set_yticklabels([it[0] for it in items], fontsize=8.2)
    ax.set_xlim(0, 1.12)
    ax.set_xlabel("Jaccard vs. true boundary")
    ax.set_title("Detection floor 1 bit: no compliant output beats the simplest carrier baseline", fontsize=9)
    ax.axvline(0.80, color=K.C["bad"], ls="--", lw=1.0)
    ax.text(0.805, 0.35, "Preregistered threshold 0.80", rotation=90, fontsize=7,
            color=K.C["bad"], va="bottom")

    return K.savefig(fig, "F4_边界识别_候选源与合规产出")


def main() -> dict:
    n_rep = 80
    cells = []
    for variant, kwargs in (
        ("W1_均质冗余", dict(heterogeneous=False)),
        ("W2_异质冗余", dict(heterogeneous=True)),
    ):
        for iota in (0.5, 1.0, 2.0):
            rows = []
            for _ in range(n_rep):
                r2 = np.random.default_rng(rng.integers(0, 2 ** 31))
                rows.append(one_world(r2, iota_D=iota, **kwargs))
            cells.append({
                "variant": variant, "iota_D": iota,
                **{f"{k}_med": float(np.median([r[k] for r in rows]))
                   for k in ("J_C0", "J_pairing", "J_minT", "J_maxI",
                             "J_carrier", "J_functional", "J_observer")},
                "n_truth": len(TRUTH_A),
                "n_pairing_med": float(np.median([r["n_pairing"] for r in rows])),
                "n_minT_med": float(np.median([r["n_minT"] for r in rows])),
                "n_maxI_med": float(np.median([r["n_maxI"] for r in rows])),
                "n_C0_med": float(np.median([r["n_C0"] for r in rows])),
                "pairing_ok_all_frac": float(np.mean([r["pairing_ok_all"] for r in rows])),
                "pairing_ok_C0_frac": float(np.mean([r["pairing_ok_C0"] for r in rows])),
                "redundancy_med": float(np.median([r["redundancy_med_rel_T_change"] for r in rows])),
                "T_truth_med": float(np.median([r["T_truth"] for r in rows])),
            })

    w1 = next(c for c in cells if c["variant"].startswith("W1") and c["iota_D"] == 1.0)
    res = {}

    # B0：冗余性见证（前置：结构确实是冗余的）
    res["B0"] = K.verdict(
        w1["redundancy_med"] <= 0.10,
        pass_text="冗余性见证：去掉任一 A 成员后 T_struct 的相对变化中位数 %.3f ≤0.10——"
                  "结构是冗余的，一阶边际不含边界信息"
                  % w1["redundancy_med"],
        fail_text="去掉单个成员即显著改变 T（%.3f），结构不冗余，B1–B3 的解释须改写"
                  % w1["redundancy_med"],
        detail={"redundancy_med": w1["redundancy_med"], "T_truth": w1["T_truth_med"]},
    )
    # ---- 编号与预注册 §5.2 对齐。B0/B7 是新增的前置与探索性诊断，已在报告中标注。
    best = max(w1["J_C0_med"], w1["J_pairing_med"],
               w1["J_minT_med"], w1["J_maxI_med"])

    # B0（新增，前置）：结构必须是冗余的，否则 B1–B4 的解释要换
    res["B0"] = K.verdict(
        w1["redundancy_med"] <= 0.10,
        pass_text="冗余性见证：去掉任一 A 成员后 T_struct 的相对变化中位数 %.3f ≤0.10——"
                  "结构是冗余的，一阶边际不含边界信息"
                  % w1["redundancy_med"],
        fail_text="去掉单个成员即显著改变 T（%.3f），结构不冗余，B1–B3 的解释须改写"
                  % w1["redundancy_med"],
        detail={"redundancy_med": w1["redundancy_med"], "T_truth": w1["T_truth_med"]},
    )
    # B1：迭代结果与真值的 Jaccard（按"最有利于理论"的口径取四条合规规则的最大值）
    res["B1"] = K.verdict(
        best >= 0.80,
        pass_text="最优合规产出的 Jaccard = %.2f ≥0.80" % best,
        fail_text="四种都合规的声明规则，最优者 Jaccard 也只有 %.2f（C_0 %.2f／配对 %0.2f／"
                  "最小充分集 %.2f／最大 I %.2f），远低于 0.80"
                  % (best, w1["J_C0_med"], w1["J_pairing_med"],
                     w1["J_minT_med"], w1["J_maxI_med"]),
        detail={"best": best, "J_C0": w1["J_C0_med"],
                "J_pairing": w1["J_pairing_med"], "J_minT": w1["J_minT_med"],
                "J_maxI": w1["J_maxI_med"]},
    )
    # B2：迭代是否优于"三源并集不迭代"
    d_union = best - w1["J_C0_med"]
    res["B2"] = K.verdict(
        d_union >= 0.10,
        pass_text="迭代比三源并集高 %.3f（≥0.10）" % d_union,
        fail_text="迭代只比三源并集高 %.3f（<0.10）：§12.8 的迭代环节对结果贡献不足，"
                  "判决力全部来自 ① 的候选生成" % d_union,
        detail={"best": best, "J_C0": w1["J_C0_med"]},
    )
    # B3：是否优于"只取载体连通分量"
    d_car = best - w1["J_carrier_med"]
    res["B3"] = K.verdict(
        d_car >= 0.15,
        pass_text="比载体基线高 %.3f（≥0.15）" % d_car,
        fail_text="比最简单的「只取载体连通分量」基线低 %.3f：整套三源+迭代没有超过一句"
                  "「把物理上连在一起的都算进来」（载体 %.2f vs 最优合规产出 %.2f）"
                  % (-d_car, w1["J_carrier_med"], best),
        detail={"best": best, "J_carrier": w1["J_carrier_med"],
                "J_functional": w1["J_functional_med"],
                "J_observer": w1["J_observer_med"]},
    )
    # B4：随检出下限退化（预注册预测：J 随 ι_D 上升而下降）
    j_by = {c["iota_D"]: best for c in cells
            if c["variant"].startswith("W1")}
    j_by_c0 = {c["iota_D"]: c["J_C0_med"] for c in cells
               if c["variant"].startswith("W1")}
    mono = j_by_c0[2.0] < j_by_c0[1.0] < j_by_c0[0.5]
    res["B4"] = K.verdict(
        mono,
        pass_text="J 随 ι_D 上升而单调下降（%.2f → %.2f → %.2f）"
                  % (j_by_c0[0.5], j_by_c0[1.0], j_by_c0[2.0]),
        fail_text="作者预测错了：J 随 ι_D 上升而上升（C_0：%.2f → %.2f → %.2f）。"
                  "原因可解释——观察者可达源是主要的多报来源，提高检出下限恰好把它收窄；"
                  "但这意味着「提高检出下限=降低分辨率=变差」的直觉在边界识别里不成立"
                  % (j_by_c0[0.5], j_by_c0[1.0], j_by_c0[2.0]),
        detail={"J_best_by_iota": j_by, "J_C0_by_iota": j_by_c0},
    )
    # B5/B6：按预注册须报"失败类型判对率"与"误报不可判定率"；本版未实现 → 不可判
    res["B5"] = K.indeterminate(
        "本版未实现 F1–F4 的注入与混淆矩阵：只做了 F1 的机制性讨论（检出下限抬高），"
        "未把四类失败做成可判定的注入场景。缺：F2 的共享能耗分摊协议、F4 的振荡判据。",
        detail={"planned": "prereg §5.2 B5"},
    )
    res["B6"] = K.indeterminate(
        "本版未实现：四条规则都不显式输出「边界不可判定」，无法统计误报率。",
        detail={"planned": "prereg §5.2 B6"},
    )
    # B7（新增，探索性）：配对判据对全集也通过
    res["B7"] = K.verdict(
        w1["pairing_ok_all_frac"] < 0.5,
        pass_text="全集不能通过配对检验（配对判据有定界能力）",
        fail_text="在 %.0f%% 的世界里，**全格 64 个单元**都通过 I–T–E 配对检验：该判据是"
                  "存在性合取，对超集单调，故「合格边界」至多是「合格描述」，不构成边界"
                  % (100 * w1["pairing_ok_all_frac"]),
        detail={"pairing_ok_all_frac": w1["pairing_ok_all_frac"]},
    )

    K.save_csv("M2_boundary.csv", cells)

    # 示例世界：用于插图（成员图）
    ex_rng = np.random.default_rng(20261103)
    ex = one_world(ex_rng, iota_D=1.0)

    out = {"module": "M2", "env": K.env_record(), "results": res,
           "cells": cells, "example_metrics": ex}
    K.save_json("M2_boundary.json", out)
    try:
        figure_f4(cells, ex)
    except Exception as e:            # 作图失败不影响判据
        out["figure_error"] = repr(e)
        K.save_json("M2_boundary.json", out)
    return out


if __name__ == "__main__":
    o = main()
    print(f"{'variant':14s} {'iota':>4s} {'J_C0':>6s} {'J_pair':>7s} {'J_minT':>7s} "
          f"{'J_maxI':>7s} {'nC0':>4s} {'nMinT':>5s} {'redun':>6s}")
    for c in o["cells"]:
        print(f"{c['variant']:14s} {c['iota_D']:4.1f} {c['J_C0_med']:6.3f} "
              f"{c['J_pairing_med']:7.3f} {c['J_minT_med']:7.3f} "
              f"{c['J_maxI_med']:7.3f} {c['n_C0_med']:4.0f} "
              f"{c['n_minT_med']:5.0f} {c['redundancy_med']:6.3f}")
    for kk in ("B0", "B1", "B2", "B3", "B4", "B5"):
        r = o["results"][kk]
        print(f"{kk:3s} {r['verdict']:3s} | {r['criterion']}")
