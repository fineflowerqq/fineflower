﻿# -*- coding: utf-8 -*-
"""
M4　因果读数两步检验的操作特性（RIF §13.3.3、§13.6）

被检句
------
§13.3.3(4)「第一步，校正后 p≤α0……第二步，$I_{causal}\\ge3$ bit（对应 $p_{tail}\\le1/8$），
  且该下界在 95% 置信水平上成立。」
§13.6「第 4 步最容易被跳过……所有"没测出差异"的效果都会默认进入第 5 步，被算出一个
  不高不低的稀有度（接近 1 bit），然后被当作"有一定信息量"记下来。」

口径
----
效果量取标准化均值差；$B_0=\\mathcal N(0,1)$；处理组 $\\mathcal N(d,1)$。
第二步的尾概率用对照样本的经验计数 $\\hat p=k/n$，区间用 **Clopper–Pearson 精确法**
（§13.3.2 允许的一种），再按"端点交换"换算到 bit。
两种准入读法都报：(i) 严——$I$ 的 95% 下界 ≥3；(ii) 宽——$I$ 的点估计 ≥3。
"""
from __future__ import annotations

import numpy as np
from scipy import stats

import common as K

MOD = 4
rng = K.rng_for(MOD)

ALPHA0 = 0.05
DELTA_EQ = 0.2


def analyze(ctrl, trat, e_obs, iota_bit=3.0):
    """两步判定 + 两种准入读法。

    * 第一步在 $n$ 对 $n$ 的两个样本上做（"有没有效果"）。
    * 第二步的 $e_{obs}$ 是**一次**观测到的效果，$B_0$ 由 $n$ 个对照样本估计
      （"这次效果相对于对照分布有多稀有"）。两步用的样本不是同一批——
      这正是 §13.3 把两件事分开的意思，也避免把"均值对比"误当成"稀有度读数"。
    """
    n = ctrl.size
    # ---- 第一步：Welch t + TOST
    t, p_welch = stats.ttest_ind(trat, ctrl, equal_var=False)
    diff = trat.mean() - ctrl.mean()
    se = np.sqrt(trat.var(ddof=1) / trat.size + ctrl.var(ddof=1) / ctrl.size)
    lo_d, hi_d = diff - 1.96 * se, diff + 1.96 * se
    equiv = (lo_d > -DELTA_EQ) and (hi_d < DELTA_EQ)
    # ---- 第二步：尾概率（经验计数）+ Clopper–Pearson
    k = int(np.count_nonzero(ctrl >= e_obs))
    p_hat = (k + 0.5) / (n + 1.0)            # 平滑，避免 p=0
    p_lo, p_hi = stats.beta.ppf([0.025, 0.975], k + 0.5, n - k + 0.5)
    I_hat = -np.log2(max(p_hat, 1e-300))
    I_lo = -np.log2(max(p_hi, 1e-300))       # 端点交换
    step1 = (p_welch <= ALPHA0)
    return {
        "step1_sig": bool(step1),
        "equiv": bool(equiv),
        "p_welch": float(p_welch),
        "I_hat": float(I_hat),
        "I_lo": float(I_lo),
        "entry_strict": bool(step1 and (not equiv) and I_lo >= iota_bit),
        "entry_loose": bool(step1 and (not equiv) and I_hat >= iota_bit),
    }


def true_I(d):
    p = stats.norm.sf(d)
    return float(-np.log2(p))


def main() -> dict:
    n_grid = [20, 50, 100, 200, 500]
    d_grid = [0.0, 0.2, 0.5, 0.8, 1.2, 2.0]
    n_rep = 2000

    rows = []
    for n in n_grid:
        for d in d_grid:
            hits_s = hits_l = hits_skip_point = hits_skip_lo = 0
            I_hat_entry = []
            for _ in range(n_rep):
                ctrl = rng.standard_normal(n)
                trat = rng.standard_normal(n) + d
                e_obs = float(rng.standard_normal() + d)   # 一次观测到的效果
                r = analyze(ctrl, trat, e_obs)
                hits_s += r["entry_strict"]
                hits_l += r["entry_loose"]
                # 跳过第一步：只看 3 bit 这一条（点估计）／只看下界
                hits_skip_point += (r["I_hat"] >= 3.0)
                hits_skip_lo += (r["I_lo"] >= 3.0)
                if r["entry_strict"]:
                    I_hat_entry.append(r["I_hat"])
            rows.append({
                "n": n, "d": d, "I_true": true_I(d),
                "rate_strict": hits_s / n_rep,
                "rate_loose": hits_l / n_rep,
                "rate_skip_point": hits_skip_point / n_rep,
                "rate_skip_lowerbound": hits_skip_lo / n_rep,
                "mean_I_given_entry": float(np.mean(I_hat_entry)) if I_hat_entry else float("nan"),
                "n_rep": n_rep,
            })

    # ---- 判据
    res = {}
    null = [r for r in rows if r["d"] == 0.0]
    max_fpr = max(r["rate_strict"] for r in null)
    res["T1"] = K.verdict(
        max_fpr <= 0.05,
        pass_text="d=0（零效应）时全网格的严格准入率最大 %.4f ≤0.05" % max_fpr,
        fail_text="d=0 时准入率最大 %.4f >0.05" % max_fpr,
        detail={"by_n": {r["n"]: r["rate_strict"] for r in null}},
    )
    skip_rate = float(np.mean([r["rate_skip_point"] for r in null]))
    res["T2"] = K.verdict(
        0.09 <= skip_rate <= 0.16,
        pass_text="只用「$I\\ge3$ bit」这一条（不看下界）时，零效应世界的准入率为 %.3f，"
                  "落在 1/8 附近——§13.6 说「那句话想拦却没拦住」，这就是它的准确数值："
                  "把 3 bit 当门槛，等于放进 12.5%% 的噪声" % skip_rate,
        fail_text="只用 3 bit 门槛时零效应准入率为 %.3f，明显偏离 1/8" % skip_rate,
        detail={"skip_rate_point": skip_rate,
                "skip_rate_lowerbound": float(np.mean([r["rate_skip_lowerbound"] for r in null])),
                "by_n": {r["n"]: r["rate_skip_point"] for r in null}},
    )

    # T3：winner's curse
    bias = []
    for r in rows:
        if np.isfinite(r["mean_I_given_entry"]) and r["I_true"] < 3.0:
            bias.append((r["n"], r["d"], r["mean_I_given_entry"] - r["I_true"]))
    worst = max(bias, key=lambda x: x[2]) if bias else None
    small = [b for b in bias if b[0] == 20]
    res["T3"] = K.verdict(
        (worst is not None) and (worst[2] > 1.0),
        pass_text="条件偏差（报出值 − 真值）在 n=20 时最大 %.2f bit >1.0——"
                  "准入之后的 $I$ 是选择性样本，不能当无偏读数用" % (max(b[2] for b in small) if small else 0),
        fail_text="条件偏差始终 ≤1.0 bit",
        detail={"max_bias": worst, "n20": small},
    )

    # T4：达到"95% 下界 ≥3"所需的样本量
    d3 = 1.15                    # sf(1.15)≈0.1251 → I_true≈3.0
    r3 = next((r for r in rows if r["d"] == 0.8 and abs(true_I(0.8) - 2.9) < 0.3), None)
    # 直接对 I_true≈3 的效应做小规模扫描
    t4 = []
    for n in [50, 100, 200, 300, 500, 800, 1200]:
        hit = 0
        for _ in range(600):
            ctrl = rng.standard_normal(n)
            trat = rng.standard_normal(n) + d3
            e_obs = float(rng.standard_normal() + d3)
            hit += analyze(ctrl, trat, e_obs)["entry_strict"]
        t4.append({"n": n, "power_strict": hit / 600})
    n_needed = next((x["n"] for x in t4 if x["power_strict"] >= 0.8), None)

    # 等效门限：在各 n 上找使严格读法功效达 0.8 的最小 d，报它对应的 I_true
    eff = []
    for n in [50, 100, 200, 500]:
        pw, ds = [], [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
        for d in ds:
            hit = 0
            for _ in range(400):
                ctrl = rng.standard_normal(n)
                trat = rng.standard_normal(n) + d
                e_obs = float(rng.standard_normal() + d)
                hit += analyze(ctrl, trat, e_obs)["entry_strict"]
            pw.append(hit / 400)
        d80 = None
        for i in range(1, len(ds)):
            if pw[i - 1] < 0.8 <= pw[i]:
                t = (0.8 - pw[i - 1]) / (pw[i] - pw[i - 1])
                d80 = ds[i - 1] + t * (ds[i] - ds[i - 1])
                break
        if d80 is None and pw[-1] >= 0.8:
            d80 = ds[0]
        eff.append({"n": n, "d_grid": ds, "power": pw,
                    "d80": d80, "I_eff": (true_I(d80) if d80 is not None else None)})

    res["T4"] = K.verdict(
        n_needed is not None and n_needed <= 500,
        pass_text="真值 $I\\approx3$ bit 时，使「95%% 下界 ≥3」通过率 ≥0.8 的最小 $n=%s$"
                  % n_needed,
        fail_text="真值 3 bit 时，$n$ 到 1200 仍达不到 80%% 通过率（扫描：%s）。"
                  "等效门限（使严读法功效达 0.8 所需的真值 $I$）为 %s——"
                  "「下界 ≥3」这一读法的实际门槛远高于 3 bit"
                  % (", ".join("%d:%.2f" % (x["n"], x["power_strict"]) for x in t4),
                     "、".join("n=%d→%.1f bit" % (e["n"], e["I_eff"])
                               for e in eff if e["I_eff"] is not None)),
        detail={"scan": t4, "n_needed": n_needed, "effective_threshold": eff},
    )
    # T5：宽读法的功效
    wide = []
    for n in [50, 100, 200]:
        hit = 0
        for _ in range(600):
            ctrl = rng.standard_normal(n)
            trat = rng.standard_normal(n) + d3
            e_obs = float(rng.standard_normal() + d3)
            rr = analyze(ctrl, trat, e_obs)
            hit += rr["entry_loose"]
        wide.append({"n": n, "power_loose": hit / 600})
    res["T5"] = K.verdict(
        (wide[1]["power_loose"] - next(x["power_strict"] for x in t4 if x["n"] == 100)) > 0.3,
        pass_text="两种读法功效差 >0.3：n=100 时宽读法 %.2f，严读法 %.2f"
                  % (wide[1]["power_loose"],
                     next(x["power_strict"] for x in t4 if x["n"] == 100)),
        fail_text="两种读法功效差 ≤0.3",
        detail={"wide": wide},
    )
    # T6：等价带换算（L1 恒等式）
    err = []
    for q, claim in ((0.05, 0.14), (0.10, 0.29)):
        lo = 1 - np.log2(1 + 2 * q)
        hi = 1 - np.log2(1 - 2 * q)
        err.append(abs((hi - lo) / 2 - claim))
    res["T6"] = K.verdict(
        max(err) < 0.01,
        pass_text="§13.3.3(3) 的等价带换算与文中「1±0.14／1±0.29 bit」一致（误差 %.4f bit）"
                  % max(err),
        fail_text="换算与文中数值不符（误差 %.4f）" % max(err),
        detail={"err": err},
    )
    # T7：等价判定与"稀有度很高"的联合事件
    joint = 0
    tot = 0
    for _ in range(4000):
        ctrl = rng.standard_normal(100)
        trat = rng.standard_normal(100) * 0.2     # 真等价
        e_obs = float(rng.standard_normal() * 0.2)
        r = analyze(ctrl, trat, e_obs)
        tot += 1
        joint += (r["equiv"] and r["I_hat"] >= 3.0)
    res["T7"] = K.verdict(
        joint / tot < 0.01,
        pass_text="判为「等价」却报出 $I\\ge3$ bit 的联合事件频率 %.4f <0.01——两条判据不冲突"
                  % (joint / tot),
        fail_text="联合事件频率 %.4f ≥0.01" % (joint / tot),
        detail={"rate": joint / tot},
    )

    K.save_csv("M4_twostep.csv", rows)
    try:
        figure_f6(rows, t4)
    except Exception as e:
        print("figure error", e)

    out = {"module": "M4", "env": K.env_record(), "results": res,
           "rows": rows, "t4_scan": t4}
    K.save_json("M4_twostep.json", out)
    return out


def figure_f6(rows, t4):
    import matplotlib.pyplot as plt
    K.setup_mpl()
    fig, axes = plt.subplots(1, 3, figsize=(11.4, 3.3))

    # (a) 零效应下的准入率：跳不跳过第一步
    ax = axes[0]
    ns = sorted({r["n"] for r in rows})
    null = sorted([r for r in rows if r["d"] == 0.0], key=lambda r: r["n"])
    ax.plot(ns, [r["rate_skip_point"] for r in null], "o-", color=K.C["bad"],
            label="Step 1 skipped")
    ax.plot(ns, [r["rate_strict"] for r in null], "s-", color=K.C["ok"],
            label="Both steps (strict reading)")
    ax.axhline(1 / 8, color=K.C["bad"], ls="--", lw=0.9)
    ax.text(500, 1 / 8 + 0.006, "1/8", color=K.C["bad"], fontsize=8, ha="right")
    ax.axhline(0.05, color=K.C["grey"], ls=":", lw=0.9)
    ax.text(22, 0.056, "$$\\alpha_0=0.05$$".replace("$$","$"), color=K.C["grey"], fontsize=7.5)
    ax.set_xscale("log")
    ax.set_xticks(ns)
    ax.set_xticklabels([str(v) for v in ns])
    ax.minorticks_off()
    ax.set_xlabel("Sample size per arm $n$")
    ax.set_ylabel("Entry rate under zero effect")
    ax.set_title("(a) Using 3 bit alone admits 1/8 noise")
    ax.legend(loc="center right", frameon=False)

    # (b) 功效曲线：严/宽两种读法
    ax = axes[1]
    ax.plot([x["n"] for x in t4], [x["power_strict"] for x in t4], "o-",
            color=K.C["ok"], label="Strict reading: 95% lower bound ≥3")
    ax.axhline(0.8, color=K.C["grey"], ls="--", lw=0.9)
    ax.set_xscale("log")
    ax.set_xlabel("Sample size per arm $n$ (true $I\\approx3$ bit)")
    ax.set_ylabel("Entry rate (power)")
    ax.set_title("(b) Samples needed for a bound of 3")
    ax.set_ylim(0, 1.02)
    ax.legend(loc="lower right", frameon=False)
    for x in t4:
        ax.annotate("%.2f" % x["power_strict"], (x["n"], x["power_strict"]),
                    textcoords="offset points", xytext=(0, 6), fontsize=6.5,
                    ha="center", color=K.C["ink"])

    # (c) winner's curse：准入后报出的 I vs 真值
    ax = axes[2]
    for i, n in enumerate([20, 100, 500]):
        rr = [r for r in rows if r["n"] == n and np.isfinite(r["mean_I_given_entry"])
              and r["d"] > 0]
        if rr:
            ax.plot([r["I_true"] for r in rr], [r["mean_I_given_entry"] for r in rr],
                    "o-", color=K.PALETTE[i], label="$n=%d$" % n)
    lim = [0, 7]
    ax.plot(lim, lim, ls=":", color=K.C["grey"], lw=1.0)
    ax.set_xlim(lim)
    ax.set_ylim(lim)
    ax.set_xlabel("True $I_{causal}$ (bit)")
    ax.set_ylabel("Mean reported $I$ among admitted samples")
    ax.set_title("(c) Admitted $I$ exceeds the truth")
    ax.legend(loc="lower right", frameon=False)
    ax.text(0.03, 0.06, "Small-sample ceiling\n$I\\leq\\log_2 2(n+1)$ (5.4 bit at $n=20$)",
            transform=ax.transAxes, fontsize=7.2, color=K.C["grey"])
    return K.savefig(fig, "F6_两步检验的操作特性")


if __name__ == "__main__":
    o = main()
    for r in o["rows"]:
        print(f"n={r['n']:4d} d={r['d']:.1f} Itrue={r['I_true']:5.2f} "
              f"P_strict={r['rate_strict']:.3f} P_loose={r['rate_loose']:.3f} "
              f"P_skip={r['rate_skip_point']:.3f} E[I|entry]={r['mean_I_given_entry']:.2f}")
    for kk in ("T1", "T2", "T3", "T4", "T5", "T6", "T7"):
        print(f"{kk:3s} {o['results'][kk]['verdict']:3s} | {o['results'][kk]['criterion']}")
