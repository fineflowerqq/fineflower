# -*- coding: utf-8 -*-
"""
M3　存续分辨率与粗化顺序（RIF §12.9.3 规则一、HR-4、HR-6）

被检句
------
HR-6「成本上升则分辨率粗化，且先丢 $\\lvert\\delta_r\\rvert$ 最小的区分。」
§12.9.3 (ii)「区分只在**区分带来的存续增益大于解码代价折算的存续当量**时才保留。」

模型
----
$K=24$ 个有序线索，响应库 6 个动作。真值收益 $U(\\xi,a)$ 由 3 个"动作台阶"决定；
此外每个线索有一个**刺激强度** $s(\\xi)$（随机游走），区分 $i$ 的信号强度取 $\\lvert\\Delta s\\rvert$。
刻意把台阶放在 $\\lvert\\Delta s\\rvert$ 最小的位置上——否则"按 $\\delta_r$ 排序"与"按信号强度排序"
不可区分，检验没有分辨力（预注册 R0 前置条件）。

两个策略
--------
**最优**：对给定 $\\lambda$ 用一维 DP 精确求最大化 $\\mathbb E[\\mathrm{sv}]-\\lambda\\sum_{\\text{cuts}}c_i$ 的划分。
**字面规则**：照 HR-6 所说，按 $\\lvert\\delta_r\\rvert$ 升序丢区分，用平均代价 $\\bar c$ 折算阈值
（该规则不认识 $c_i$，只能用平均值）。测它的**后悔值**随代价异质度 $\\sigma_c$ 的变化。
"""
from __future__ import annotations

import numpy as np
from scipy import stats

import common as K

MOD = 3
rng = K.rng_for(MOD)

K_CUES = 24
N_ACT = 6
N_REGIME = 3


# ---------------------------------------------------------------------------
# 世界生成
# ---------------------------------------------------------------------------


def build_world(rng_local, sigma_c=0.0, c0=1.0):
    # 刺激强度：随机游走
    steps = rng_local.normal(0, 1.0, size=K_CUES)
    s = np.cumsum(steps)
    ds = np.abs(np.diff(s))                      # 23 个区分处的信号强度

    # 把 12 个"动作台阶"放在 |Δs| 最小的位置上（制造反相关），
    # 每处阶跃的动作幅度随机取 1..3，使各区分的增益有不同的量级
    order = np.argsort(ds)
    cuts_true = sorted(order[:12].tolist())
    delta_a = rng_local.integers(1, 4, size=len(cuts_true))

    a_true = np.zeros(K_CUES, dtype=int)
    cur = 0
    k = 0
    for i in range(1, K_CUES):
        if (i - 1) in cuts_true:
            cur = (cur + int(delta_a[k])) % N_ACT
            k += 1
        a_true[i] = cur

    # 收益矩阵：正确动作给 +1，错误动作按"混淆代价"给扣分
    U = np.zeros((K_CUES, N_ACT))
    for xi in range(K_CUES):
        for a in range(N_ACT):
            U[xi, a] = 1.0 if a == a_true[xi] else -0.35 * min(abs(a - a_true[xi]),
                                                              N_ACT - abs(a - a_true[xi]))
    # 每个 cut 的解码代价
    z = rng_local.uniform(-1, 1, size=K_CUES - 1)
    c = c0 * (1.0 + sigma_c * z)
    c = np.maximum(c, 0.05)
    return {"U": U, "s": s, "ds": ds, "cuts_true": cuts_true, "c": c,
            "a_true": a_true}


def block_value(U, i, j):
    """块 [i, j) 的最优单动作期望收益。"""
    seg = U[i:j]
    return float(np.max(seg.mean(axis=0)))


def block_table(U):
    """预计算所有块的取值（DP 与字面规则共用，避免重复计算）。"""
    n = U.shape[0]
    B = np.zeros((n + 1, n + 1))
    for i in range(n):
        for j in range(i + 1, n + 1):
            B[i, j] = float(np.max(U[i:j].mean(axis=0)))
    return B


def dp_optimal(B, c, lam):
    """一维 DP：返回 (最优分值, 使用的 cut 布尔数组)。"""
    n = B.shape[0] - 1
    dp = np.full(n + 1, -np.inf)
    back = np.zeros(n + 1, dtype=int)
    dp[0] = 0.0
    for j in range(1, n + 1):
        best, bi = -np.inf, 0
        for i in range(j):
            cost = lam * c[i - 1] if i > 0 else 0.0
            val = dp[i] + (j - i) / n * B[i, j] - cost
            if val > best:
                best, bi = val, i
        dp[j], back[j] = best, bi
    cuts = np.zeros(n - 1, dtype=bool)
    j = n
    while j > 0:
        i = back[j]
        if i > 0:
            cuts[i - 1] = True
        j = i
    return float(dp[n]), cuts


def gains(B):
    """每个 cut 的存续增益，**与 DP 同量纲**：

    保留该区分 = 两个单元素块各占 1/n 权重；合并 = 一个二元素块占 2/n。
    $\\delta_r^{(i)}=(B_{i,i+1}+B_{i+1,i+2}-2B_{i,i+2})/n$。
    """
    n = B.shape[0] - 1
    g = np.zeros(n - 1)
    for i in range(n - 1):
        g[i] = (B[i, i + 1] + B[i + 1, i + 2] - 2.0 * B[i, i + 2]) / n
    return g


def literal_policy_score(B, g, c, lam):
    """照 HR-6 的字面规则：按 |δ_r| 升序丢区分，用平均代价折算阈值。

    规则不认识 c_i，只能用 c̄ 判断"该保留哪些区分"；但世界照实收 Σ_{用到的 cut} c_i。
    """
    n = B.shape[0] - 1
    cbar = float(np.mean(c))
    keep = g > lam * cbar          # 保留该区分
    score = 0.0
    i = 0
    while i < n:
        j = i + 1
        while j < n and not keep[j - 1]:    # 没有 cut 就继续合并
            j += 1
        score += (j - i) / n * B[i, j]
        if j < n:
            score -= lam * c[j - 1]         # 该处确实存在一个 cut
        i = j
    return float(score)


def optimal_score(U, c, lam):
    return dp_optimal(U, c, lam)[0]


# ---------------------------------------------------------------------------
# 主实验
# ---------------------------------------------------------------------------


def one_world(rng_local, sigma_c):
    W = build_world(rng_local, sigma_c=sigma_c)
    U, c, ds = W["U"], W["c"], W["ds"]
    B = block_table(U)
    g = gains(B)

    lam_grid = np.logspace(-4, 2.2, 120)
    # 最优路径
    opt_scores, opt_cuts = [], []
    for lam in lam_grid:
        sc, cuts = dp_optimal(B, c, lam)
        opt_scores.append(sc)
        opt_cuts.append(cuts)
    opt_scores = np.array(opt_scores)

    # 不可加性：全部区分都在时的联合收益 vs 两两增益之和
    sc_all, _ = dp_optimal(B, c, 0.0)
    joint = sc_all - B[0, B.shape[0] - 1]
    pair_sum = float(np.sum(g))

    # 字面规则的代价（仅报告，不进判据）
    lit_scores = np.array([literal_policy_score(B, g, c, lam) for lam in lam_grid])
    denom = np.maximum(np.abs(opt_scores - B[0, B.shape[0] - 1]), 1e-9)
    regret = np.maximum(opt_scores - lit_scores, 0) / denom

    # 粗化顺序：每个 cut 最后一次出现时的 λ（越大 = 越晚被丢 = 越重要）
    lam_crit = np.zeros(g.size)
    for i in range(g.size):
        present = np.array([oc[i] for oc in opt_cuts])
        lam_crit[i] = lam_grid[present].max() if present.any() else 1e-6
    return {
        "spearman_gain_S": float(stats.spearmanr(g, ds).statistic),
        "kendall_gain_order_vs_drops": float(stats.kendalltau(lam_crit, g).statistic),
        "kendall_S_order_vs_drops": float(stats.kendalltau(lam_crit, ds).statistic),
        "kendall_gc_order_vs_drops": float(stats.kendalltau(lam_crit, g / c).statistic),
        "nonadditivity": float(joint / max(pair_sum, 1e-9)),
        "joint_gain": float(joint),
        "pair_sum": float(pair_sum),
        "regret_mid": float(np.median(regret[(lam_grid > 1e-3) & (lam_grid < 10)])),
        "lam_crit": lam_crit, "g": g, "ds": ds,
    }


def main() -> dict:
    sigma_grid = [0.0, 0.1, 0.2, 0.3, 0.4, 0.6, 0.8, 1.0]
    n_rep = 40
    rows = []
    for sc in sigma_grid:
        rr = []
        for _ in range(n_rep):
            r2 = np.random.default_rng(rng.integers(0, 2 ** 31))
            rr.append(one_world(r2, sc))
        rows.append({
            "sigma_c": sc,
            "spearman_gain_S_med": float(np.median([x["spearman_gain_S"] for x in rr])),
            "kendall_gain_med": float(np.median([x["kendall_gain_order_vs_drops"] for x in rr])),
            "kendall_S_med": float(np.median([x["kendall_S_order_vs_drops"] for x in rr])),
            "kendall_gc_med": float(np.median([x["kendall_gc_order_vs_drops"] for x in rr])),
            "nonadditivity_med": float(np.median([x["nonadditivity"] for x in rr])),
            "regret_med": float(np.median([x["regret_mid"] for x in rr])),
            "n_rep": n_rep,
        })

    res = {}
    # R0：检验力前置——增益与信号强度必须反相关，否则两种排序分不开
    r0_ok = all(r["spearman_gain_S_med"] <= -0.5 for r in rows)
    res["R0"] = K.verdict(
        r0_ok,
        pass_text="所有 σ_c 下 rank(|δ_r|) 与 rank(S) 的 Spearman 中位数 ≤−0.5"
                  "（最小 %.2f）——两种排序确实可分" % min(r["spearman_gain_S_med"] for r in rows),
        fail_text="存在 σ_c 使两种排序不可分（Spearman > −0.5），该格不计入 R1",
        detail={r["sigma_c"]: r["spearman_gain_S_med"] for r in rows},
    )
    # R1（HR-4）：阈值移动顺序跟 |δ_r| 还是跟信号强度
    res["R1"] = K.verdict(
        all(r["kendall_gain_med"] >= 0.6 and (r["kendall_gain_med"] - r["kendall_S_med"]) >= 0.2
            for r in rows),
        pass_text="粗化顺序与 |δ_r| 的 Kendall τ 中位数均 ≥0.6，且比与信号强度的 τ 高 ≥0.2"
                  "——HR-4 的方向成立",
        fail_text="某些格上与 |δ_r| 的一致性不足 0.6，或与信号强度的差 <0.2（见下表）",
        detail=rows,
    )
    # R2（σ_c=0 时顺序应严格复现 |δ_r|）
    r2row = next(r for r in rows if r["sigma_c"] == 0.0)
    res["R2"] = K.verdict(
        r2row["kendall_gain_med"] >= 0.95,
        pass_text="σ_c=0 时粗化顺序与 |δ_r| 的 Kendall τ = %.3f ≥0.95——代价同质时"
                  "「先丢 |δ_r| 最小」与最优顺序一致" % r2row["kendall_gain_med"],
        fail_text="σ_c=0 时 τ 只有 %.3f <0.95——即便代价同质，「按 |δ_r| 排序」也不等于最优顺序"
                  % r2row["kendall_gain_med"],
        detail={"tau_gain": r2row["kendall_gain_med"]},
    )
    # R3（异质代价下顺序应改跟 δ_r/c）
    big = next(r for r in rows if r["sigma_c"] == 1.0)
    res["R3"] = K.verdict(
        (big["kendall_gc_med"] - big["kendall_gain_med"]) >= 0.2,
        pass_text="σ_c=1.0 时顺序与 δ_r/c 的 τ 比与 δ_r 的高 ≥0.2（%.2f vs %.2f）"
                  % (big["kendall_gc_med"], big["kendall_gain_med"]),
        fail_text="σ_c=1.0 时最优顺序与 δ_r/c 的 τ = %.2f，比与 δ_r 的 τ = %.2f 高 %.2f："
                  "代价异质后，决定先后的是**增益与代价之比**，不是增益本身。"
                  "HR-6 的「先丢 |δ_r| 最小」需要前提：解码代价对各区分近似相同"
                  % (big["kendall_gc_med"], big["kendall_gain_med"],
                     big["kendall_gc_med"] - big["kendall_gain_med"]),
        detail={"rows": rows},
    )
    # R4（新增，探索性）：δ_r 的可加性
    nonadd = [r["nonadditivity_med"] for r in rows]
    res["R4"] = K.verdict(
        max(nonadd) <= 1.5,
        pass_text="联合收益 ÷ 两两增益之和 ≤1.5：区分近似可加，排序规则有依据",
        fail_text="联合收益是两两增益之和的 %.1f 倍（σ_c=0）～%.1f 倍（σ_c=1.0）："
                  "δ_r 严重不可加。区分很少时单个区分几乎没有价值，只有成组保留才兑现收益。"
                  "以两两 δ_r 排序的任何规则都不可能与最优顺序一致"
                  % (nonadd[0], nonadd[-1]),
        detail={"nonadditivity": dict(zip(sigma_grid, nonadd)),
                "regret": {r["sigma_c"]: r["regret_med"] for r in rows}},
    )

    K.save_csv("M3_resolution.csv", rows)

    # 插图：一个 σ_c=0.8 的世界的粗化顺序 + 后悔曲线
    ex_rng = np.random.default_rng(20261103)
    ex = one_world(ex_rng, 0.8)
    try:
        figure_f5(rows, ex)
    except Exception as e:
        print("figure error", e)

    out = {"module": "M3", "env": K.env_record(), "results": res,
           "rows": rows, "example": {k: ex[k] for k in
                                     ("g", "ds", "lam_crit", "regret_mid",
                                      "nonadditivity")}}
    K.save_json("M3_resolution.json", out)
    return out


def figure_f5(rows, ex):
    import matplotlib.pyplot as plt
    K.setup_mpl()
    fig, axes = plt.subplots(1, 3, figsize=(11.4, 3.3))

    # (a) 三种排序与最优丢序的一致性
    ax = axes[0]
    sc = [r["sigma_c"] for r in rows]
    ax.plot(sc, [r["kendall_gain_med"] for r in rows], "o-", color=K.C["env"],
            label="by $|\\delta_r|$")
    ax.plot(sc, [r["kendall_gc_med"] for r in rows], "s--", color=K.C["ok"],
            mfc="white", label="by $\\delta_r/c$")
    ax.plot(sc, [r["kendall_S_med"] for r in rows], "^:", color=K.C["max"],
            label="by signal strength $S$")
    ax.axhline(0.0, color=K.C["grey"], lw=0.8)
    ax.set_xlabel("Decoding-cost heterogeneity $\\sigma_c/\\bar c$")
    ax.set_ylabel("Kendall $\\tau$ vs. optimal drop order")
    ax.set_title("(a) $\\delta_r/c$ sets the drop order")
    ax.legend(loc="center left", frameon=False)

    # (b) 两个维度被设计成反相关（检验力前提）
    ax = axes[1]
    g, ds = np.asarray(ex["g"]), np.asarray(ex["ds"])
    ax.scatter(ds, g, s=26, color=K.C["env"], alpha=0.85)
    ax.set_xlabel("Signal strength $S$ (stimulus gap between adjacent cues)")
    ax.set_ylabel("Persistence gain $\\delta_r$")
    ax.set_title("(b) Anti-correlation is the precondition for test power")
    rho = stats.spearmanr(g, ds).statistic
    ax.text(0.04, 0.90, "Spearman ρ = %.2f" % rho, transform=ax.transAxes,
            fontsize=8, color=K.C["ink"])

    # (c) 一个世界：临界 λ 与 |δ_r|
    ax = axes[2]
    lc = np.maximum(np.asarray(ex["lam_crit"]), 1e-4)
    ax.scatter(np.log10(lc), g, s=30, color=K.C["acc"], alpha=0.85)
    ax.set_xlabel("$\\log_{10}\\lambda$ (critical value for loss)")
    ax.set_ylabel("$\\delta_r$")
    ax.set_title("(c) Larger gains are dropped later")
    tau = stats.kendalltau(lc, g).statistic
    ax.text(0.04, 0.90, "Kendall τ = %.2f" % tau, transform=ax.transAxes,
            fontsize=8, color=K.C["ink"])
    return K.savefig(fig, "F5_粗化顺序由增益代价比决定")


if __name__ == "__main__":
    o = main()
    for r in o["rows"]:
        print(f"sigma_c={r['sigma_c']:.1f}  rho(g,S)={r['spearman_gain_S_med']:+.2f}  "
              f"tau(gain)={r['kendall_gain_med']:+.2f}  tau(S)={r['kendall_S_med']:+.2f}  "
              f"regret={r['regret_med']:.4f}")
    for kk in ("R0", "R1", "R2", "R3", "R4"):
        print(f"{kk:3s} {o['results'][kk]['verdict']:3s} | {o['results'][kk]['criterion']}")
