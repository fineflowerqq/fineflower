# -*- coding: utf-8 -*-
"""
M1　稀有度协议的三条数值断言（RIF §12.1、§12.2、§12.1.1）

被检句
------
Q1  §12.1「尾概率服从 (0,1) 均匀分布……中位数恰为 1 bit，均值 1/ln2≈1.44 bit。
     背景存在并列值或统计量离散时均匀性失效，须按实际分布重算。」
Q2  §12.2「末行 k≈50 处……尾概率形式约 0.9 bit，接近「中位数 1 bit」这个基准。」
Q3  §12.1.1「按栖息背景算出 0.3 bit 的读数，按协议基线可能算出 12 bit。」
     规则 3「不得把两种口径下算出的稀有度相减、排序……」

本模块只做 L1（定义与代数恒等式）核对，不做外推。
"""
from __future__ import annotations

import numpy as np
from scipy import stats

import common as K

MOD = 1
rng = K.rng_for(MOD)


# ---------------------------------------------------------------------------
# 工具：给定离散支撑与概率，精确算出尾概率与稀有度的分布
# ---------------------------------------------------------------------------


def discrete_tail_stats(probs: np.ndarray) -> dict:
    """probs 按支撑升序给出。返回尾概率（≥ 约定）诱导分布的精确统计量。

    注意：离散支撑下中位数可能不唯一。这里给出**中位数区间的两个端点**
    （下端 = 使 F≥1/2 且 S≥1/2 成立的最小值；上端 = 最大值），
    而不是硬选一个约定 —— 见报告 M1 的"判据失效"一节。
    """
    p = np.asarray(probs, dtype=float)
    p = p / p.sum()
    # 上尾：P(X' >= v_i)
    tail = np.cumsum(p[::-1])[::-1]
    I = -np.log2(tail)
    order = np.argsort(I)
    I_sorted = I[order]
    w = p[order]
    cw = np.cumsum(w)          # F(I_i)
    sw = np.cumsum(w[::-1])[::-1]  # S(I_i) = P(I >= I_i)
    ok = (cw >= 0.5 - 1e-12) & (sw >= 0.5 - 1e-12)
    med_lo = float(I_sorted[ok].min()) if ok.any() else float("nan")
    med_hi = float(I_sorted[ok].max()) if ok.any() else float("nan")
    return {
        "E_p_tail": float(np.sum(p * tail)),
        "sum_p2": float(np.sum(p ** 2)),
        "mean_I": float(np.sum(p * I)),
        "median_I_lo": med_lo,
        "median_I_hi": med_hi,
        "min_p_tail": float(tail.min()),
        "n_support": int(p.size),
    }


# ---------------------------------------------------------------------------
# Q1a　连续背景
# ---------------------------------------------------------------------------


def q1a(n: int = 200_000) -> dict:
    out = {}
    for name, dist in [
        ("normal", stats.norm(0, 1)),
        ("expon", stats.expon(1)),
        ("uniform", stats.uniform(0, 1)),
    ]:
        x = dist.rvs(size=n, random_state=rng)
        # 已知分布时，尾概率是解析的（与"从样本估"不同，这里检验的是定义本身）
        p = dist.sf(x)
        p = np.clip(p, 1e-300, 1.0)
        I = -np.log2(p)
        ks = stats.kstest(p, "uniform")
        out[name] = {
            "ks_stat": float(ks.statistic),
            "ks_p": float(ks.pvalue),
            "median_I": float(np.median(I)),
            "mean_I": float(np.mean(I)),
            "n": n,
        }
    return out


# ---------------------------------------------------------------------------
# Q1b　均匀离散
# ---------------------------------------------------------------------------


def q1b(ks=(2, 4, 8, 16, 64, 256, 1024), n_mc: int = 60_000) -> list[dict]:
    rows = []
    for k in ks:
        probs = np.full(k, 1.0 / k)
        ex = discrete_tail_stats(probs)
        # 蒙特卡洛复核（真实抽样）
        draw = rng.integers(0, k, size=n_mc)
        tail = np.cumsum(probs[::-1])[::-1][draw]
        I = -np.log2(tail)
        # 闭式：均匀 K 支撑下 E[I] = log2 K − (1/K)·log2(K!)
        closed = np.log2(k) - np.sum(np.log2(np.arange(1, k + 1))) / k
        rows.append({
            "K": k,
            "exact_median_I_lo": ex["median_I_lo"],
            "exact_median_I_hi": ex["median_I_hi"],
            "exact_mean_I": ex["mean_I"],
            "closed_form_mean_I": float(closed),
            "closed_form_err": float(abs(closed - ex["mean_I"])),
            "mc_mean_I": float(np.mean(I)),
            "E_p_tail": ex["E_p_tail"],
            "sum_p2": ex["sum_p2"],
            "identity_err": float(abs(ex["E_p_tail"] - 0.5 * (1 + ex["sum_p2"]))),
        })
    return rows


# ---------------------------------------------------------------------------
# Q1c / Q2　非均匀离散：二项分布（正是 §12.2 的读数「黑格个数」）
# ---------------------------------------------------------------------------


def q1c(n_mc: int = 200_000) -> dict:
    N, q = 100, 0.5
    k = np.arange(N + 1)
    p = stats.binom.pmf(k, N, q)
    ex = discrete_tail_stats(p)

    # 蒙特卡洛：随机抽一个读数，用解析尾概率
    draw = rng.choice(k, size=n_mc, p=p)
    tail = np.cumsum(p[::-1])[::-1][draw]
    I = -np.log2(tail)

    # §12.2 表里的四行
    rows = []
    for kk in (0, 1, 2, 50):
        p_discrete = p[kk]
        p_tail_lower = stats.binom.cdf(kk, N, q)
        rows.append({
            "k": int(kk),
            "I_discrete": float(-np.log2(p_discrete)),
            "I_tail_lower": float(-np.log2(max(p_tail_lower, 1e-300))),
            "book_says": {0: "100", 1: "≈93.4", 2: "≈87.7", 50: "≈3.65 / 0.9"}[kk],
        })

    return {
        "exact": ex,
        "mc_median_I": float(np.median(I)),
        "mc_mean_I": float(np.mean(I)),
        "implied_median_from_mode": float(-np.log2(stats.binom.cdf(50, N, q))),
        "median_unique": bool(abs(ex["median_I_lo"] - ex["median_I_hi"]) < 1e-12),
        "book_rows": rows,
        "n_support": int(np.count_nonzero(p > 0)),
    }


# ---------------------------------------------------------------------------
# Q1d　量化导致的并列
# ---------------------------------------------------------------------------


def q1d(deltas=(1e-3, 1e-2, 1e-1, 0.25, 0.5, 1.0, 2.0), n: int = 200_000) -> list[dict]:
    rows = []
    base = rng.standard_normal(n)
    for d in deltas:
        # 量化到步长 d，并在同一格内视为并列
        xq = np.round(base / d) * d
        # 用解析尾概率：P(X' >= v) 对量化后的分布（受并列影响）
        vals, counts = np.unique(xq, return_counts=True)
        probs = counts / counts.sum()
        ex = discrete_tail_stats(probs)
        rows.append({
            "delta": d,
            "n_levels": int(vals.size),
            "median_I_lo": ex["median_I_lo"],
            "median_I_hi": ex["median_I_hi"],
            "mean_I": ex["mean_I"],
            "E_p_tail": ex["E_p_tail"],
            "sum_p2": ex["sum_p2"],
            "median_shift_vs_continuous": float(ex["median_I_hi"] - 1.0),
            "abs_median_shift": float(abs(ex["median_I_hi"] - 1.0)),
        })
    return rows


# ---------------------------------------------------------------------------
# Q3　两个背景：量级差 + 排序反转
# ---------------------------------------------------------------------------


def q3() -> dict:
    # (i) 日光：同一读数「光谱落在太阳黑体 ± 容差内」，可区分光谱格 K=4096
    K_spec = 4096
    I_day_env = -np.log2(0.90)
    I_day_max = np.log2(K_spec)  # 等概率基线，该格概率 1/K
    # (ii) 完美晶体：12 格全 0
    I_xtal_env = -np.log2(0.05)
    I_xtal_max = 12.0

    # (iii) 排序反转：4 个读数，栖息背景按频率，协议基线按「粗读数覆盖多少个细状态」
    p_env = np.array([0.45, 0.35, 0.15, 0.05])
    fine_sizes = np.array([1, 1, 4, 2])          # 每个粗读数覆盖的细状态数
    p_max = fine_sizes / fine_sizes.sum()
    I_env = -np.log2(p_env)
    I_max = -np.log2(p_max)
    order_env = np.argsort(-I_env)
    order_max = np.argsort(-I_max)

    # 稳健性：env 概率扰动 ±10%，fine_sizes 不变
    n_pert = 2000
    keep = 0
    for _ in range(n_pert):
        pert = p_env * (1 + rng.uniform(-0.1, 0.1, size=4))
        pert = pert / pert.sum()
        if np.array_equal(np.argsort(-(-np.log2(pert))), order_env) and \
           np.array_equal(np.argsort(-I_max), order_max):
            # 反转条件：两种排序不完全一致
            if not np.array_equal(np.argsort(-(-np.log2(pert))), order_max):
                keep += 1
    return {
        "daylight": {"I_env": float(I_day_env), "I_max": float(I_day_max),
                     "ratio": float(2 ** (I_day_max - I_day_env))},
        "crystal": {"I_env": float(I_xtal_env), "I_max": float(I_xtal_max),
                    "ratio": float(2 ** (I_xtal_max - I_xtal_env))},
        "inversion": {
            "p_env": p_env.tolist(),
            "p_max": p_max.tolist(),
            "I_env": I_env.tolist(),
            "I_max": I_max.tolist(),
            "order_env": order_env.tolist(),
            "order_max": order_max.tolist(),
            "reversed": bool(not np.array_equal(order_env, order_max)),
            "robust_frac": keep / n_pert,
        },
    }


# ---------------------------------------------------------------------------
# 作图
# ---------------------------------------------------------------------------


def figure_f1(q1a_res, q1b_rows, q1c_res, q1d_rows):
    import matplotlib.pyplot as plt
    K.setup_mpl()

    fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.3))

    # (a) 尾概率的累积分布：连续=对角线；离散落在对角线下方
    ax = axes[0]
    tt = np.linspace(0, 1, 400)
    ax.plot(tt, tt, color=K.C["env"], lw=2.0, label="Continuous background (= diagonal)")
    N_, q_ = 100, 0.5
    k = np.arange(N_ + 1)
    pk = stats.binom.pmf(k, N_, q_)
    tail = np.cumsum(pk[::-1])[::-1]
    order = np.argsort(tail)
    ax.step(tail[order], np.cumsum(pk[order]), where="post", color=K.C["max"],
            lw=1.6, label="Discrete: Bin(100, 1/2)")
    Kq = 8
    tq = np.array([(Kq - j) / Kq for j in range(Kq)])
    oq = np.argsort(tq)
    ax.step(tq[oq], np.cumsum(np.full(Kq, 1 / Kq)[oq]), where="post",
            color=K.C["warn"], lw=1.4, ls="--", label="Discrete: uniform $K=8$")
    ax.plot([0, 1], [0, 1], color=K.C["grey"], lw=0.8, ls=":", zorder=0)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.set_xlabel("Tail probability $p_{\\mathrm{tail}}$")
    ax.set_ylabel("Cumulative probability $F(p_{\\mathrm{tail}})$")
    ax.set_title("(a) Discreteness inflates $p_{\\mathrm{tail}}$ stochastically")
    ax.legend(loc="upper left", frameon=False, fontsize=7.6)
    ax.annotate("Curves lie below the diagonal\n$\\Rightarrow\\ E[p_{\\mathrm{tail}}]=(1+\\Sigma p^2)/2>1/2$",
                xy=(0.66, 0.40), xytext=(0.26, 0.14), fontsize=7.6, color=K.C["ink"],
                arrowprops=dict(arrowstyle="->", lw=0.8, color=K.C["grey"]))

    # (b) 均匀离散：均值随 K 的收敛（中位数不唯一，只画区间端点）
    ax = axes[1]
    Ks = [r["K"] for r in q1b_rows]
    ax.fill_between(Ks, [r["exact_median_I_lo"] for r in q1b_rows],
                    [r["exact_median_I_hi"] for r in q1b_rows],
                    color=K.C["env"], alpha=0.18, lw=0,
                    label="Uniform discrete: median interval")
    ax.plot(Ks, [r["exact_mean_I"] for r in q1b_rows], "s--", color=K.C["env"],
            mfc="white", label="Uniform discrete: mean (closed form)")
    ax.axhline(1.0, color=K.C["env"], lw=0.8, alpha=0.5)
    ax.axhline(1 / np.log(2), color=K.C["env"], lw=0.8, alpha=0.5)
    ax.axhline(q1c_res["exact"]["median_I_lo"], color=K.C["max"], lw=1.1, ls=":")
    ax.axhline(q1c_res["exact"]["mean_I"], color=K.C["max"], lw=1.1, ls="-.")
    ax.text(Ks[-1], q1c_res["exact"]["median_I_lo"] + 0.03, "Binomial: median %.3f" %
            q1c_res["exact"]["median_I_lo"], ha="right", fontsize=7.5, color=K.C["max"])
    ax.text(Ks[-1], q1c_res["exact"]["mean_I"] + 0.03, "Binomial: mean %.3f" %
            q1c_res["exact"]["mean_I"], ha="right", fontsize=7.5, color=K.C["max"])
    ax.set_xscale("log", base=2)
    ax.set_xlabel("Support size $K$")
    ax.set_ylabel("Rarity (bit)")
    ax.set_ylim(0.4, 1.6)
    ax.set_title("(b) The benchmark is the $K\\to\\infty$ limit")
    ax.legend(loc="lower right", frameon=False)

    # (c) 量化并列
    ax = axes[2]
    d = [r["delta"] for r in q1d_rows]
    ax.plot(d, [r["median_I_hi"] for r in q1d_rows], "o-", color=K.C["acc"],
            label="Median (upper interval end)")
    ax.plot(d, [r["mean_I"] for r in q1d_rows], "s--", color=K.C["warn"],
            mfc="white", label="Mean")
    ax.axhline(1.0, color=K.C["ink"], lw=0.8, ls="--", alpha=0.6)
    ax.set_xscale("log")
    ax.set_xlabel("Quantization step $\\Delta$ (in SD units)")
    ax.set_ylabel("Rarity (bit)")
    ax.set_title("(c) Ties bias rarity downward")
    ax.legend(loc="lower left", frameon=False)

    return K.savefig(fig, "F1_稀有度基准与离散偏移")


def figure_f2(q3):
    import matplotlib.pyplot as plt
    K.setup_mpl()
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.4),
                             gridspec_kw={"width_ratios": [1, 1.15]})

    # (a) 两个具名算例：同读数、两口径
    ax = axes[0]
    cases = [("Daylight\n(diurnal holder)", q3["daylight"]),
             ("Perfect crystal\n(12 cells all 0)", q3["crystal"])]
    ys = np.arange(len(cases))[::-1]
    for y, (name, d) in zip(ys, cases):
        ax.plot([d["I_env"], d["I_max"]], [y, y], color=K.C["grey"], lw=2.2, zorder=1)
        ax.scatter([d["I_env"]], [y], s=70, color=K.C["env"], zorder=3,
                   label="$B^{\\mathrm{env}}$ habitat background" if y == ys[0] else None)
        ax.scatter([d["I_max"]], [y], s=70, color=K.C["max"], marker="s", zorder=3,
                   label="$B^{\\max}$ protocol baseline" if y == ys[0] else None)
        ax.annotate("×%.0f" % d["ratio"],
                    xy=((d["I_env"] + d["I_max"]) / 2, y + 0.16), ha="center",
                    fontsize=8, color=K.C["ink"])
        ax.text(d["I_env"], y - 0.26, "%.2f" % d["I_env"], ha="center", fontsize=7.5,
                color=K.C["env"])
        ax.text(d["I_max"], y - 0.26, "%.2f" % d["I_max"], ha="center", fontsize=7.5,
                color=K.C["max"])
    ax.set_yticks(ys)
    ax.set_yticklabels([c[0] for c in cases])
    ax.set_xlim(-0.6, 13.6)
    ax.set_xlabel("Rarity $I$ (bit)")
    ax.set_title("(a) Same readout, two backgrounds")
    ax.legend(loc="upper right", frameon=False)
    ax.set_ylim(-0.6, 1.95)

    # (b) 排序反转（同侧标签去重叠）
    ax = axes[1]
    inv = q3["inversion"]
    Ie, Im = np.array(inv["I_env"]), np.array(inv["I_max"])
    labels = ["Readout A", "Readout B", "Readout C", "Readout D"]
    for i in range(4):
        ax.plot([0, 1], [Ie[i], Im[i]], "-o", color=K.PALETTE[i], ms=5, lw=1.5)
    for side, yv, xlab, ha in ((-0.07, Ie, -0.07, "right"), (1.07, Im, 1.07, "left")):
        yv = np.asarray(yv, dtype=float)
        ordr = np.argsort(yv)
        ypos = yv[ordr].copy()
        for j in range(1, ypos.size):
            if ypos[j] - ypos[j - 1] < 0.22:
                ypos[j] = ypos[j - 1] + 0.22
        for j, idx in enumerate(ordr):
            ax.text(xlab, ypos[j], labels[idx], ha=ha, va="center", fontsize=8,
                    color=K.PALETTE[idx])
    ax.set_xlim(-0.38, 1.38)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["$B^{\\mathrm{env}}$", "$B^{\\max}$"])
    ax.set_ylabel("Rarity $I$ (bit)")
    ax.set_title("(b) Same readouts, opposite orderings under the two conventions")
    ax.grid(axis="x", visible=False)

    return K.savefig(fig, "F2_两种背景的量级差与排序反转")


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------


def main() -> dict:
    a = q1a()
    b = q1b()
    c = q1c()
    d = q1d()
    e = q3()

    # ---------------- 判据 ----------------
    res = {"Q1a": {}, "Q1b": {}, "Q1c": {}, "Q1d": {}, "Q2": {}, "Q3a": {}, "Q3b": {}}

    ks_ok = all(r["ks_p"] > 0.01 for r in a.values())
    med_ok = all(0.99 <= r["median_I"] <= 1.01 for r in a.values())
    mean_ok = all(1.42 <= r["mean_I"] <= 1.46 for r in a.values())
    res["Q1a"] = K.verdict(
        ks_ok and med_ok and mean_ok,
        pass_text="连续背景下尾概率均匀（KS p>0.01）；中位数∈[0.99,1.01]，均值∈[1.42,1.46]",
        fail_text="连续背景下的均匀性/中位数/均值有一项越界",
        detail={"by_dist": a},
    )

    # ---- Q1b：原判据假设中位数唯一；离散支撑下中位数是区间（见报告"判据失效"披露）。
    # 修正判据：基准是 K→∞ 的极限，检验其收敛性。
    mean_small = next(r["exact_mean_I"] for r in b if r["K"] == 8)
    mean_big = next(r["exact_mean_I"] for r in b if r["K"] == 1024)
    converged = abs(mean_big - 1 / np.log(2)) < 0.01
    far_at_small = mean_small < 1.15
    closed_ok = all(r["closed_form_err"] < 1e-12 for r in b)
    ident_ok = all(r["identity_err"] < 1e-12 for r in b)
    res["Q1b"] = K.verdict(
        converged and far_at_small and closed_ok and ident_ok,
        pass_text="1/ln2 是 K→∞ 的极限：K=1024 时均值 %.3f（距 1.4427 <0.01），K=8 时仅 %.3f；"
                  "闭式 E[I]=log2K−(1/K)log2(K!) 命中（误差<1e-12），"
                  "E[p_tail]=(1+Σp²)/2 恒等式命中" % (mean_big, mean_small),
        fail_text="均值未表现出「小 K 偏低、大 K 收敛」的模式，或闭式/恒等式不成立",
        detail={"note": "原预注册判据 Q1b 的中位数口径在离散支撑下不唯一，判据作废；"
                        "此处为修正判据（详见 02_仿真报告_B.md §3.2 的改动披露）",
                "rows": b},
    )

    c_med = c["exact"]["median_I_lo"]
    c_mean = c["exact"]["mean_I"]
    res["Q1c"] = K.verdict(
        (c_med < 0.97) or (c_mean < 1.35),
        pass_text="非均匀离散（Bin(100,1/2)）下中位数 %.3f bit（唯一）或均值 %.3f bit，"
                  "低于 1 bit 基准——离散偏移存在，且对非等概率支撑才显著" % (c_med, c_mean),
        fail_text="非均匀离散下中位数与均值都未跌出基准，离散偏移可忽略",
        detail={
            "exact": c["exact"],
            "mc_median_I": c["mc_median_I"],
            "mc_mean_I": c["mc_mean_I"],
            "median_unique": c["median_unique"],
            "identity_E_p_tail": 0.5 * (1 + c["exact"]["sum_p2"]),
            "identity_check": abs(c["exact"]["E_p_tail"] - 0.5 * (1 + c["exact"]["sum_p2"])),
        },
    )

    # ---- Q1d：原判据的符号约定写错（偏移应取绝对值），此处修正并披露
    abs_shifts = [r["abs_median_shift"] for r in d]
    mono = all(np.diff(abs_shifts) >= -0.005)
    res["Q1d"] = K.verdict(
        mono and max(abs_shifts) > 0.05,
        pass_text="量化并列使中位数偏移（绝对值）随 Δ 单调增大，Δ=2σ 时达 %.3f bit (>0.05)"
                  % max(abs_shifts),
        fail_text="偏移非单调或最大偏移 ≤0.05 bit",
        detail={"note": "原预注册判据把带符号偏移当成单调增，符号约定写错；"
                        "此处改用绝对偏移（详见 02_仿真报告_B.md §3.2 的改动披露）",
                "rows": d},
    )

    # Q2：由精确值判断「0.9 bit」是否由离散性解释
    mode_I = c["implied_median_from_mode"]
    med_I = c["exact"]["median_I_lo"]
    res["Q2"] = K.verdict(
        abs(mode_I - med_I) < 0.05 and abs(mode_I - 0.9) < 0.05,
        pass_text="k=50 的尾概率读数 %.3f bit 与二项离散下的中位数 %.3f bit 一致（差 %.3f），"
                  "故「0.9 接近 1 bit 基准」实为**离散偏移后的中位数**，不是基准本身"
                  % (mode_I, med_I, abs(mode_I - med_I)),
        fail_text="k=50 处读数与离散中位数不一致，0.9 另有来源",
        detail={"k50_tail_I": mode_I, "discrete_median_I": med_I,
                "median_unique": c["median_unique"],
                "book_table": c["book_rows"]},
    )

    res["Q3a"] = K.verdict(
        e["daylight"]["ratio"] >= 10 and e["crystal"]["ratio"] >= 10,
        pass_text="两个具名算例的跨口径比分别为 ×%.0f 与 ×%.0f，均 ≥10 倍"
                  % (e["daylight"]["ratio"], e["crystal"]["ratio"]),
        fail_text="跨口径比不足一个数量级",
        detail=e,
    )
    res["Q3b"] = K.verdict(
        e["inversion"]["reversed"] and e["inversion"]["robust_frac"] >= 0.95,
        pass_text="存在排序反转，且 ±10%% 扰动下仍反转的比例 %.3f ≥0.95"
                  % e["inversion"]["robust_frac"],
        fail_text="无反转，或反转在扰动下不稳定",
        detail={"order_env": e["inversion"]["order_env"],
                "order_max": e["inversion"]["order_max"],
                "robust_frac": e["inversion"]["robust_frac"]},
    )

    fig1 = figure_f1(a, b, c, d)
    fig2 = figure_f2(e)
    res["figures"] = [str(fig1.name), str(fig2.name)]

    # CSV
    rows = []
    for r in b:
        rows.append({"table": "Q1b_uniform_discrete", **r})
    for r in d:
        rows.append({"table": "Q1d_quantization", **r})
    for r in c["book_rows"]:
        rows.append({"table": "Q2_book_table", **{k: v for k, v in r.items()
                                                  if k != "book_says"},
                     "book_says": r["book_says"]})
    K.save_csv("M1_rarity.csv", rows)

    out = {
        "module": "M1",
        "env": K.env_record(),
        "results": res,
        "raw": {"Q1a": a, "Q1b": b, "Q1c": c, "Q1d": d, "Q3": e},
    }
    K.save_json("M1_rarity.json", out)
    return out


if __name__ == "__main__":
    o = main()
    for kk in ("Q1a", "Q1b", "Q1c", "Q1d", "Q2", "Q3a", "Q3b"):
        r = o["results"][kk]
        print(f"{kk:5s} {r['verdict']:3s} | {r['criterion']}")
