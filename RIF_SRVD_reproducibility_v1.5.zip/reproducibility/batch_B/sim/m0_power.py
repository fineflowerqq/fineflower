# -*- coding: utf-8 -*-
"""
M0（上）　反例重建：0.0 版「附录 X 五重递归数值仿真」为什么不可证伪

被检对象
--------
`00_0.0版/中文_卷Ⅰ_0.0.md` 第 2260–2274 行，及其引用的式 (5.1†)–(5.6†)（同书 877–941 行）。
v1.59 已删除该附录；本模块把它重建，目的不是翻旧账，而是给"什么叫不可证伪"一个**可计算**的判据，
并据此给出本补丁每一条判据都必须满足的底线。

四个判据
--------
X0  可复现性审计：附录参数块是否绑定了它引用的方程所需的全部符号？
X1  结论是否为代数恒等式的改写（对任意轨迹都成立 ⇒ 不能失败）？
X2  结论在参数空间中的成立域有多大？可失败的域是否只是个刀锋？
X3  结论是否依赖 (5.5) 的具体函数形式？换一个单调递减形式是否照样成立？
"""
from __future__ import annotations

import numpy as np

import common as K

MOD = 0
rng = K.rng_for(MOD)

# ---------------------------------------------------------------------------
# 附录 X 报告的参数（原样抄录，不增不改）
# ---------------------------------------------------------------------------
REPORTED = dict(I0=1.0, T0=10.0, E_base=1.0, k=0.5, lam=0.08, gamma0=1.2,
                Vmax=10.0, Ethresh=5.0, delta=5.0, dt=0.2, steps=150)

# 附录 X 引用的方程里出现、但参数块从未赋值的符号
UNBOUND = [
    ("chi", "χ", "(5.1)(5.6) 耦合强度", "决定 I 与 T_pred 的反馈强度；无它无法推进任何一步"),
    ("V0", "V_0", "(5.2)(5.3) 初值", "无初值不能积分"),
    ("E_structure", "E_structure", "(5.4)(5.5)", "参数块只给 E_base，未说明二者是否同一符号"),
    ("k_s", "k_s", "(5.5)", "代谢敏感系数；参数块的 k=0.5 已被 (5.2) 的 r_v=kV 占用"),
    ("T_min", "T_min", "(5.6)", "视界下限；它决定 E_flow 的上确界"),
    ("I_struct", "I_struct", "(5.4)", "结构信息"),
    ("T_static", "T_static", "(5.4)", "静态存续时间"),
    ("E_causal", "E_causal", "(5.4)", "因果处理能耗"),
]

# ---------------------------------------------------------------------------
# X1/X2　把"先于"化归为阈值比较
# ---------------------------------------------------------------------------


def collapse_criterion_T(T0: float, frac: float = 0.3) -> float:
    """附录 X 把「T_pred 坍缩」取为 T_pred < 3.0（T0=10 的 30%）。"""
    return frac * T0


def breach_threshold_T(k_s: float, E_struct: float, E_thresh: float) -> float:
    """E_flow = E_struct + k_s/T_pred > E_thresh  ⟺  T_pred < k_s/(E_thresh-E_struct)。"""
    denom = E_thresh - E_struct
    if denom <= 0:
        return np.inf
    return k_s / denom


def claim1_holds(k_s: float, E_struct: float, E_thresh: float, T0: float,
                 frac: float = 0.3) -> bool:
    """「T_pred 先坍缩、E_flow 后破阈」⇔ 破阈阈值比坍缩阈值更小。

    T_pred 沿轨迹单调下降（(5.6) 在 χV 增大时下降），故两个事件谁先发生
    只由两个阈值的大小决定，与轨迹快慢、与 χ 无关。
    """
    tau = breach_threshold_T(k_s, E_struct, E_thresh)
    return tau < collapse_criterion_T(T0, frac)


def audit() -> dict:
    """X0：参数块 vs 方程需求的覆盖审计。"""
    return {
        "reported": REPORTED,
        "unbound": [{"sym": b, "latex": l, "where": w, "why": y} for b, l, w, y in UNBOUND],
        "n_unbound": len(UNBOUND),
        "note_cross_ref": "附录 X 另称「V^virt 采用 α_eff=2.5 计算」，"
                          "但 α_eff 只出现在 v1.59 的 (5.12)/(5.13) 一组方程里，"
                          "不在附录自称实现的 (5.1†)–(5.6†) 中——引用了另一套模型的状态量。",
    }


def x1_vacuity() -> dict:
    """X1：用报告的 k_s=0.5、E_thresh=5、E_base=1 检查破阈通道是否可达。"""
    k_s = 0.5
    E_struct = REPORTED["E_base"]
    E_thresh = REPORTED["Ethresh"]
    tau = breach_threshold_T(k_s, E_struct, E_thresh)
    T_coll = collapse_criterion_T(REPORTED["T0"])
    # E_flow 的上确界取决于 T_min；T_min 未报告
    # 破阈可达 ⟺ T_min < tau
    return {
        "k_s": k_s, "E_struct": E_struct, "E_thresh": E_thresh,
        "tau_breach": tau,
        "tau_collapse": T_coll,
        "max_E_flow_if_Tmin_ge_tau": E_struct + k_s / tau if tau > 0 else np.inf,
        "reachable_iff_Tmin_below": tau,
        "conclusion": (
            "以报告值计，E_flow 破阈要求 T_pred < %.3f s。而 (5.6†) 给出 T_pred ≥ T_min，"
            "T_min 从未赋值：若 T_min ≥ %.3f，损伤通道永不触发，"
            "「T_pred 先坍缩、E_flow 后破阈」对空集成立（vacuous）；"
            "若 T_min < %.3f，则 T_pred 必先经过 3.0，命题由单调性平凡成立。"
            "两条路都使该命题不能失败。"
            % (tau, tau, tau)
        ),
    }


def x2_region(k_s_grid=None, e_frac_grid=None) -> dict:
    """X2：在 (k_s, E_structure/E_thresh) 平面上画出「命题可失败」的域。"""
    if k_s_grid is None:
        k_s_grid = np.linspace(1e-3, 40, 400)
    if e_frac_grid is None:
        e_frac_grid = np.linspace(0.0, 0.999, 400)
    E_thresh = REPORTED["Ethresh"]
    T0 = REPORTED["T0"]
    T_coll = collapse_criterion_T(T0)
    hold = np.zeros((e_frac_grid.size, k_s_grid.size), dtype=bool)
    for i, f in enumerate(e_frac_grid):
        tau = np.where(E_thresh * (1 - f) > 0, k_s_grid / (E_thresh * (1 - f)), np.inf)
        hold[i] = tau < T_coll
    fail_frac = float(1.0 - hold.mean())
    # 可失败域的下边界：k_s* = T_coll * E_thresh * (1 - f)
    boundary_k = T_coll * E_thresh * (1 - e_frac_grid)
    # 报告的 k_s=0.5 时需要 E_structure 多高才可失败
    f_req = 1 - REPORTED["k"] / (T_coll * E_thresh)
    return {
        "hold": hold,
        "fail_frac_in_box": fail_frac,
        "e_frac_grid": e_frac_grid,
        "k_s_grid": k_s_grid,
        "boundary_k": boundary_k,
        "e_frac_needed_for_failure_at_reported_k_s": float(f_req),
        "E_struct_needed": float(f_req * E_thresh),
        "distance_to_threshold_frac": float(1 - f_req),
    }


def x3_functional_form() -> dict:
    """X3：把 (5.5) 换成任意单调递减形式，命题是否照样成立？"""
    E_struct, E_thresh = REPORTED["E_base"], REPORTED["Ethresh"]
    T0 = REPORTED["T0"]
    T_coll = collapse_criterion_T(T0)
    forms = {
        "反比 k_s/T（原式）": lambda T: 1.0 + 0.5 / T,
        "负幂 k_s/T^2": lambda T: 1.0 + 0.5 / T ** 2,
        "指数 exp(k_s/T)": lambda T: np.exp(0.05 / T),
        "仿射递减 6.5-0.35T": lambda T: 6.5 - 0.35 * T,
    }
    out = {}
    for name, f in forms.items():
        # 破阈阈值：解 f(T)=E_thresh
        Ts = np.linspace(1e-4, T0, 200000)
        vals = f(Ts)
        idx = np.where(vals > E_thresh)[0]
        tau = float(Ts[idx].max()) if idx.size else 0.0
        out[name] = {"tau_breach": tau, "claim_holds": bool(tau < T_coll)}
    return out


def figure_f3(audit_res, x2_res):
    import matplotlib.pyplot as plt
    K.setup_mpl()
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.6),
                             gridspec_kw={"width_ratios": [1.15, 1]})

    # (a) 成立域 / 可失败域
    ax = axes[0]
    ef = x2_res["e_frac_grid"]
    ks = x2_res["k_s_grid"]
    ax.contourf(ks, ef, x2_res["hold"].astype(float), levels=[0.5, 1.5],
                colors=[K.C["ok"]], alpha=0.30)
    ax.contourf(ks, ef, x2_res["hold"].astype(float), levels=[-0.5, 0.5],
                colors=[K.C["bad"]], alpha=0.18)
    ax.plot(x2_res["boundary_k"], ef, color=K.C["ink"], lw=1.4)
    ax.scatter([REPORTED["k"]], [REPORTED["E_base"] / REPORTED["Ethresh"]],
               s=60, color=K.C["max"], zorder=5, marker="D",
               label="Value reported by Appendix X")
    ax.axhline(1 - x2_res["distance_to_threshold_frac"], color=K.C["grey"], ls=":", lw=1)
    ax.set_xlim(0, 40)
    ax.set_ylim(0, 1)
    ax.set_xlabel("Metabolic sensitivity $k_s$ (J·s)")
    ax.set_ylabel("$E_{\\mathrm{structure}}/E_{\\mathrm{thresh}}$")
    ax.set_title("(a) The claim holds only in the green region; red is where it can fail")
    ax.text(21, 0.42, "Failure region\n($E_{\\mathrm{flow}}$ breaches first)", color=K.C["bad"],
            fontsize=8.5, ha="center")
    ax.text(3.0, 0.80, "Claim holds", color=K.C["ok"], fontsize=8.5)
    ax.legend(loc="lower left", frameon=False)
    ax.annotate("Reported point: $k_s$=0.5, $E/E_{th}$=0.2\n→ deep inside the green region, 0.767 from the boundary",
                xy=(0.5, 0.2), xytext=(8.0, 0.09), fontsize=7.4, color=K.C["ink"],
                arrowprops=dict(arrowstyle="->", lw=0.8, color=K.C["grey"]))

    # (b) E_flow 上确界 vs T_min
    ax = axes[1]
    Tmin = np.logspace(-3, 1, 400)
    Eflow_max = REPORTED["E_base"] + REPORTED["k"] / Tmin
    ax.plot(Tmin, Eflow_max, color=K.C["env"], lw=1.8)
    ax.axhline(REPORTED["Ethresh"], color=K.C["bad"], ls="--", lw=1.2,
               label="$E_{\\mathrm{thresh}}=5$")
    ax.axvspan(1e-3, 0.125, color=K.C["bad"], alpha=0.12)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Horizon floor $T_{\\min}$ (s, not reported)")
    ax.set_ylabel("Supremum of $E_{\\mathrm{flow}}$ (J)")
    ax.set_title("(b) The damage channel is reachable only when $T_{\\min}<0.125$ s")
    ax.axvline(0.125, color=K.C["ink"], ls=":", lw=0.9)
    ax.text(0.0015, 2.0, "Channel reachable", fontsize=8, color=K.C["bad"])
    ax.text(0.4, 2.0, "Channel never reachable\n(claim holds vacuously)", fontsize=8,
            color=K.C["ok"])
    ax.legend(loc="upper right", frameon=False)

    return K.savefig(fig, "F3_不可证伪性诊断_附录X")


def diagnosis(claimed: bool, *, text: str, detail: str = "") -> dict:
    """M0 用另一套判定语气：通过 = 诊断成立（不是"附录 X 成立"）。"""
    return {
        "verdict": "诊断成立" if claimed else "诊断不成立",
        "criterion": text,
        "is_pass": bool(claimed),
        "detail": detail,
    }


def main() -> dict:
    a = audit()
    x1 = x1_vacuity()
    x2 = x2_region()
    x3 = x3_functional_form()

    # 解析翻转点：k_s* = T_coll · (E_thresh − E_structure)
    T_coll = collapse_criterion_T(REPORTED["T0"])
    k_s_star = T_coll * (REPORTED["Ethresh"] - REPORTED["E_base"])
    # 数值翻转点：二分（claim1_holds 对 k_s 单调：小 k_s 成立）
    lo, hi = 1e-6, 1e3
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if claim1_holds(mid, REPORTED["E_base"], REPORTED["Ethresh"], REPORTED["T0"]):
            lo = mid
        else:
            hi = mid
    k_flip = 0.5 * (lo + hi)

    res = {}
    res["D1"] = diagnosis(
        a["n_unbound"] > 0,
        text="参数块未绑定 %d 个符号，附录 X 无法从出版物复现"
             % a["n_unbound"],
        detail=a,
    )
    res["D2"] = diagnosis(
        abs(k_flip - k_s_star) < 1e-9 and x1["tau_breach"] < 1.0,
        text="「全称命题」的真值域被解析地定出：成立 ⟺ $k_s<3(E_{\\mathrm{thresh}}-E_{\\mathrm{structure}})$"
             "；数值翻转点 $k_s^*$=%.3f 与解析值 %.3f 一致（差<1e-9）。"
             "报告点 $k_s$=0.5 在该域内，而参数盒中 %.1f%% 的区域在域外（命题为假）"
             % (k_flip, k_s_star, 100 * x2["fail_frac_in_box"]),
        detail={"k_flip_numeric": k_flip, "k_flip_analytic": k_s_star,
                "tau_breach_at_reported": x1["tau_breach"],
                "statement": x1["conclusion"]},
    )
    res["D3"] = diagnosis(
        x2["e_frac_needed_for_failure_at_reported_k_s"] > 0.9,
        text="在报告的 $k_s$=0.5 下，命题要失败需 $E_{\\mathrm{structure}}>%.3f$"
             "（阈值 %.0f 的 %.1f%%）——可失败域是一道窄缝，"
             "所以报告点附近「怎么试都成立」并不构成证据"
             % (x2["E_struct_needed"], REPORTED["Ethresh"],
                100 * x2["e_frac_needed_for_failure_at_reported_k_s"]),
        detail={"E_struct_needed": x2["E_struct_needed"],
                "frac_of_threshold": x2["e_frac_needed_for_failure_at_reported_k_s"]},
    )
    n_hold = sum(1 for v in x3.values() if v["claim_holds"])
    res["D4"] = diagnosis(
        n_hold >= 3,
        text="把 (5.5) 换成 4 种不同的单调递减形式，命题在 %d/4 种下照样成立"
             "——它不依赖 E_flow 的具体机制，只依赖「E_flow 随 T_pred 单调递减」。"
             "这比「参数条件」更弱：它是函数形式的同义反复" % n_hold,
        detail=x3,
    )

    fig = figure_f3(a, x2)
    res["figures"] = [str(fig.name)]

    out = {"module": "M0.1", "env": K.env_record(),
           "reading": "本模块的判定语是「诊断成立/不成立」，不是说附录 X 成立",
           "results": res,
           "raw": {"audit": a, "x1": x1,
                   "x2": {kk: x2[kk] for kk in x2 if kk not in ("hold",)},
                   "x3": x3}}
    K.save_json("M0_appendixX.json", out)
    return out


if __name__ == "__main__":
    o = main()
    for kk in ("D1", "D2", "D3", "D4"):
        r = o["results"][kk]
        print(f"{kk} {r['verdict']:6s} | {r['criterion']}")
