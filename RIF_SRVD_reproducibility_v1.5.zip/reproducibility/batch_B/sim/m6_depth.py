﻿# -*- coding: utf-8 -*-
"""
M6　规则深度与压缩增益的可测性（RIF §14.4／§14.6；卷Ⅱ §2.4／§6.2）

被检句
------
§14.6 第 3 步「在 $D$ 的描述语言中寻找最短的分层描述」；第 5 步「读出 $D_{\\mathrm{depth}}$」。
§14.4 压缩增益的单向判别力：$\\hat G_{\\mathrm{comp}}>0$ 可确认有规则；$\\approx0$ 不能确认无规则。
卷Ⅱ §2.4 标定检验：回归 $D^{\\mathrm{stat}}=a+b\\cdot\\#\\{\\mathcal T\\}$ 并检验 $b=1,a=1$。

做法
----
(1) 在**声明的规则库**内生成对象（深度 1–3 的异或叠加），用库内 MDL 反解深度；
(2) 用通用压缩器（zlib）的描述长度作对照，看长度能不能当深度的代理；
(3) 用库外规则（伪随机线性同余位置）测"库不覆盖时会不会系统性低估"；
(4) 四种瑕疵放置方式下算 $\\hat G_{\\mathrm{comp}}$ 的分布；
(5) 模拟一条演化史，回归 $b$。
"""
from __future__ import annotations

import lzma
import zlib

import numpy as np
from scipy import stats
from scipy.special import comb

import common as K

MOD = 6
rng = K.rng_for(MOD)

N = 32
NPIX = N * N


# ---------------------------------------------------------------------------
# 规则库
# ---------------------------------------------------------------------------


def _grid():
    r, c = np.mgrid[0:N, 0:N]
    return r, c


R_, C_ = _grid()


def prim_const0():
    return np.zeros((N, N), dtype=bool)


def prim_const1():
    return np.ones((N, N), dtype=bool)


def make_library():
    lib = []
    lib.append(("全 0", np.zeros((N, N), bool), 8))
    lib.append(("全 1", np.ones((N, N), bool), 8))
    for p in (2, 4, 8, 16):
        for ph in (0, 1):
            lib.append((f"竖条 p={p},φ={ph}", ((C_ + ph) % p) < p // 2, 16))
            lib.append((f"横条 p={p},φ={ph}", ((R_ + ph) % p) < p // 2, 16))
    for p in (2, 4, 8):
        lib.append((f"棋盘 p={p}", (((R_ // p) + (C_ // p)) % 2) == 0, 16))
    for bx in (2, 4, 8):
        lib.append((f"块 bx={bx}", ((R_ // bx) + (C_ // bx)) % 2 == 0, 16))
    for p in (2, 4, 8):
        lib.append((f"对角 p={p}", ((R_ + C_) % p) < p // 2, 16))
    return lib


LIB_FULL = make_library()


def _independent_subset(lib):
    """取一个 GF(2) 线性无关子集：这样"生成用了几条"与"最少几条"才一致。

    否则三条原始规则的异或可能恰好等于一条或两条的异或，真值深度就没有定义。
    """
    basis = []            # 已选向量的 echelon 形式
    keep = []
    for name, arr, cost in lib:
        v = arr.ravel().astype(np.uint8).copy()
        for b in basis:
            pivot = np.argmax(b)
            if v[pivot]:
                v ^= b
        if v.any():
            pivot = np.argmax(v)
            # 归一化到该 pivot 为 1 已是事实；插入并按 pivot 排序
            basis.append(v)
            basis.sort(key=lambda z: np.argmax(z))
            keep.append((name, arr, cost))
    return keep


LIB = _independent_subset(LIB_FULL)


# ---------------------------------------------------------------------------
# 压缩长度
# ---------------------------------------------------------------------------


def zlib_len(a: np.ndarray) -> int:
    return len(zlib.compress(np.packbits(a.ravel()).tobytes(), 9))


def lzma_len(a: np.ndarray) -> int:
    return len(lzma.compress(np.packbits(a.ravel()).tobytes(), preset=9))


# ---------------------------------------------------------------------------
# 库内 MDL 反解深度
# ---------------------------------------------------------------------------


def best_fit(obj, max_depth=3, tol=0.02):
    """返回 (深度, 描述长度, 规则名列表)。逐层枚举异或叠加。"""
    best = (0, zlib_len(obj) + 8 * NPIX, ["逐点记录"])   # 深度 0 的基线
    n = len(LIB)
    if np.mean(obj) < 0 or np.mean(obj) > 1:
        pass
    # 深度 1
    for i in range(n):
        cand = LIB[i][1]
        err = np.mean(cand != obj)
        if err <= tol:
            L = LIB[i][2]
            if L < best[1]:
                best = (1, L, [LIB[i][0]])
    # 深度 2
    for i in range(n):
        for j in range(i + 1, n):
            cand = LIB[i][1] ^ LIB[j][1]
            err = np.mean(cand != obj)
            if err <= tol:
                L = LIB[i][2] + LIB[j][2]
                if L < best[1]:
                    best = (2, L, [LIB[i][0], LIB[j][0]])
    # 深度 3（只在与已有深度相同的误差下才用；这里为速度只试一部分）
    if max_depth >= 3:
        idx = list(range(n))
        for i in idx:
            ci = LIB[i][1]
            for j in idx:
                if j <= i:
                    continue
                cij = ci ^ LIB[j][1]
                for k in idx:
                    if k <= j:
                        continue
                    cand = cij ^ LIB[k][1]
                    if np.mean(cand != obj) <= tol:
                        L = LIB[i][2] + LIB[j][2] + LIB[k][2]
                        if L < best[1]:
                            best = (3, L, [LIB[i][0], LIB[j][0], LIB[k][0]])
    return best


def sample_object(rng_local, depth):
    ids = rng_local.choice(len(LIB), size=depth, replace=False)
    obj = np.zeros((N, N), dtype=bool)
    for i in ids:
        obj ^= LIB[i][1]
    return obj, [LIB[i][0] for i in ids]


def pseudo_random_object(rng_local):
    """库外规则：位置由线性同余生成（描述极短，但 zlib 抓不到）。"""
    obj = np.zeros(NPIX, dtype=bool)
    state = int(rng_local.integers(1, 2 ** 16))
    a, c, m = 75, 74, 65537
    for _ in range(30):
        state = (a * state + c) % m
        obj[state % NPIX] = True
    return obj.reshape(N, N)


# ---------------------------------------------------------------------------
# 压缩增益
# ---------------------------------------------------------------------------


def g_comp(positions, Ntot, k):
    """按**声明的规则库**给位置列表求描述长度上界（bit）。

    库：① 常数差分（等距）＝参数几个比特；
        ② 常数差分＋不超过 ±2 的扰动＝参数＋k·log2(5)；
        ③ 逐点列表＝log2 C(N,k)（与随机放置同长，增益为 0）。
    """
    pos = np.sort(np.asarray(positions))
    dif = np.diff(pos, prepend=0)
    base = float(np.log2(float(comb(Ntot, k, exact=False))))
    if dif.size > 1 and np.all(dif[1:] == dif[1]):
        L = np.log2(Ntot) + np.log2(max(k, 2)) + 4
    elif dif.size > 1 and np.all(np.abs(dif[1:] - np.median(dif[1:])) <= 2):
        L = np.log2(Ntot) + np.log2(max(k, 2)) + 4 + k * np.log2(5)
    else:
        L = base
    return float(base - L)


def part_gcomp(n_rep=200, Ntot=400, k=20):
    out = {}
    for kind in ("周期", "等距+扰动", "随机", "伪随机规则"):
        vals = []
        for _ in range(n_rep):
            if kind == "周期":
                start = rng.integers(0, Ntot // k)
                pos = start + np.arange(k) * (Ntot // k)
            elif kind == "等距+扰动":
                start = rng.integers(0, 10)
                pos = start + np.arange(k) * (Ntot // k) + rng.integers(-1, 2, size=k)
            elif kind == "随机":
                pos = rng.choice(Ntot, size=k, replace=False)
            else:
                st = int(rng.integers(1, 2 ** 16))
                pos = []
                while len(pos) < k:
                    st = (75 * st + 74) % 65537
                    p = st % Ntot
                    if p not in pos:
                        pos.append(p)
                pos = np.array(pos)
            pos = np.clip(pos, 0, Ntot - 1)
            vals.append(g_comp(np.unique(pos), Ntot, len(np.unique(pos))))
        out[kind] = np.array(vals)
    return out


def part_calibration(n=200):
    """b=1 标定：每次跃迁新增 1–3 条独立规则。"""
    m = rng.integers(0, 7, size=n)
    incr = rng.choice([1, 2, 3], size=(n, 6), p=[0.5, 0.3, 0.2])
    dstat = np.ones(n)
    for i in range(n):
        tot = 1
        for j in range(m[i]):
            if rng.random() < 0.2:
                continue          # 只重组，不增条数
            tot += incr[i, j]
        dstat[i] = tot
    X = np.column_stack([np.ones(n), m])
    coef = np.linalg.lstsq(X, dstat, rcond=None)[0]
    resid = dstat - X @ coef
    s2 = resid @ resid / (n - 2)
    cov = s2 * np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(cov))
    t_b = (coef[1] - 1.0) / se[1]
    t_a = (coef[0] - 1.0) / se[0]
    return {"a": float(coef[0]), "b": float(coef[1]),
            "se_b": float(se[1]), "t_b_minus_1": float(t_b),
            "p_b_equals_1": float(2 * stats.t.sf(abs(t_b), n - 2)),
            "p_a_equals_1": float(2 * stats.t.sf(abs(t_a), n - 2))}


def main() -> dict:
    # ---- K1/K3：库内 vs 库外
    hit, tot, under = 0, 0, 0
    rows = []
    for depth in (1, 2, 3):
        for _ in range(25):
            obj, names = sample_object(rng, depth)
            d_hat, L_hat, picked = best_fit(obj, max_depth=3)
            rows.append({"true_depth": depth, "est_depth": d_hat,
                         "zlib_len": zlib_len(obj), "mdl_len": L_hat})
            tot += 1
            hit += (d_hat == depth)
            under += (d_hat < depth)
    k1 = hit / tot
    # 库外
    hit_o, tot_o, under_o = 0, 0, 0
    for _ in range(25):
        obj = pseudo_random_object(rng)
        d_hat, L_hat, picked = best_fit(obj, max_depth=3)
        rows.append({"true_depth": 1, "est_depth": d_hat,
                     "zlib_len": zlib_len(obj), "mdl_len": L_hat, "outside": True})
        tot_o += 1
        hit_o += (d_hat == 1)
        under_o += (d_hat < 1)

    # ---- K2：长度能不能当深度
    rr = [r for r in rows if not r.get("outside")]
    tau_len = float(stats.kendalltau([r["true_depth"] for r in rr],
                                     [r["zlib_len"] for r in rr]).statistic)
    # 纯随机对象：长度最大，深度应为 0
    rand_obj = rng.random((N, N)) < 0.5
    len_rand = zlib_len(rand_obj)
    len_max_lib = max(r["zlib_len"] for r in rr)
    d_rand, _, _ = best_fit(rand_obj, max_depth=1)

    # ---- K4–K6：G_comp
    gc = part_gcomp(n_rep=150)

    # ---- K7：标定
    cal = part_calibration()

    res = {}
    res["K1"] = K.verdict(
        k1 >= 0.85,
        pass_text="库内 MDL 的深度恢复率 %.2f ≥0.85" % k1,
        fail_text="库内 MDL 的深度恢复率只有 %.2f" % k1,
        detail={"rate": k1, "n": tot},
    )
    res["K2"] = K.verdict(
        (tau_len <= 0.8) and (d_rand == 0),
        pass_text="库内对象的长度与深度 Kendall τ=%.2f（≤0.8），且纯随机对象长度 %.0f 字节"
                  "（不短于库内最大值 %d）而深度为 %d——长度不能当深度的代理"
                  % (tau_len, len_rand, len_max_lib, int(d_rand)),
        fail_text="库内 τ=%.2f >0.8 且随机对象深度不为 0：同一语言内长度几乎可代替深度"
                  % tau_len,
        detail={"tau_len_depth": tau_len, "zlib_len_random": len_rand,
                "zlib_len_max_lib": len_max_lib, "mdl_depth_random": int(d_rand)},
    )
    res["K3"] = K.verdict(
        (hit_o / tot_o) <= 0.2 and under_o >= 0.8 * tot_o,
        pass_text="库外规则上库内 MDL 的恢复率 %.2f ≤0.20，且以低估为主（%d/%d）"
                  % (hit_o / tot_o, under_o, tot_o),
        fail_text="库外规则上恢复率 %.2f >0.20，或错误无方向" % (hit_o / tot_o),
        detail={"rate": hit_o / tot_o, "underestimate": under_o, "n": tot_o},
    )
    rate_pos = float(np.mean(gc["周期"] > 0)), float(np.mean(gc["等距+扰动"] > 0))
    res["K4"] = K.verdict(
        min(rate_pos) >= 0.95,
        pass_text="有规则的两型上 $\\hat G_{comp}>0$ 的比例 %.2f / %.2f，≥0.95"
                  % (rate_pos[0], rate_pos[1]),
        fail_text="有规则的两型上正增益比例只有 %.2f / %.2f" % rate_pos,
        detail={"periodic": rate_pos[0], "jitter": rate_pos[1]},
    )
    rate_rand = float(np.mean(gc["随机"] <= 0))
    res["K5"] = K.verdict(
        rate_rand >= 0.90,
        pass_text="随机放置上 $\\hat G_{comp}\\le0$ 的比例 %.2f ≥0.90" % rate_rand,
        fail_text="随机放置上非正比例只有 %.2f" % rate_rand,
        detail={"rate": rate_rand},
    )
    rate_pseudo = float(np.mean(gc["伪随机规则"] <= 0))
    res["K6"] = K.verdict(
        rate_pseudo >= 0.80,
        pass_text="伪随机规则（描述极短、压缩器抓不到）上 $\\hat G_{comp}\\le0$ 的比例 %.2f，"
                  "≥0.80——这正是「$\\approx0$ 不能确认无规则」的实证" % rate_pseudo,
        fail_text="伪随机规则上非正比例只有 %.2f：压缩器把它当成了无规则" % rate_pseudo,
        detail={"rate": rate_pseudo},
    )
    res["K7"] = K.verdict(
        (cal["p_b_equals_1"] < 1e-3) and (cal["b"] > 1.0),
        pass_text="回归给出 $\\hat b=%.2f$（远大于 1，$b=1$ 被拒，p=%.1e）——"
                  "卷Ⅱ的标定检验可执行、且在这个生成过程下会失败，"
                  "故 $D^{\\mathrm{dyn}}$ 只能作序数刻度" % (cal["b"], cal["p_b_equals_1"]),
        fail_text="回归给出 $\\hat b=%.2f$，$b=1$ 未被拒（p=%.2f）"
                  % (cal["b"], cal["p_b_equals_1"]),
        detail=cal,
    )

    K.save_csv("M6_depth.csv", rows)
    try:
        figure_f9(rows, gc, cal)
    except Exception as e:
        print("figure error", e)

    out = {"module": "M6", "env": K.env_record(), "results": res,
           "gcomp_summary": {k: {"mean": float(np.mean(v)), "median": float(np.median(v)),
                                 "frac_le0": float(np.mean(v <= 0))}
                             for k, v in gc.items()},
           "calibration": cal, "tau_len_depth": tau_len}
    K.save_json("M6_depth.json", out)
    return out


def figure_f9(rows, gc, cal):
    import matplotlib.pyplot as plt
    K.setup_mpl()
    fig, axes = plt.subplots(1, 3, figsize=(11.4, 3.3))

    # (a) 长度 vs 深度
    ax = axes[0]
    for d, col in zip((1, 2, 3), (K.C["env"], K.C["acc"], K.C["warn"])):
        sub = [r for r in rows if (not r.get("outside")) and r["true_depth"] == d]
        ax.scatter([r["true_depth"] for r in sub], [r["zlib_len"] for r in sub],
                   s=22, alpha=0.7, color=col, label="True depth %d" % d)
    out = [r for r in rows if r.get("outside")]
    ax.scatter([0.6] * len(out), [r["zlib_len"] for r in out], s=22, alpha=0.7,
               color=K.C["bad"], marker="x", label="Out-of-library rule")
    ax.set_xlabel("True rule depth")
    ax.set_ylabel("zlib description length (bytes)")
    ax.set_title("(a) Length is not a proxy for depth")
    ax.legend(loc="upper left", frameon=False, fontsize=7.2)

    # (b) G_comp 分布
    ax = axes[1]
    data = [gc["周期"], gc["等距+扰动"], gc["随机"], gc["伪随机规则"]]
    bp = ax.boxplot(data, tick_labels=["Periodic", "Equidistant\n+jitter", "Random", "Pseudo-random\nrule"],
                    patch_artist=True, widths=0.55)
    for patch, col in zip(bp["boxes"], (K.C["ok"], K.C["ok"], K.C["bad"], K.C["warn"])):
        patch.set_facecolor(col)
        patch.set_alpha(0.55)
    ax.axhline(0, color=K.C["ink"], lw=1.0, ls="--")
    ax.set_ylabel("$\\hat G_{\\mathrm{comp}}$ (bit)")
    ax.set_title("(b) $>0$ confirms a rule; $\\approx0$ cannot rule one out")

    # (c) 标定回归
    ax = axes[2]
    m = rng.integers(0, 7, size=200)
    incr = rng.choice([1, 2, 3], size=(200, 6), p=[0.5, 0.3, 0.2])
    dstat = np.ones(200)
    for i in range(200):
        tot = 1
        for j in range(m[i]):
            if rng.random() < 0.2:
                continue
            tot += incr[i, j]
        dstat[i] = tot
    jitter = rng.uniform(-0.15, 0.15, size=200)
    ax.scatter(m + jitter, dstat, s=18, alpha=0.55, color=K.C["env"])
    xx = np.linspace(0, 6, 10)
    ax.plot(xx, cal["a"] + cal["b"] * xx, color=K.C["bad"], lw=1.6,
            label="Fit $\\hat b=%.2f$" % cal["b"])
    ax.plot(xx, 1 + 1.0 * xx, color=K.C["ink"], lw=1.2, ls="--",
            label="Calibration hypothesis $b=1,a=1$")
    ax.set_xlabel("Number of transitions #T")
    ax.set_ylabel("$D^{\\mathrm{stat}}$")
    ax.set_title("(c) Calibration slope significantly exceeds 1")
    ax.legend(loc="upper left", frameon=False, fontsize=7.5)
    return K.savefig(fig, "F9_规则深度与压缩增益")


if __name__ == "__main__":
    o = main()
    for kk in ("K1", "K2", "K3", "K4", "K5", "K6", "K7"):
        print(f"{kk:3s} {o['results'][kk]['verdict']:3s} | {o['results'][kk]['criterion']}")
