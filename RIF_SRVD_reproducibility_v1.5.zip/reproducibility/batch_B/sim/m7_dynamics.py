﻿# -*- coding: utf-8 -*-
"""
M7　终局相图、带伤平衡的"移动目标"、双稳盆地（卷Ⅰ §5.1.2／§5.6／§5.19／§5.2.3）

被检句
------
§5.1.2 三分情形（归零型／降阶型／加速崩溃）与 $V^{*}=V_{\\max}(1-\\delta_{\\mathrm{dam}}/g_0)$。
§5.1.2 末「任一时变参数都会把不动点变成移动目标，此时只能作分段近似」——本模块把它量化。
§5.2.3 第（4）类「$\\chi<\\chi_{\\mathrm c}$ 时系统双稳……不能把 $\\chi<\\chi_{\\mathrm c}$ 一律当作路径一」。
"""
from __future__ import annotations

import numpy as np
from scipy import optimize

import common as K

MOD = 7
rng = K.rng_for(MOD)


# ---------------------------------------------------------------------------
# (a) 三分情形
# ---------------------------------------------------------------------------


def integrate_52(g0, delta, vmax=1.0, v0=0.5, t_end=500.0, dt=0.01, damage=True):
    v = v0
    for _ in range(int(t_end / dt)):
        g = g0 - (delta if damage else 0.0)
        dv = v * g0 * (1 - v / vmax) - (delta * v if damage else 0.0)
        v += dt * dv
        if v < 0:
            v = 0.0
            break
    return v


def classify_numeric(v, vmax=1.0, delta=0.0, g0=0.0):
    if v < 1e-3 * vmax:
        return "归零"
    if delta > 0 and g0 - delta > 0:
        vstar = vmax * (1 - delta / g0)
        if abs(v - vstar) / vstar < 1e-2:
            return "降阶"
    if delta == 0 and abs(v - vmax) / vmax < 1e-2:
        return "饱和"
    return "未定"


def classify_analytic(g0, delta, vmax=1.0):
    if delta <= 0:
        return "饱和" if g0 > 0 else "归零"
    if g0 <= 0:
        return "归零"
    if g0 > delta:
        return "降阶"
    return "归零"


def part_a():
    """相图用解析终局（损伤支）；分类一致性用**向量化**数值积分核对。"""
    g0_grid = np.linspace(-0.06, 0.12, 181)
    d_grid = np.linspace(0.0, 0.10, 141)
    G, D = np.meshgrid(g0_grid, d_grid, indexing="xy")
    with np.errstate(divide="ignore", invalid="ignore"):
        V_an = np.where((D > 0) & (G > D), 1.0 - D / np.maximum(G, 1e-12), 0.0)
        V_an = np.where(D <= 0, np.where(G > 0, 1.0, 0.0), V_an)

    # ---- 数值核对：随机抽 600 个格点，向量化积分
    m = 600
    g0s = rng.uniform(g0_grid[0], g0_grid[-1], m)
    ds = rng.uniform(0.0, d_grid[-1], m)
    v = np.full(m, 0.5)
    dt, nstep = 0.02, 20000
    for _ in range(nstep):
        dv = v * g0s * (1 - v) - ds * v
        v = np.maximum(v + dt * dv, 0.0)

    agree, tot, undecided = 0, 0, 0
    for i in range(m):
        c = classify_numeric(float(v[i]), delta=float(ds[i]), g0=float(g0s[i]))
        if c == "未定":
            undecided += 1
            continue
        if ds[i] > 0 and abs(g0s[i] - ds[i]) / ds[i] < 1e-2:
            continue                     # 临界面附近除外
        tot += 1
        agree += (c == classify_analytic(float(g0s[i]), float(ds[i])))
    return {"V": V_an, "g0_grid": g0_grid, "d_grid": d_grid,
            "agree": agree, "tot": tot, "undecided": undecided,
            "rate": agree / max(tot, 1),
            "numeric_v": v, "sample_g0": g0s, "sample_d": ds}


# ---------------------------------------------------------------------------
# (b) 移动目标：驱动率随时间漂移
# ---------------------------------------------------------------------------


def drift_max_dev(eps, g0_0=0.04, delta=0.02, vmax=1.0, v0=None, t_end=400.0, dt=0.01):
    """r_v(t)=g0_0(1+eps t)+γ0。冻结参数下的预测是常数 V*(0)。

    初值取在 V*(0) 上，这样量到的是**漂移造成的**偏离，不含初始瞬态。
    """
    v_star0 = vmax * (1 - delta / g0_0)
    v = v_star0 if v0 is None else v0
    dev = 0.0
    t = 0.0
    n = int(t_end / dt)
    for _ in range(n):
        g0 = g0_0 * (1 + eps * t)
        dv = v * (g0) * (1 - v / vmax) - delta * v
        v += dt * dv
        t += dt
        if v < 0:
            v = 0.0
        d = abs(v - v_star0) / v_star0
        dev = max(dev, d)
        if v <= 0:
            break
    return dev


def part_b():
    eps_grid = np.logspace(-5, -1, 25)
    devs = [drift_max_dev(e) for e in eps_grid]
    crit = None
    for i in range(1, len(eps_grid)):
        if devs[i - 1] < 0.10 <= devs[i]:
            t = (0.10 - devs[i - 1]) / (devs[i] - devs[i - 1])
            crit = float(np.exp(np.log(eps_grid[i - 1]) +
                                t * (np.log(eps_grid[i]) - np.log(eps_grid[i - 1]))))
            break
    g0 = 0.04
    return {"eps_grid": eps_grid, "devs": devs, "eps_star": crit,
            "eps_star_over_g0": (crit / g0 if crit else None)}


# ---------------------------------------------------------------------------
# (c) 双稳盆地（5.12）
# ---------------------------------------------------------------------------


def chi_c(alpha_eff, kappa):
    return (2.0 / ((alpha_eff - 2.0) * np.sqrt(kappa)) *
            ((alpha_eff - 2.0) / alpha_eff) ** (alpha_eff / 2.0))


def equilibria(alpha_eff, kappa, chi):
    f = lambda V: V ** 2 - kappa * (1 + chi * V) ** alpha_eff
    return f


def part_c(alpha_eff=3.0, kappa=1.0, chi_frac=0.9, n_grid=90,
           t_end=120.0, dt=0.02, blow=1e3):
    kc = chi_c(alpha_eff, kappa)
    chi = chi_frac * kc
    f = equilibria(alpha_eff, kappa, chi)
    xs = np.linspace(1e-6, 10, 20000)
    fs = np.array([f(x) for x in xs])
    idx = np.where(np.sign(fs[:-1]) * np.sign(fs[1:]) < 0)[0]
    roots = []
    for i in idx:
        try:
            roots.append(optimize.brentq(f, xs[i], xs[i + 1]))
        except Exception:
            pass
    v_low = min(roots) if roots else 1.0

    I_bas, tau_I, kI, gamma0 = 1.0, 1.0, 1.0, 1.0
    Ig = np.linspace(0.2, 8.0, n_grid)
    Vg = np.linspace(0.2, 22.0, n_grid)
    II, VV = np.meshgrid(Ig, Vg, indexing="xy")
    I = II.ravel().astype(float).copy()
    V = VV.ravel().astype(float).copy()
    blown = np.zeros_like(I, dtype=bool)
    alive = np.ones_like(I, dtype=bool)
    for _ in range(int(t_end / dt)):
        dI = (I_bas * (1 + chi * V) - I) / tau_I
        dV = kI * np.power(np.maximum(I, 1e-12), alpha_eff) / np.maximum(V, 1e-9) - gamma0 * V
        I = I + dt * dI
        V = V + dt * dV
        newb = alive & ((V > blow * max(v_low, 1e-6)) | (V > 1e4))
        blown |= newb
        alive &= ~newb
        alive &= (V > 1e-9)
        if not alive.any():
            break
    divmap = blown.reshape(n_grid, n_grid).astype(float)
    return {"kappa": kappa, "chi_c": float(kc), "chi": float(chi),
            "v_low": float(v_low), "div_frac": float(blown.mean()),
            "Ig": Ig, "Vg": Vg, "divmap": divmap}


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------


def main() -> dict:
    a = part_a()
    b = part_b()
    c = part_c()

    res = {}
    res["P1"] = K.verdict(
        a["rate"] >= 0.99,
        pass_text="数值终局与解析三情形一致率 %.4f（例外格 %d，未定格 %d）"
                  % (a["rate"], a["tot"] - a["agree"], a["undecided"]),
        fail_text="一致率只有 %.4f，低于 0.99" % a["rate"],
        detail={"rate": a["rate"], "n_tot": a["tot"],
                "n_disagree": a["tot"] - a["agree"]},
    )
    p2 = None
    for g0 in (0.04, 0.06, 0.08):
        for d in (0.01, 0.02, 0.03):
            if g0 <= d:
                continue
            vstar = 1 - d / g0
            v = integrate_52(g0, d)
            if p2 is None:
                p2 = abs(v - vstar) / vstar
    res["P2"] = K.verdict(
        p2 is not None and p2 < 1e-3,
        pass_text="带伤平衡 $V^{*}=V_{\\max}(1-\\delta/g_0)$ 的数值相对误差 %.2e <1e-3" % p2,
        fail_text="$V^{*}$ 误差 %.2e ≥1e-3" % p2,
        detail={"err": p2},
    )
    esg = b["eps_star_over_g0"]
    res["P3"] = K.verdict(
        esg is not None and 0.05 <= esg <= 0.5,
        pass_text="移动目标的临界漂移 $\\varepsilon^{*}/g_0=%.2f$，落在 [0.05,0.5]——"
                  "「分段近似」的适用条件是漂移率比净增长率小一个量级左右，不是小三个量级"
                  % esg if esg else "unavailable",
        fail_text=("临界漂移 $\\varepsilon^{*}/g_0=%s$，超出 [0.05,0.5]："
                   "「移动目标」的警戒线比预想%s" % (esg, "更宽" if (esg or 0) > 0.5 else "更窄"))
        if esg is not None else "无法定位",
        detail=b,
    )
    res["P4"] = K.verdict(
        0.05 <= c["div_frac"] <= 0.6,
        pass_text="$\\chi=0.9\\chi_{\\mathrm c}$ 时发散初值占 %.3f，落在 [0.05,0.6]——"
                  "「不能把 $\\chi<\\chi_{\\mathrm c}$ 一律当作路径一」确有实质内容"
                  % c["div_frac"],
        fail_text="发散初值占 %.3f，落在 [0.05,0.6] 之外" % c["div_frac"],
        detail={k: c[k] for k in ("kappa", "chi_c", "chi", "v_low", "div_frac")},
    )

    try:
        figure_f8(a, b, c)
    except Exception as e:
        print("figure error", e)

    out = {"module": "M7", "env": K.env_record(), "results": res,
           "part_a": {k: a[k] for k in ("agree", "tot", "undecided", "rate")},
           "part_b": b, "part_c": {k: c[k] for k in ("chi_c", "chi", "v_low", "div_frac")}}
    K.save_json("M7_dynamics.json", out)
    return out


def figure_f8(a, b, c):
    import matplotlib.pyplot as plt
    from matplotlib.colors import TwoSlopeNorm
    K.setup_mpl()
    fig, axes = plt.subplots(1, 3, figsize=(11.6, 3.4))

    # (a) 终局相图
    ax = axes[0]
    im = ax.imshow(a["V"], origin="lower", aspect="auto",
                   extent=[a["g0_grid"][0], a["g0_grid"][-1],
                           a["d_grid"][0], a["d_grid"][-1]],
                   cmap="viridis", vmin=0, vmax=1)
    gg = np.linspace(1e-4, a["g0_grid"][-1], 100)
    ax.plot(gg, gg, color="white", lw=1.4, ls="--")
    ax.text(0.075, 0.055, "$\\delta_{\\mathrm{dam}}=g_0$", color="white", fontsize=7.5,
            rotation=38)
    ax.set_xlabel("$g_0=r_{\\mathrm{v}}-\\gamma_0$")
    ax.set_ylabel("$\\delta_{\\mathrm{dam}}$")
    ax.set_title("(a) Final $V/V_{\\max}$: collapse vs. degraded state")
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.02)

    # (b) 移动目标
    ax = axes[1]
    ax.loglog(b["eps_grid"], b["devs"], "o-", color=K.C["env"])
    ax.axhline(0.10, color=K.C["bad"], ls="--", lw=1.0)
    ax.text(1.2e-5, 0.115, "10% deviation line", fontsize=7.5, color=K.C["bad"])
    if b["eps_star"]:
        ax.axvline(b["eps_star"], color=K.C["ink"], ls=":", lw=1.0)
        ax.text(b["eps_star"], 0.003,
                "$\\varepsilon^*=%.1e$\n$(\\varepsilon^*/g_0=%.3f)$"
                % (b["eps_star"], b["eps_star_over_g0"]), fontsize=7.2,
                color=K.C["ink"], ha="left")
    ax.set_xlabel("Driver drift rate $\\varepsilon$")
    ax.set_ylabel("Max deviation from the frozen fixed point")
    ax.set_title("(b) Quantitative warning line for the moving target")

    # (c) 双稳盆地
    ax = axes[2]
    im = ax.imshow(c["divmap"], origin="lower", aspect="auto", cmap="magma",
                   extent=[c["Ig"][0], c["Ig"][-1], c["Vg"][0], c["Vg"][-1]])
    ax.set_xlabel("Initial $I_0$")
    ax.set_ylabel("Initial $V_0$")
    ax.set_title("(c) $\\chi=0.9\\chi_c$: divergence region covers %.0f%%" % (100 * c["div_frac"]))
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.02, ticks=[0, 1])
    return K.savefig(fig, "F8_终局相图与双稳盆地")


if __name__ == "__main__":
    o = main()
    for kk in ("P1", "P2", "P3", "P4"):
        print(f"{kk:3s} {o['results'][kk]['verdict']:3s} | {o['results'][kk]['criterion']}")
