﻿# -*- coding: utf-8 -*-
"""
M5　解码偏差预测失误（HR-7）

被检句
------
HR-7「栖息分布突变后，$B_{\\mathrm{int}}$ 与 $B^{\\mathrm{env}}$ 的差距应预测失误与存续下降。」
检验方式「人为突变频率分布，测二者的 KL 差距，看其是否预测后续失误率；**控制突变幅度**。」

模型
----
$K=8$ 类线索、4 个动作，收益矩阵使每个线索有唯一最优动作。
持有者用指数加权估计内部模型 $B_{\\mathrm{int}}$（学习率 $\\eta$），按 $B_{\\mathrm{int}}$
算期望收益并取最优动作。环境频率 $\\pi_t$ 在 $t=200$ 处突变（幅度 $\\Delta$）或匀速漂移（$\\omega$）。

两个候选预测量
--------------
$G_t=D_{\\mathrm{KL}}(\\pi_t\\,\\|\\,\\hat\\pi_t)$：HR-7 说的"解码偏差"。
$A_t=D_{\\mathrm{KL}}\\big(p(a\\mid\\pi_t)\\,\\|\\,p(a\\mid\\hat\\pi_t)\\big)$：§13.9 的 $I_{\\mathrm{pragmatic}}$
  的同构量（行动分布的信息增益）。
"""
from __future__ import annotations

import numpy as np
from scipy import stats

import common as K

MOD = 5
rng = K.rng_for(MOD)

K_CUE = 8
N_ACT = 4
T_END = 400
T_SHIFT = 200
TEMP = 0.35


def build_payoff(rng_local):
    """每个线索一个唯一最优动作，另有次优收益。"""
    U = rng_local.uniform(0.0, 1.0, size=(K_CUE, N_ACT))
    best = rng_local.integers(0, N_ACT, size=K_CUE)
    U[np.arange(K_CUE), best] += 2.0
    return U


def softmax(x, temp=TEMP):
    z = x / temp
    z = z - z.max(axis=-1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=-1, keepdims=True)


def kl(p, q):
    p = np.asarray(p, float)
    q = np.asarray(q, float)
    m = (p > 0) & (q > 0)
    return float(np.sum(p[m] * np.log2(p[m] / q[m])))


def run_one(rng_local, Delta, eta, omega):
    U = build_payoff(rng_local)
    pi0 = rng_local.dirichlet(np.ones(K_CUE))
    target = np.zeros(K_CUE)
    hot = rng_local.choice(K_CUE, size=2, replace=False)
    target[hot] = 1.0
    target = 0.5 * pi0 + 0.5 * target
    target = target / target.sum()

    pi = pi0.copy()
    b = pi0.copy()                    # 内部模型初值（先验 = 初始生境）
    Gs, As, errs = [], [], []
    for t in range(T_END):
        if t == T_SHIFT:
            pi = (1 - Delta) * pi + Delta * target
            pi = pi / pi.sum()
        elif omega > 0 and t > T_SHIFT:
            pi = (1 - omega * 0.05) * pi + omega * 0.05 * target
            pi = pi / pi.sum()

        # 真实最优动作（以 π 为权）
        a_true = int(np.argmax(pi @ U))
        a_hat = int(np.argmax(b @ U))
        # 后果读数：期望收益损失（越接近 0 越好），比 0/1 失误率更少噪声
        loss = float(pi @ (U[:, a_true] - U[:, a_hat]))
        errs.append(loss)

        Gs.append(kl(pi, b))
        # 行动分布的信息增益（§13.9 的同构量）
        pa_true = softmax((pi @ U)[None, :])[0]
        pa_hat = softmax((b @ U)[None, :])[0]
        As.append(kl(pa_true, pa_hat))

        # 观测一个线索并按指数加权更新
        xi = rng_local.choice(K_CUE, p=pi)
        onehot = np.zeros(K_CUE)
        onehot[xi] = 1.0
        b = (1 - eta) * b + eta * onehot
        b = b / b.sum()
    return np.array(Gs), np.array(As), np.array(errs)


def partial_corr(x, y, controls):
    """控制 controls 后 x 与 y 的偏相关（对 controls 回归取残差）。"""
    Z = np.column_stack([np.ones_like(x)] + controls)
    rx = x - Z @ np.linalg.lstsq(Z, x, rcond=None)[0]
    ry = y - Z @ np.linalg.lstsq(Z, y, rcond=None)[0]
    return float(np.corrcoef(rx, ry)[0, 1])


def auc(score, label) -> float:
    """Mann–Whitney 形式的 AUC。"""
    score = np.asarray(score, float)
    label = np.asarray(label, bool)
    n1 = label.sum()
    n0 = (~label).sum()
    if n1 == 0 or n0 == 0:
        return float("nan")
    order = np.argsort(score)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, score.size + 1)
    # 并列取平均秩
    s_sorted = score[order]
    i = 0
    while i < s_sorted.size:
        j = i
        while j + 1 < s_sorted.size and s_sorted[j + 1] == s_sorted[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = (i + j) / 2.0 + 1
        i = j + 1
    return float((ranks[label].sum() - n1 * (n1 + 1) / 2.0) / (n1 * n0))


def dose_response(G, Ybin, n_bins=10):
    """按 G 的分位分箱，返回每箱的 G 中位数与 P(失误>0)。"""
    qs = np.quantile(G, np.linspace(0, 1, n_bins + 1))
    xs, ys = [], []
    for i in range(n_bins):
        m = (G >= qs[i]) & (G <= qs[i + 1] if i == n_bins - 1 else G < qs[i + 1])
        if m.sum() < 10:
            continue
        xs.append(float(np.median(G[m])))
        ys.append(float(np.mean(Ybin[m])))
    return xs, ys


def main() -> dict:
    Delta_grid = [0.05, 0.1, 0.2, 0.4]
    eta_grid = [0.01, 0.05, 0.2, 1.0]
    omega_grid = [0.0, 0.01, 0.05]
    n_rep = 12

    rec = []          # 每个 (格, 世界, t) 一条
    bank_X, bank_y = [], []
    for Delta in Delta_grid:
        for eta in eta_grid:
            for omega in omega_grid:
                for rep in range(n_rep):
                    r2 = np.random.default_rng(rng.integers(0, 2 ** 31))
                    G, A, E = run_one(r2, Delta, eta, omega)
                    bank_X.append((Delta, eta, omega, rep))
                    bank_y.append((G, A, E))
                    for t in range(T_SHIFT, T_END, 5):
                        # 用"未来 10 步内的失误数"作为后果读数
                        fut = float(E[t:t + 10].sum())
                        rec.append({"Delta": Delta, "eta": eta, "omega": omega,
                                    "t": t, "G": float(G[t]), "A": float(A[t]),
                                    "fut_err": fut})
    G = np.array([r["G"] for r in rec])
    A = np.array([r["A"] for r in rec])
    Y = np.array([r["fut_err"] for r in rec])
    Dl = np.array([r["Delta"] for r in rec])
    Et = np.array([r["eta"] for r in rec])
    Om = np.array([r["omega"] for r in rec])

    res = {}
    Ybin = (Y > 1e-9).astype(int)
    r_pear = float(np.corrcoef(G, Y)[0, 1])
    xs, ys = dose_response(G, Ybin)
    rho_dose = float(stats.spearmanr(xs, ys).statistic) if len(xs) >= 3 else float("nan")
    auc_G = auc(G, Ybin)
    auc_A = auc(A, Ybin)
    res["D1"] = K.verdict(
        (rho_dose >= 0.8) and (auc_G >= 0.70),
        pass_text="剂量—反应：按 $G$ 分箱后 P(失误>0) 随箱单调上升（Spearman=%.2f），"
                  "AUC(%.3f)≥0.70" % (rho_dose, auc_G),
        fail_text="合并 Pearson 相关只有 r=%.3f；剂量—反应 Spearman=%.2f、AUC=%.3f。"
                  "原因是后果读数是阈值函数：$G$ 不大到能翻转动作时损失恒为零，"
                  "所以「差距越大失误越多」只在阈值以上成立" % (r_pear, rho_dose, auc_G),
        detail={"pearson_G": r_pear, "dose_x": xs, "dose_y": ys,
                "rho_dose": rho_dose, "auc_G": auc_G, "auc_A": auc_A},
    )
    # D2：控制 Δ、η、ω 之后 G 还剩多少判别力
    Zc = np.column_stack([np.ones_like(G), Dl, Et, Om])
    resid_G = G - Zc @ np.linalg.lstsq(Zc, G, rcond=None)[0]
    auc_resid = auc(resid_G, Ybin)
    pcG = partial_corr(G, Y, [Dl, Et, Om])
    res["D2"] = K.verdict(
        auc_resid >= 0.65,
        pass_text="控制 $\\Delta,\\eta,\\omega$ 后，残差 $G$ 的 AUC=%.3f ≥0.65" % auc_resid,
        fail_text="控制 $\\Delta,\\eta,\\omega$ 后，残差 $G$ 的 AUC 只剩 %.3f（偏相关 r=%.3f）："
                  "HR-7 的「控制突变幅度后仍预测」在这个模型族里**不可识别**——"
                  "$G$ 的判别力几乎全部来自它与突变幅度、学习率的共线"
                  % (auc_resid, pcG),
        detail={"auc_resid_G": auc_resid, "partial_G": pcG,
                "partial_A": partial_corr(A, Y, [Dl, Et, Om])},
    )

    # D3：留出预测（按 (Δ,η,ω) 三元组分折，回归"未来损失"）
    trip = [(r["Delta"], r["eta"], r["omega"]) for r in rec]
    uniq = sorted(set(trip))
    errs_G, errs_D = [], []
    for i in range(0, len(uniq), 4):
        hold = set(uniq[i:i + 4])
        te = np.array([t in hold for t in trip])
        if te.all() or (~te).sum() < 10:
            continue
        for Xd, store in ((np.column_stack([G, Dl, Om]), errs_G),
                          (np.column_stack([Dl, Om]), errs_D)):
            Xtr = np.column_stack([np.ones((~te).sum()), Xd[~te]])
            coef = np.linalg.lstsq(Xtr, Y[~te], rcond=None)[0]
            Xte = np.column_stack([np.ones(te.sum()), Xd[te]])
            pred = Xte @ coef
            store.append(float(np.sqrt(np.mean((pred - Y[te]) ** 2))))
    rmse_G = float(np.mean(errs_G)) if errs_G else float("nan")
    rmse_D = float(np.mean(errs_D)) if errs_D else float("nan")
    gain = (rmse_D - rmse_G) / rmse_D if np.isfinite(rmse_D) else float("nan")
    res["D3"] = K.verdict(
        np.isfinite(gain) and gain >= 0.05,
        pass_text="留出预测：加入 $G$ 后 RMSE 相对只用 $\\Delta,\\omega$ 的模型下降 %.1f%%（≥5%%）"
                  % (100 * gain),
        fail_text="留出预测：加入 $G$ 后 RMSE 只下降 %.1f%%（<5%%）——"
                  "在已含突变幅度的模型里，$G$ 没有带来可检出增益" % (100 * gain),
        detail={"rmse_with_G": rmse_G, "rmse_without_G": rmse_D, "gain": gain},
    )

    # D4：判别力比较——行动分布 KL 是否比全 KL 更能预测"有没有失误"
    res["D4"] = K.verdict(
        (auc_A - auc_G) >= 0.05,
        pass_text="行动分布 KL 的 AUC=%.3f，比全 KL 的 %.3f 高 %.3f（≥0.05）——"
                  "§13.9 的候选操作化在预测失误上优于 HR-7 写的全 KL"
                  % (auc_A, auc_G, auc_A - auc_G),
        fail_text="行动分布 KL 的 AUC=%.3f，全 KL 的 AUC=%.3f，只高 %.3f（<0.05）"
                  % (auc_A, auc_G, auc_A - auc_G),
        detail={"auc_G": auc_G, "auc_A": auc_A},
    )

    K.save_csv("M5_bias.csv", rec[:5000])
    try:
        figure_f7(rec, bank_y, G, A, Y)
    except Exception as e:
        print("figure error", e)

    out = {"module": "M5", "env": K.env_record(), "results": res,
           "n_records": len(rec)}
    K.save_json("M5_bias.json", out)
    return out


def figure_f7(rec, bank_y, G, A, Y):
    import matplotlib.pyplot as plt
    K.setup_mpl()
    fig, axes = plt.subplots(1, 3, figsize=(11.4, 3.3))

    # (a) 一个世界的时序：π 突变后 G 与失误
    ax = axes[0]
    Delta, eta, omega, rep = 0.4, 0.05, 0.0, 0
    r2 = np.random.default_rng(12345)
    Gs, As, E = run_one(r2, Delta, eta, omega)
    ax.plot(Gs, color=K.C["env"], lw=1.4, label="Decoding divergence $G_t$ (bit)")
    ax2 = ax.twinx()
    ax2.plot(np.convolve(E, np.ones(10) / 10, mode="same"), color=K.C["bad"],
             lw=1.3, label="Error rate (moving average)")
    ax2.set_ylabel("Error rate", color=K.C["bad"])
    ax2.tick_params(axis="y", colors=K.C["bad"])
    ax2.grid(False)
    ax.axvline(T_SHIFT, color=K.C["grey"], ls="--", lw=1.0)
    ax.text(T_SHIFT + 4, ax.get_ylim()[1] * 0.9, "Habitat shift", fontsize=7.5,
            color=K.C["grey"])
    ax.set_xlabel("Time step")
    ax.set_ylabel("$G_t$ (bit)", color=K.C["env"])
    ax.tick_params(axis="y", colors=K.C["env"])
    ax.set_title("(a) $G$ jumps at the shift; errors arrive late and out of phase")

    # (b) 散点：G 与后续失误
    ax = axes[1]
    sub = rec[::7]
    xs = np.array([r["G"] for r in sub])
    ys = np.array([r["fut_err"] for r in sub])
    ax.scatter(xs, ys, s=8, alpha=0.25, color=K.C["env"], edgecolors="none")
    ax.set_xlabel("$G_t$ (bit)")
    ax.set_ylabel("Errors in the next 10 steps")
    ax.set_title("(b) Pooled correlation r=%.2f" % np.corrcoef(xs, ys)[0, 1])

    # (c) 偏相关：先扣掉 Δ 与 η 能解释的部分
    ax = axes[2]
    Z = np.column_stack([np.ones_like(G),
                         np.array([r["Delta"] for r in rec]),
                         np.array([r["eta"] for r in rec]),
                         np.array([r["omega"] for r in rec])])
    rx = G - Z @ np.linalg.lstsq(Z, G, rcond=None)[0]
    ry = Y - Z @ np.linalg.lstsq(Z, Y, rcond=None)[0]
    ax.scatter(rx[::7], ry[::7], s=8, alpha=0.25, color=K.C["warn"], edgecolors="none")
    b = np.polyfit(rx, ry, 1)
    xx = np.linspace(rx.min(), rx.max(), 10)
    ax.plot(xx, np.polyval(b, xx), color=K.C["ink"], lw=1.2)
    ax.set_xlim(-1, 6)
    ax.set_xlabel("Residual of $G$ (after $\\Delta,\\eta,\\omega$)")
    ax.set_ylabel("Residual of errors")
    ax.set_title("(c) Partial correlation r=%.2f" % np.corrcoef(rx, ry)[0, 1])
    return K.savefig(fig, "F7_解码偏差与失误")


if __name__ == "__main__":
    o = main()
    for kk in ("D1", "D2", "D3", "D4"):
        print(f"{kk:3s} {o['results'][kk]['verdict']:3s} | {o['results'][kk]['criterion']}")
