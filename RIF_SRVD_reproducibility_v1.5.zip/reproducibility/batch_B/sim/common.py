# -*- coding: utf-8 -*-
"""
补丁 B 公共基础设施。

约定
----
* 所有随机流由主种子 20261103 派生：第 i 个模块用 SeedSequence(20261103).spawn(8)[i]。
* results/ 落 JSON（判据用）与 CSV（作图用）；figures/ 落 PNG(300dpi) 与 PDF。
* 本文件不含任何"理论主张"，只提供测量工具。
"""
from __future__ import annotations

import hashlib
import json
import platform
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
FIGS = ROOT / "figures"
for _d in (RESULTS, FIGS):
    _d.mkdir(parents=True, exist_ok=True)

MASTER_SEED = 20261103
N_MODULES = 8

# ----------------------------------------------------------------------------
# 随机流
# ----------------------------------------------------------------------------


def rng_for(module_index: int) -> np.random.Generator:
    """第 module_index 个模块的独立随机流（0..7）。"""
    ss = np.random.SeedSequence(MASTER_SEED).spawn(N_MODULES)
    return np.random.default_rng(ss[module_index])


# ----------------------------------------------------------------------------
# 结果落盘
# ----------------------------------------------------------------------------


def save_json(name: str, obj) -> Path:
    p = RESULTS / name
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=_json_default)
    return p


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (np.bool_,)):
        return bool(o)
    raise TypeError(f"not serializable: {type(o)}")


def save_csv(name: str, rows: list[dict]) -> Path:
    """极简 CSV 写出（不依赖 pandas，避免列序漂移）。"""
    if not rows:
        raise ValueError("empty rows")
    keys = list(rows[0].keys())
    p = RESULTS / name
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        f.write(",".join(keys) + "\n")
        for r in rows:
            f.write(",".join(_fmt(r.get(k)) for k in keys) + "\n")
    return p


def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, float):
        return f"{v:.10g}"
    return str(v)


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ----------------------------------------------------------------------------
# 判定纪律
# ----------------------------------------------------------------------------


def verdict(passed: bool, *, pass_text: str, fail_text: str, detail: str = "") -> dict:
    return {
        "verdict": "通过" if passed else "失败",
        "criterion": pass_text if passed else fail_text,
        "is_pass": bool(passed),
        "detail": detail,
    }


def indeterminate(reason: str, detail: str = "") -> dict:
    return {"verdict": "不可判", "criterion": reason, "is_pass": None, "detail": detail}


# ----------------------------------------------------------------------------
# 稀有度工具
# ----------------------------------------------------------------------------


def tail_p_upper(x_obs: float, sample: np.ndarray) -> float:
    """有序尾概率（大值更极端）：P_B(s(X') >= s(x_obs))。

    严格按定义计数（含并列），不做平滑 —— 并列正是要研究的对象。
    """
    n = sample.size
    return float(np.count_nonzero(sample >= x_obs) + 1) / float(n + 1)


def tail_p_lower(x_obs: float, sample: np.ndarray) -> float:
    n = sample.size
    return float(np.count_nonzero(sample <= x_obs) + 1) / float(n + 1)


def rarity_from_p(p: np.ndarray | float) -> np.ndarray | float:
    return -np.log2(np.asarray(p, dtype=float))


# ----------------------------------------------------------------------------
# bootstrap（BCa）
# ----------------------------------------------------------------------------


def bca_ci(sample: np.ndarray, stat_fn, *, level: float = 0.95,
           n_boot: int = 5000, rng: np.random.Generator | None = None,
           jackknife: bool = True) -> tuple[float, float, bool]:
    """BCa 区间。返回 (lo, hi, degenerate)。

    degenerate=True 表示重抽样分布退化（统计量几乎不变），此时 lo=hi=点估计。
    """
    sample = np.asarray(sample, dtype=float)
    n = sample.size
    rng = rng or np.random.default_rng(0)
    theta_hat = float(stat_fn(sample))

    idx = rng.integers(0, n, size=(n_boot, n))
    boot = np.array([stat_fn(sample[i]) for i in idx], dtype=float)
    boot = boot[np.isfinite(boot)]
    if boot.size < 25 or np.ptp(boot) == 0.0:
        return theta_hat, theta_hat, True

    z0 = _norm_ppf(np.clip(np.mean(boot < theta_hat), 1e-6, 1 - 1e-6))
    # 加速常数（jackknife）
    a = 0.0
    if jackknife and n <= 500:
        jk = np.array([stat_fn(np.delete(sample, i)) for i in range(n)], dtype=float)
        jk = jk[np.isfinite(jk)]
        if jk.size > 2:
            d = jk.mean() - jk
            denom = 6.0 * (np.sum(d ** 2) ** 1.5)
            if denom > 0:
                a = float(np.sum(d ** 3) / denom)

    alpha = (1 - level) / 2
    out = []
    for q in (alpha, 1 - alpha):
        zq = _norm_ppf(q)
        adj = z0 + (z0 + zq) / (1 - a * (z0 + zq))
        out.append(float(np.quantile(boot, _norm_cdf(adj))))
    return out[0], out[1], False


def _norm_cdf(x):
    from math import erf, sqrt
    return 0.5 * (1.0 + erf(x / sqrt(2.0)))


def _norm_ppf(q):
    from scipy.special import ndtri
    return float(ndtri(q))


# ----------------------------------------------------------------------------
# 绘图
# ----------------------------------------------------------------------------

MPL_READY = False


def setup_mpl():
    """统一字体与样式。必须在任何 pyplot 调用之前执行一次。"""
    global MPL_READY
    if MPL_READY:
        return
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["DejaVu Sans", "Noto Sans CJK SC", "Source Han Sans SC",
                            "WenQuanYi Zen Hei", "Microsoft YaHei", "SimHei", "sans-serif"],
        "axes.unicode_minus": False,
        "figure.dpi": 110,
        "savefig.dpi": 300,
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "legend.fontsize": 8,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "axes.grid": True,
        "grid.alpha": 0.25,
        "grid.linewidth": 0.6,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "lines.linewidth": 1.4,
        "figure.autolayout": False,
    })
    MPL_READY = True


# 统一配色（避免每张图各挑一套）
C = {
    "env": "#1f6fb4",       # 栖息背景 / 主
    "max": "#d1495b",       # 协议基线 / 次
    "ok": "#2a9d8f",        # 通过 / 真值
    "warn": "#e9a53f",      # 警示 / 中间态
    "bad": "#b5322c",       # 失败 / 崩溃
    "grey": "#8d99ae",
    "ink": "#22333b",
    "acc": "#7b4ea3",
}

PALETTE = ["#1f6fb4", "#d1495b", "#2a9d8f", "#e9a53f",
           "#7b4ea3", "#5f7a61", "#b5322c", "#8d99ae"]


def savefig(fig, stem: str, *, tight: bool = True):
    """Save both PNG and PDF, return the PNG path.

    The PDF is written without embedded timestamps so that re-running the
    pipeline reproduces it byte for byte (matplotlib embeds the creation
    time by default, which would break `sha256sum -c` after a re-run).
    """
    import matplotlib.pyplot as plt
    if tight:
        fig.tight_layout()
    png = FIGS / f"{stem}.png"
    pdf = FIGS / f"{stem}.pdf"
    fig.savefig(png, bbox_inches="tight", facecolor="white")
    fig.savefig(pdf, bbox_inches="tight", facecolor="white",
                metadata={"CreationDate": None, "ModDate": None})
    plt.close(fig)
    return png


# ----------------------------------------------------------------------------
# 环境记录
# ----------------------------------------------------------------------------


def env_record() -> dict:
    import matplotlib
    import scipy
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "matplotlib": matplotlib.__version__,
        "master_seed": MASTER_SEED,
    }
