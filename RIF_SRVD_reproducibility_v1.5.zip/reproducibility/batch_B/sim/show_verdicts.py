import json
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
SUMMARY = Path(__file__).resolve().parent.parent / "results" / "SUMMARY.json"
VERDICT_EN = {"通过": "PASS", "失败": "FAIL", "不可判": "UNDEC",
              "诊断成立": "DIAG"}
s = json.load(open(SUMMARY, encoding="utf-8"))
n = 0
for m, v in s["modules"].items():
    for k, r in v.items():
        n += 1
        print(f"{m:3s} {k:4s} {VERDICT_EN.get(r['verdict'], r['verdict']):4s} "
              f"{r['criterion'][:78]}")
print("total", n)
