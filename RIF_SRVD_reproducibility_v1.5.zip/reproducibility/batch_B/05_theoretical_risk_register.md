# Theoretical risk register

**LiangRuifeng** | 2026 | Companion to `batch_B/`

> The register answers one question: **what does this claim currently owe?**
> The "Verdict" column records only the conclusion this patch reaches; "Residual risk" records what this patch **cannot** exclude;
> "What would close it" records the thing that would really pin it down — in most cases that is an experiment, not a simulation.

---

## 1. Risk ledger for the claims examined

### A. Supported; can be used as the text stands

| # | Claim | Location | Verdict | Residual risk | What would close it |
| :-: | :-- | :-- | :-- | :-- | :-- |
| 1 | In a continuous background, tail-probability rarity has median 1 bit and mean 1.44 bit | §12.1 | pass (identity) | none — this is a probability integral transform | closed |
| 2 | One-sided discriminating power of compression gain: $\hat G>0$ confirms a rule, $\approx0$ cannot confirm its absence | §14.4 | pass (K4–K6) | tested only on one library of 30 rules and four placements | redo on three real object domains and see whether the false-negative rate stays high |
| 3 | Three-case terminal classification + damaged plateau $V^*=V_{\max}(1-\delta/g_0)$ | Volume I §5.1.2 | pass (P1/P2, error $1.5\times10^{-7}$) | this is a mathematical property of the ODE, not a statement about reality | no need to close; the risk lies in calibrating $V_{\max},\delta_{\mathrm{dam}}$, not in the classification |
| 4 | "$\chi<\chi_{\mathrm c}$ is not equivalent to path one" | Volume I §5.2.3 | pass (P4, 29% of initial values diverge) | holds only for the reduced subsystem (5.12) | requires a phase diagram of the full system, which this patch cannot do |
| 5 | Depth, length and size cannot be inferred from one another | §14.4 / Volume II §6.2 | pass (K2: $\tau=0.41$; random objects have the largest length but depth 0) | depends on the qualifier "in-library" | measure the three quantities in a real object domain and see whether they still fail to imply one another |
| 6 | Zero-effect control of the two-step test (false-positive rate 0.005 when both steps are done) | §13.3.3 | pass (T1) | tested only under normal, equal-variance, standardized effect size | redo with discrete / heavy-tailed / unequal-sample designs |

### B. Usable only after the text is changed (see `03` for details)

| # | Claim | Location | Verdict | Residual risk | What would close it |
| :-: | :-- | :-- | :-- | :-- | :-- |
| 7 | The boundary is determined by I–T–E pairing iteration | §12.8 | **fail** (B1/B2/B3/B7) | the ground truth of the synthetic world was planted; real structures may be more "non-redundant", in which case the pairing criterion might still delimit a boundary — **this patch has not excluded that** | run the same procedure on a non-redundant system with known ground truth (e.g. an ablatable regulatory network) and see whether it still converges to the full set |
| 8 | "$I\ge3$ bit and the 95% lower bound holds" is the entry threshold | §13.3.3(4) | **fail** (T4) | computed only under Clopper–Pearson with a single $e_{\mathrm{obs}}$; a bootstrap version may differ | recompute the threshold on control samples from a real dataset and check the actual pass rate |
| 9 | HR-6's coarsening order by $|\delta_r|$ | §12.9.3 / HR-6 | **fail** (R2/R3) | the one-dimensional ordered cue with 6 actions limits how "non-additivity" can show; a high-dimensional action space may be worse or better | run a cost-manipulation experiment on a real perceptual task with measurable decoding cost and measure the discard order |
| 10 | HR-7 predicts error from the KL gap between $B_{\mathrm{int}}$ and $B^{\mathrm{env}}$ | HR-7 at end of volume | **fail** (D1/D3), but D2 passes | D2's pass (residual AUC 0.757) shows that "no predictive power at all" is also wrong; the conclusion is **non-identifiability**, not absence of effect | needs data that measure $B_{\mathrm{int}}$ and $\Delta$ independently; a measurement problem, not a simulation problem |
| 11 | 1 bit / 1.44 bit are the baseline values for rarity | §12.1 | needs revision (Q1b/Q1c) | only under the convention that the reading is drawn randomly from the background; if it is a mean-type effect, see #12 | already closed in closed form: change to "limit + correction term" |
| 12 | $B_0$ estimated from control samples | §13.3.2 | needs one added sentence (A4) | an implementation trap, not a theoretical error | closed; one sentence suffices |
| 13 | "0.9 bit is close to the 1 bit baseline" | §12.2 | reading needs revision (Q2) | none | closed |

### C. Not touched at all by this patch

| # | Claim | Location | Why not touched |
| :-: | :-- | :-- | :-- |
| 14 | HR-1 to HR-3 (social-deprivation class) | end of volume | requires real population data; simulation cannot substitute |
| 15 | HR-8 (trajectory determined by the update rate of the reference class) | end of volume | with the object fixed it is a near-definitional tautology; simulation can only "confirm the identity", which is not a test |
| 16 | HR-9 (misleading rare signals are reproducible) | end of volume | depends on an action-binning protocol for $I_{\mathrm{pragmatic}}$, which has not yet been established |
| 17 | The decoder game and alignment engineering of Volume IV | Volume IV | requires another model setting (game structure + execution-layer coupling); time and space did not allow it this round |
| 18 | Offline compilation computation and human causal increment in Volume III | Volume III | as above; and its core quantity (the "compilation" of expert cognition) has not yet been operationalized |
| 19 | Operationalization of $W_{\mathrm{sv}}$ and $\iota_D$ | §12.9 | this patch only did a parameter sweep ($\iota_D\in\{0.5,1,2,3\}$ bit); no protocol was given |
| 20 | Cross-scale extrapolation | whole book | explicitly not attempted (L4) |

---

## 2. Risks rearranged by "who bears them"

The same set of failures means different things to the author, to readers, and to later researchers.

### For the author: three structural underdeterminations

1. **The inclusion rule of §12.8** — discriminating power outsourced. This is the most dangerous, because it is not on the "open problems" list;
   it reads like a completed definition.
2. **The double threshold of §13.3.3(4)** — two thresholds crammed into one sentence, with only one number given.
3. **The implicit premises of HR-6 / HR-7** — "costs are homogeneous" and "still predicts after controlling the shock magnitude": both presuppose a structural
   condition that has not been verified.

What these three share: **none is a miscalculation; each is "written down but not pinned down"**. A miscalculation is easy to fix; an unpinned statement is hard to fix — because it requires the author
to make a decision (which rule to adopt, which threshold to use, which premise to keep), and decisions make enemies.

### For readers: three usage prohibitions

1. **Do not use the output of §12.8 as a "boundary"** unless the author adds the minimality criterion of A1. What it gives is a family of admissible descriptions.
2. **Do not treat "3 bit" as the entry threshold** unless rewritten according to the either/or of A2. The actual threshold today is 6–7 bit.
3. **Do not treat the full KL gap as a predictor of error** (the current text of HR-7); its AUC is below chance; use a quantity at the level of the action distribution.

### For follow-on researchers: three tractable problems

1. **Boundary identification on non-redundant structures** (residual risk of register #7). This is the item this patch would most like to see overturned:
   if real structures are not redundant, the pairing criterion may still delimit a boundary. Requires an ablatable system with known ground truth.
2. **A measurement protocol for decoding cost** (#9). HR-6's fix requires $c$ to be measurable, and v1.59 has no such protocol.
3. **Separable measurement of $B_{\mathrm{int}}$ and $\Delta$** (#10). HR-7's "control the shock magnitude" is measurement-wise equivalent to
   "measure the two quantities separately", and at present only one is measured.

---

## 3. This patch's own risks

For honesty, a note on ourselves as well.

| Risk | Description | Mitigation |
| :-- | :-- | :-- |
| **The synthetic world is planted** | the ground-truth boundary is given by the generative process and may be "cleaner" than reality | the report qualifies every conclusion with "within this model family"; M2 adds a heterogeneous-redundancy world |
| **The criteria are mine** | how tight or loose a criterion is directly affects the pass rate | pre-registration written first, predictions registered first, and two criterion failures publicly disclosed (M1) |
| **Model-family selection is biased** | normal, one-dimensional, 8 categories of cues — all chosen for convenience | every module reports "how this conclusion changes with parameters" and lists the dimensions not swept |
| **Sample size and repetition count** | M2 used 80 repetitions (pre-registration said 500); M6 used 25 objects | flagged in the report; M2's medians are stable across 6 cells, so lowering repetitions does not change the conclusion |
| **Logical pre-registration is not institutional pre-registration** | no third-party timestamp | report §10 voluntarily lists 4 prediction errors + 2 criterion errors, as evidence that "the author hid nothing" |
| **No extrapolation** | all conclusions stop at L3 | explicitly declared; no "this means that in reality…" statements |

---

## 4. In one sentence

What this theory currently owes is not "more simulation" but **three decisions**: which inclusion rule boundary identification uses, how the 3 bit threshold is to be read,
and whether the denominator of the coarsening order counts. None of the three is hard to make; what is hard is admitting that they are still hanging.
