# RIF / SRVD v1.5 — Reproducibility Package: Licensing

This package is distributed under three licenses by content type
(author: LiangRuifeng, ORCID 0009-0002-8575-7127, 2026).

If a repository form (e.g. Zenodo) accepts only one license, select
**CC BY 4.0**; this file governs the actual per-file terms.

## 1. Scripts and code (`**/sim/*.py`, `tools/*.py`) — MIT License

```
MIT License

Copyright (c) 2026 LiangRuifeng

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## 2. Result data (`**/results/*.json`, `**/results/*.csv`, `**/results/*.sha256`, `**/figure/*`, `**/figures/*`) — CC0 1.0

Numerical results and figures are released under the Creative Commons CC0 1.0
Universal (Public Domain Dedication). Full text:
https://creativecommons.org/publicdomain/zero/1.0/legalcode

## 3. Documents and reports (`*.md`, including this README, pre-registration protocols, simulation reports, revision notes, figure notes, risk registers, and this file) — CC BY 4.0

Documents are released under the Creative Commons Attribution 4.0 International
License (CC BY 4.0). Full text:
https://creativecommons.org/licenses/by/4.0/legalcode

Suggested citation: LiangRuifeng, *Relational Information Framework* (RIF) v1.5
and *Structure Recursive Viability Dynamics* (SRVD) v1.5 — Reproducibility Package.

## Notes

- Synthetic-world numerical experiments are not empirical data; for interpretation limits see the "Notes" section of `README.md`.
- The split-license scheme follows the package release plan approved by the author in November 2026.
