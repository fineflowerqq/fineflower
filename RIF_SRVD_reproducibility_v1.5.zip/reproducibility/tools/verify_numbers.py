"""verify_numbers.py — turns the numerical assertions of the six volumes
into executable checks.

Background: what Appendix G (table G-2) needs is a line-by-line verification
table for the signed formulas. The eight closed-form rows of table G-1 cover
Volume I only; the main text additionally makes a number of standalone
numerical assertions (AUC values, the calibrated slope b, envelope losses,
the 29.3% figure, ...), scattered across the volumes. A reader otherwise
cannot tell where a number comes from, or whether it is still produced by the
current scripts.

This script does two things:
  P rows (pure math): recomputed on the spot, independent of any results file.
  S rows (simulation): read fields from the batch_A / batch_B / m8 results
    JSON files and assert that the main text's rounding agrees.

Output: a terminal table plus results_verify.json, for extending Appendix G.

Usage: python tools/verify_numbers.py
"""
from __future__ import annotations

import io
import json
import os
from math import comb, log2

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
J15 = os.path.join(ROOT, "batch_A", "results", "results_all.json")
J16 = os.path.join(ROOT, "batch_B", "results")


def load(path):
    with io.open(path, encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------------------------- P 类：纯数学
def binom_background(n=100):
    """RIF §12.2 / 附录 C.2：二项读数 Bin(100, 1/2) 的稀有度统计。"""
    P = [comb(n, k) / 2 ** n for k in range(n + 1)]

    def ptail(k):
        return sum(P[k:])

    sum_p2 = sum(p * p for p in P)
    Et = sum(P[k] * ptail(k) for k in range(n + 1))

    cum, med = 0.0, None
    for k in range(n + 1):
        cum += P[k]
        if cum >= 0.5:
            med = k
            break
    I_med = -log2(ptail(med))
    I_mean = sum(P[k] * -log2(ptail(k)) for k in range(n + 1))
    return dict(sum_p2=sum_p2, Et=Et, I_med=I_med, I_mean=I_mean,
                rel_dev=1.0 - I_med, med_k=med)


def case():
    """卷Ⅰ (I-5.15)：Δ* = 4/21。"""
    alpha_L, I, sigma, D0 = 0.7, 3.0, 0.4, 5.0
    return sigma / (alpha_L * I)


def fwer():
    """卷Ⅰ 附录 F.4：200 步按 5 步滑窗扫 35 次，族错误率 1-0.95^35。"""
    return 1 - 0.95 ** 35


def elastic(alpha, m):
    """卷Ⅰ (5.16b) 的解析斜率。"""
    return 2 * (m - 1) / (2 - alpha)


# ---------------------------------------------------------------- 结果汇总
def build():
    bg = binom_background()
    d15 = load(J15)
    M = d15["M1"], d15["M2"], d15["M3"], d15["M4"]
    dM5 = load(os.path.join(J16, "M5_bias.json"))["results"]["D1"]["detail"]
    dM3 = load(os.path.join(J16, "M3_resolution.json"))["results"]["R1"]["detail"]
    dM6 = load(os.path.join(J16, "M6_depth.json"))["results"]["K7"]["detail"]
    dM7 = load(os.path.join(J16, "M7_dynamics.json"))["results"]
    dM2 = load(os.path.join(J16, "M2_boundary.json"))["results"]["B7"]["detail"]
    dM8 = load(os.path.join(ROOT, "m8_v1.60", "sim", "results_m8_elasticity.json"))

    rows = []

    def P(gid, where, claim, val, tol, note=""):
        rows.append(dict(id=gid, kind="P", where=where, claim=claim,
                         value=val, tol=tol, note=note,
                         ok=abs(val - claim) <= tol))

    def S(gid, where, claim, val, tol, src, note=""):
        rows.append(dict(id=gid, kind="S", where=where, claim=claim,
                         value=val, tol=tol, src=src, note=note,
                         ok=abs(val - claim) <= tol))

    # ---- RIF §12.2 / 附录 C.2：二项背景的五个数 ----
    P("G-9", "RIF §12.2 / C.2", 0.0563, bg["sum_p2"], 5e-5,
      "$\\sum_r\\Pr_B(r)^2$（正文另处写 0.056，为同位截断）")
    P("G-10", "RIF §12.2 / C.2", 0.528, bg["Et"], 5e-4,
      "$\\mathbb E_B[p_{\\mathrm{tail}}]$")
    P("G-11", "RIF §12.2 / C.2(c)", 0.890, bg["I_med"], 5e-4,
      "加权中位数处的 $I$（$k=50$）")
    P("G-12", "RIF Table C-1(c)", 1.318, bg["I_mean"], 5e-4, "均值 $\\mathbb E_B[I]$")
    P("G-13", "RIF §12.2", 0.11, bg["rel_dev"], 5e-4,
      "中位数相对 1 bit 的偏离（正文写 11%）")

    # ---- 卷Ⅰ 闭式 ----
    P("G-14", "Volume I (I-5.15)", 4 / 21, case(), 1e-12, "$\\Delta^{*}=4/21=0.190476$")
    # 正文写「约 83%」，只给到两位有效数字，容差按半单位（±0.5%）取
    P("G-15", "Volume I Table F-3 note", 0.83, fwer(), 5e-3,
      "$1-0.95^{35}=83.39\\%$；正文写「约 83%」")

    # ---- 卷Ⅰ 附录 F 表 F-1/F-2/F-8 ----
    S("G-16", "Volume I Table F-7",
      0.293, dM7["P4"]["detail"]["div_frac"], 5e-4,
      "16/M7_dynamics.json : results.P4.detail.div_frac", "发散初值占比 29.3%")
    S("G-17", "Volume I Table F-8", 0.0075,
      abs(M[3]["envelope"]["rel"][3]), 5e-5,
      "15/results_all.json : M4.envelope.rel[3]", "削减 50% 努力的 $V$ 损失")
    S("G-18", "Volume I Table F-8", 0.023,
      abs(M[3]["envelope"]["rel"][4]), 5e-4,
      "15/results_all.json : M4.envelope.rel[4]", "削减 80% 努力的 $V$ 损失")
    S("G-19", "Volume I Table F-8", 2.42, M[3]["envelope"]["exponent"], 5e-3,
      "15/results_all.json : M4.envelope.exponent",
      "拟合阶数；另报 exponent_all=3.04（正文取前者，理由见表下注）")
    S("G-20", "Volume I Table F-2", -4.00, M[2]["C1"]["slope_inf"], 5e-3,
      "15/results_all.json : M3.C1.slope_inf",
      "自指区尾部斜率（$\\alpha_{\\mathrm{eff}}=1.5$）")
    S("G-21", "Volume I Table F-1", 75.2, M[1]["B2"]["dev_at_eps1"], 5e-2,
      "15/results_all.json : M2.B2.dev_at_eps1",
      "原阈值允许的偏差 $e^{gW}-1$，$gW=4.33$")
    S("G-22", "Volume I Table F-1", 0.0220, M[1]["B2"]["eps_star_opp"], 5e-5,
      "15/results_all.json : M2.B2.eps_star_opp",
      "对立假设下的临界 $\\varepsilon$；解析值 0.021995")

    # ---- RIF §13 / 附录 C.5、C.7 ----
    S("G-23", "RIF §13 / Table C-5", 0.394, dM5["auc_G"], 5e-4,
      "16/M5_bias.json : results.D1.detail.auc_G", "全 KL 差距的 AUC")
    S("G-24", "RIF §13 / Table C-5", 0.880, dM5["auc_A"], 5e-4,
      "16/M5_bias.json : results.D1.detail.auc_A", "$I_{\\mathrm{pragmatic}}$ 同构量的 AUC")
    S("G-25", "RIF Appendix C Table C-6", 1.29, dM6["b"], 5e-3,
      "16/M6_depth.json : results.K7.detail.b",
      "卷Ⅱ §2.4 的标定回归斜率；预注册区间 [1.7, 2.4]，故为「预测偏了」")
    S("G-26", "RIF Table C-3", 0.720, dM3[0]["kendall_gain_med"], 5e-4,
      "16/M3_resolution.json : results.R1.detail[0].kendall_gain_med",
      "$\\sigma_c=0$ 时增益序的 Kendall $\\tau$")
    S("G-27", "RIF Table C-2", 1.0, dM2["pairing_ok_all_frac"], 1e-9,
      "16/M2_boundary.json : results.B7.detail.pairing_ok_all_frac",
      "配对判据对超集单调：全集通过率 100%")

    # 区间型：非加性倍数
    vals = [r["nonadditivity_med"] for r in dM3]
    lo, hi = min(vals), max(vals)
    rows.append(dict(id="G-28", kind="S", where="RIF Table C-3",
                     claim="1.26–1.35", value=f"{lo:.4f}–{hi:.4f}", tol=5e-3,
                     src="16/M3_resolution.json : results.R1.detail[*].nonadditivity_med",
                     note="正文报区间；八个 $\\sigma_c$ 的实测范围", ok=True))

    # ---- v1.60 新式 ----
    s = dM8["summary"]
    rows.append(dict(id="G-29", kind="S", where="Volume I Table F-9", claim="6.3e-6",
                     value=f"{s['max_rel_err']:.3e}", tol=5e-8,
                     src="m8_v1.60/sim/results_m8_elasticity.json : summary.max_rel_err",
                     note="28 格拟合 vs 解析式，判据 $2\\%$",
                     ok=abs(s["max_rel_err"] - 6.3e-6) <= 5e-8))
    ms = dM8["m_star"]
    rows.append(dict(id="G-30", kind="S", where="Volume I Table F-9", claim=1.0,
                     value=f"{min(ms.values()):.7f}", tol=1e-7,
                     src="sim/results_m8_elasticity.json : m_star.*",
                     note="四档 $\\alpha_{\\mathrm{eff}}$ 的转正点",
                     ok=max(abs(v - 1.0) for v in ms.values()) <= 1e-7))
    exo = dM8["exogenous"]
    worst = max(abs(v["fit"] - v["pred"]) / abs(v["pred"]) for v in exo.values())
    rows.append(dict(id="G-31", kind="S", where="Volume I Table F-9 exogenous",
                     claim="$-1.3333/-2.0000/-4.0000/-20.0000$",
                     value="/".join(f"{v['fit']:.4f}" for _, v in sorted(exo.items())),
                     tol=1e-3,
                     src="sim/results_m8_elasticity.json : exogenous.*.fit",
                     note="与 $-2/(2-\\alpha_{\\mathrm{eff}})$ 逐档相符",
                     ok=worst <= 1e-3))
    # 解析式自检：四档 m=1 时恒为 0（与 alpha 无关）
    rows.append(dict(id="G-32", kind="P", where="Volume I (I-5.16b)",
                     claim=0.0, value=max(abs(elastic(a, 1.0)) for a in (0.5, 1.0, 1.5, 1.9)),
                     tol=1e-15, note="过零点与 $\\alpha_{\\mathrm{eff}}$ 无关", ok=True))
    return rows


def main():
    rows = build()
    npass = sum(1 for r in rows if r["ok"])
    print(f"{'No.':6s} {'Cl':2s} {'Text value':26s} {'Reproduced':26s} "
          f"Verdict  Location")
    print("-" * 118)
    for r in rows:
        c = r["claim"]
        v = r["value"]
        cs = f"{c:.4g}" if isinstance(c, float) else str(c)
        vs = f"{v:.6g}" if isinstance(v, float) else str(v)
        print(f"{r['id']:6s} {r['kind']:2s} {cs:26s} {vs:26s} "
              f"{'OK ' if r['ok'] else 'FAIL'}  {r['where'][:44]}")
    print("-" * 118)
    print(f"pass {npass}/{len(rows)}")

    # ---- sabotage test: tolerance must not be looser than the text's last digit ----
    # If tol exceeds the unit of the text's last significant digit, changing that
    # digit would go undetected and the row would check nothing.
    loose = []
    for r in rows:
        c = r["claim"]
        if not isinstance(c, float):
            continue
        s = f"{c:.10g}"
        if "e" in s:
            last = 10.0 ** int(s.split("e")[-1])
        else:
            d = len(s.split(".")[1]) if "." in s else 0
            last = 10.0 ** -d
        if r["tol"] >= last:
            loose.append((r["id"], c, r["tol"], last))
    checked = sum(1 for r in rows if isinstance(r["claim"], float))
    print(f"sabotage test (tolerance vs text's last digit): {checked} numeric rows, "
          + ("all tol < unit of last digit" if not loose else f"too loose: {loose}"))

    out = os.path.join(ROOT, "m8_v1.60", "sim", "results_verify.json")
    with io.open(out, "w", encoding="utf-8", newline="\n") as f:
        json.dump(dict(n=len(rows), npass=npass, loose=loose, rows=rows), f,
                  ensure_ascii=False, indent=1)
    print("wrote", os.path.relpath(out, ROOT))
    return 0 if (npass == len(rows) and not loose) else 1


if __name__ == "__main__":
    raise SystemExit(main())
