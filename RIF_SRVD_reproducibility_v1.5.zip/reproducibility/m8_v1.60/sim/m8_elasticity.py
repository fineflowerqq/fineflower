"""M8  Four-regime check of the elasticity closed form (I-5.16b).

The claim under test is analytic:

    d ln Delta*/d ln chi = 2/(2-alpha) * [ m*rho/(1+rho) - 1 ],  rho = (u/chi*)^m

with u = chi V*.  Its two limits are  -2/(2-alpha)  (source dormant) and
2(m-1)/(2-alpha)  (source dominant).  v1.59.4 only had alpha=1.5.  Here the
same statement is checked on four alpha values; the acceptance criterion is
2% relative error between the fitted tail slope and the analytic value.

Difference from 15/sim/m3_chain.py (kept on purpose, documented in the paper):
  * the root of h(V)=0 is found in LOG space.  At alpha=1.9 and chi>10 the
    bracket in linear space overflows and brentq returns NaN.
  * the chi grid is chosen per alpha so that V*<=1e12 everywhere; the grid is
    long enough for both asymptotics (chi V*>>1 and (u/chi*)^m>>1) to be
    active inside the fitted window.  A short grid is not a wrong formula:
    it just fits the crossover instead of the tail.
  * m=0 is excluded (division by zero in rho); the scan starts at 0.2.

M0-style power check: the same pipeline is run against a deliberately wrong
prediction (drop the -1, i.e. pretend the denominator contributes nothing).
If the wrong formula also passes, the check is worthless.
"""
import json
import platform
import sys

import numpy as np
import scipy
from scipy.optimize import brentq

KAPPA = 1.0
IBAS = 1.0
CHI_STAR = 1.0
SIGMA0 = 1.0
ALPHA_L = 1.0

ALPHAS = [0.5, 1.0, 1.5, 1.9]
MS = [0.5, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5]
TOL = 0.02


# ---------------------------------------------------------------- equilibrium
def logV_star(chi, alpha, kappa=KAPPA):
    """lower positive root of V^2 = kappa (1+chi V)^alpha, solved for ln V."""
    def g(L):
        # 2L - ln kappa - alpha ln(1 + chi e^L); stable for L up to ~700
        return 2.0 * L - np.log(kappa) - alpha * np.log1p(chi * np.exp(L))

    lo = -60.0
    hi = 1.0
    while g(hi) < 0:
        hi *= 2.0
        if hi > 600.0:
            return np.nan
    return brentq(g, lo, hi, xtol=1e-13, rtol=1e-15, maxiter=200)


def chi_grid(alpha, n=260):
    """chi from 1e-2 up to the value where V* would exceed 1e12."""
    top = 12.0 * (2.0 - alpha) / alpha      # log10 V* = alpha/(2-alpha) log10 chi
    return np.logspace(-2.0, min(top, 30.0), n)


def curve(alpha, m, n=260):
    chis = chi_grid(alpha, n)
    V = np.array([np.exp(logV_star(c, alpha)) for c in chis])
    ok = np.isfinite(V)
    chis, V = chis[ok], V[ok]
    u = chis * V                              # = chi V*
    rho = (u / CHI_STAR) ** m                 # (u/chi*)^m, m>0
    sig = SIGMA0 * (1.0 + rho)
    I = IBAS * (1.0 + u)                      # exact, not the u>>1 shortcut
    D = sig / (ALPHA_L * I)
    return chis, V, u, rho, D


def tail_slope(alpha, m, u_floor=1e2, rho_floor=1e2, frac=0.45):
    """least-squares slope of ln D vs ln chi on the doubly-asymptotic tail."""
    chis, V, u, rho, D = curve(alpha, m)
    mask = (u > u_floor) & (rho > rho_floor)
    if mask.sum() < 12:
        return np.nan, dict(n=int(mask.sum()), chi_lo=None, chi_hi=None)
    x, y = np.log(chis[mask]), np.log(D[mask])
    keep = max(12, int(len(x) * frac))
    x, y = x[-keep:], y[-keep:]
    k, b = np.polyfit(x, y, 1)
    # corrcoef divides by the per-vector stddev; a perfectly flat (or
    # degenerate) tail would give stddev 0 and NaN, so silence the
    # RuntimeWarning the division raises on the way there.
    with np.errstate(invalid="ignore", divide="ignore"):
        r2 = float(np.corrcoef(x, y)[0, 1] ** 2)
    return float(k), dict(n=int(keep), chi_lo=float(np.exp(x[0])),
                          chi_hi=float(np.exp(x[-1])), r2=r2,
                          u_lo=float(u[mask][-keep]), u_hi=float(u[mask][-1]))


def analytic(alpha, m):
    return 2.0 * (m - 1.0) / (2.0 - alpha)


def wrong(alpha, m):
    """corrupted: forget that the denominator also scales with chi."""
    return 2.0 * m / (2.0 - alpha)


# ---------------------------------------------------------------- scan
def scan():
    cells = []
    for alpha in ALPHAS:
        for m in MS:
            fit, info = tail_slope(alpha, m)
            pred = analytic(alpha, m)
            bad = wrong(alpha, m)
            cells.append(dict(alpha=alpha, m=m, slope_fit=fit, slope_pred=pred,
                              abs_err=(abs(fit - pred) if np.isfinite(fit) else None),
                              rel_err=(abs(fit - pred) / abs(pred)
                                       if np.isfinite(fit) and abs(pred) > 1e-9 else None),
                              slope_if_wrong=bad,
                              err_if_wrong=(abs(fit - bad) if np.isfinite(fit) else None),
                              **info))
    return cells


def m_star(alpha):
    """m at which the tail slope crosses zero (should be 1, independent of alpha)."""
    f = lambda m: tail_slope(alpha, m, frac=1.0)[0]
    lo, hi = 0.5, 2.0
    flo, fhi = f(lo), f(hi)
    if not (np.isfinite(flo) and np.isfinite(fhi)) or flo * fhi > 0:
        return None
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        fm = f(mid)
        if flo * fm <= 0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
        if hi - lo < 1e-9:
            break
    return 0.5 * (lo + hi)


def exogenous_check():
    """m=None equivalent: sigma constant.  Should reproduce -2/(2-alpha)."""
    out = {}
    for alpha in ALPHAS:
        chis, V, u, rho, D = curve(alpha, 1.0)
        I = IBAS * (1.0 + u)
        Dx = 1.0 / (ALPHA_L * I)              # sigma = sigma0, exogenous
        mask = u > 1e2                        # same self-referential window
        x, y = np.log(chis[mask]), np.log(Dx[mask])
        keep = max(12, int(len(x) * 0.45))
        k, _ = np.polyfit(x[-keep:], y[-keep:], 1)
        out[str(alpha)] = dict(fit=float(k), pred=float(-2.0 / (2.0 - alpha)),
                               n=int(keep), chi_hi=float(chis[mask][-1]))
    return out


def main():
    cells = scan()
    judged = [c for c in cells if c["rel_err"] is not None and abs(c["slope_pred"]) >= 0.1]
    max_rel = max(c["rel_err"] for c in judged)
    zero_cells = [c for c in cells if abs(c["slope_pred"]) < 0.1]
    max_abs_at_zero = max(abs(c["abs_err"]) for c in zero_cells
                          if c["abs_err"] is not None)
    wrong_ok = [c for c in cells
                if abs(c["slope_if_wrong"]) > 1e-9 and c["err_if_wrong"] is not None
                and c["err_if_wrong"] / abs(c["slope_if_wrong"]) < TOL]

    res = dict(
        module="M8  elasticity closed form (5.16b), four alpha regimes",
        threshold_rel=TOL,
        params=dict(kappa=KAPPA, I_bas=IBAS, chi_star=CHI_STAR,
                    sigma0=SIGMA0, alpha_L=ALPHA_L, alphas=ALPHAS, m=MS),
        cells=cells,
        m_star={str(a): m_star(a) for a in ALPHAS},
        exogenous=exogenous_check(),
        summary=dict(n_cells=len(cells),
                     max_rel_err=float(max_rel),
                     max_abs_err_at_m1=float(max_abs_at_zero),
                     wrong_formula_passes=len(wrong_ok),
                     passed=bool(max_rel < TOL and max_abs_at_zero < 0.05
                                 and len(wrong_ok) == 0)),
        env=dict(python=sys.version.split()[0], numpy=np.__version__,
                 scipy=scipy.__version__, platform=platform.platform()),
        seed=None,
        note="deterministic; no random numbers are drawn anywhere in this module",
    )
    return res


if __name__ == "__main__":
    r = main()
    print(json.dumps(r["summary"], ensure_ascii=False, indent=1))
    print("m* =", r["m_star"])
    print("exogenous:", {k: (round(v["fit"], 6), v["pred"]) for k, v in r["exogenous"].items()})
    for c in r["cells"]:
        print(f"a={c['alpha']:<4} m={c['m']:<4} fit={c['slope_fit']:>9.5f} "
              f"pred={c['slope_pred']:>8.4f} rel={'' if c['rel_err'] is None else round(c['rel_err'],6)}")
    def _json_safe(o):
        if isinstance(o, dict):
            return {k: _json_safe(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [_json_safe(v) for v in o]
        if isinstance(o, float) and not (o == o and abs(o) != float("inf")):
            return None
        return o

    with open("results_m8_elasticity.json", "w", encoding="utf-8") as f:
        json.dump(_json_safe(r), f, ensure_ascii=False, indent=1)
