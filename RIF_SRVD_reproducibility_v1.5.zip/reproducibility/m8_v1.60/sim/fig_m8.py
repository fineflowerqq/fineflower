"""Figure F.6  two regimes of Delta*(chi) and the zero crossing of the elasticity.

Left : Delta*_VV(chi) at alpha_eff=1.5, m=1.5 -- falls while the source is
       dormant, turns up once (chi V/chi*)^m dominates.  The two dashed lines
       are the analytic asymptotes -2/(2-alpha) and 2(m-1)/(2-alpha).
Right: fitted tail slope against m for four alpha_eff (the 28 cells of
       results_m8_elasticity.json); all four cross zero at m=1.

Data come from m8_elasticity.py; nothing is recomputed here except the left
panel curve, which uses the same root solver.
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from m8_elasticity import ALPHAS, curve, tail_slope

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.abspath(os.path.join(HERE, "..", "figures"))
RES = os.path.join(HERE, "results_m8_elasticity.json")

plt.rcParams.update({
    "font.size": 8, "axes.titlesize": 8, "axes.labelsize": 8,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 6.5,
    "axes.linewidth": 0.6, "lines.linewidth": 1.2,
})


def _deterministic_svg_ids(path):
    """Rename matplotlib's per-process random SVG element ids in order of
    first appearance, so the SVG is byte-for-byte reproducible across runs.
    (The ids look like `ma05232390d` / `p74fce7f24e` and appear after
    `id="`, `#` or `(` only; figure content is untouched.)"""
    import re
    with open(path, encoding="utf-8") as f:
        text = f.read()
    pat = re.compile(r'(?<=["(#])[mp][0-9a-f]{10}')
    seen = {}

    def sub(m):
        tok = m.group(0)
        if tok not in seen:
            seen[tok] = tok[0] + f"id{len(seen):02d}"
        return seen[tok]

    text = pat.sub(sub, text)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def main():
    d = json.load(open(RES, encoding="utf-8"))
    fig, axes = plt.subplots(1, 2, figsize=(6.7, 2.75))

    # ---------------- left: two regimes, alpha=1.5, m=1.5, chi*=10
    # chi*=10 (not the scan's 1) only so that both regimes fit in the frame:
    # the tail slope does not depend on chi*, only on rho>>1.
    ax = axes[0]
    alpha, m, chi_star = 1.5, 1.5, 1.0e3
    chis, V, u, rho0, _ = curve(alpha, m)
    rho = (u / chi_star) ** m
    D = (1.0 + rho) / (1.0 + u)
    ax.loglog(chis, D, color="#1f4e79", lw=1.8, zorder=3)

    s_lo = -2.0 / (2.0 - alpha)
    s_hi = 2.0 * (m - 1.0) / (2.0 - alpha)
    seg = (u > 2.0) & (u < chi_star * 0.3)
    ax.loglog(chis[seg], D[seg][0] * (chis[seg] / chis[seg][0]) ** s_lo, "--",
              color="0.45", lw=1.1, zorder=2)
    seg2 = u > chi_star * 20
    i_end = np.where(seg2)[0][-1]
    ax.loglog(chis[seg2], D[i_end] * (chis[seg2] / chis[i_end]) ** s_hi, ":",
              color="crimson", lw=1.2, zorder=2)

    i = int(np.argmin(D))
    ax.plot([chis[i]], [D[i]], "o", ms=4.5, mfc="white", mec="#1f4e79", mew=1.2, zorder=4)
    ax.annotate(r"$u_{\min}=\chi_*(m-1)^{-1/m}$", xy=(chis[i], D[i]),
                xytext=(0.52, 0.24), textcoords="axes fraction",
                arrowprops=dict(arrowstyle="-", lw=0.6, color="0.3"))
    ax.text(0.12, 0.30, rf"slope ${s_lo:+.0f}$", transform=ax.transAxes,
            color="0.35", fontsize=7.5)
    ax.text(0.60, 0.72, rf"slope ${s_hi:+.0f}$", transform=ax.transAxes,
            color="crimson", fontsize=7.5)
    ax.set_xlabel(r"$\chi$")
    ax.set_ylabel(r"$\Delta^{*}_{\mathrm{VV}}$")
    ax.set_title(r"(a) $\alpha_{\mathrm{eff}}=1.5,\ m=1.5$: two regimes")

    # ---------------- right: slope vs m, four alpha
    ax = axes[1]
    cols = {0.5: "#1f4e79", 1.0: "#2e7d32", 1.5: "#b26a00", 1.9: "#7b1fa2"}
    for a in ALPHAS:
        ms = [c["m"] for c in d["cells"] if c["alpha"] == a]
        fs = [c["slope_fit"] for c in d["cells"] if c["alpha"] == a]
        ax.plot(ms, fs, "o-", ms=3, lw=1.2, color=cols[a],
                label=rf"$\alpha_{{\mathrm{{eff}}}}={a}$")
    ax.axhline(0, color="0.3", lw=0.7)
    ax.axvline(1.0, color="crimson", lw=0.9, ls=":")
    ax.text(0.03, 0.95, r"$m^{*}=1.0000$ (all four)", transform=ax.transAxes,
            fontsize=6.5, color="crimson", ha="left", va="top")
    ax.set_xlim(0.35, 2.65)
    ax.margins(y=0.08)
    ax.set_xlabel(r"endogenous exponent $m$")
    ax.set_ylabel(r"$\mathrm{d}\ln\Delta^{*}/\mathrm{d}\ln\chi$")
    ax.set_title("(b) zero crossing independent of $\\alpha_{\\mathrm{eff}}$")
    ax.legend(loc="lower right", frameon=False, handlelength=1.4)

    fig.tight_layout(pad=0.4)
    fig.savefig(os.path.join(FIG, "fig_m8_regimes.png"), dpi=300)
    fig.savefig(os.path.join(FIG, "fig_m8_regimes.pdf"), dpi=300,
                metadata={"CreationDate": None, "ModDate": None})
    svg = os.path.join(FIG, "fig_m8_regimes.svg")
    fig.savefig(svg, dpi=300, metadata={"Date": None})
    _deterministic_svg_ids(svg)
    print("wrote figures/fig_m8_regimes.{png,pdf,svg}")
    plt.close(fig)


if __name__ == "__main__":
    main()
