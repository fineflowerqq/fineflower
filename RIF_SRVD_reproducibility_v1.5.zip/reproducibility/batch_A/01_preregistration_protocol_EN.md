> Reference translation. The Chinese file `01_预注册协议.md` is the hash-locked original; in case of any discrepancy the Chinese original governs.

# Preregistration protocol (v1.59 simulation patch)

**LiangRuifeng** | 2026 | companion to `batch_A/`

> This file was written **before any code was run**. All decision thresholds, grids, random seeds, and refutation conditions are locked here; `02_simulation_report.md` only fills in results and does not change criteria. If any criterion is changed after running, it must be flagged separately in the report together with the time of change; no silent re-judgement is permitted.

---

## 0  What this protocol is meant to solve

"Adding simulations" is most easily done as one of two things: recomputing an analytic result and calling it verification, or tuning parameters until a figure appears and then declaring support. Neither takes any risk — because both are **designed so that they cannot fail**. This protocol pins the simulation to a place where it can fail, using three hard constraints:

1. **Every test must first state "what result counts as failure"**, and the failure criterion must be mutually exclusive with the pass criterion and distinguishable from the same output.
2. **Every test must report its test power**: deliberately corrupt the claim under test (sign, coefficient, exponent, direction of the criterion); if the test still returns "pass" after the corruption, the test is invalid and is not counted in the conclusions (calibrated uniformly by M0).
3. **Every test must declare which layer it tests**, and a pass at a lower layer may not be presented as support for a higher layer.

## 0.1  Three-layer classification and the honest limits of this patch

SRVD's claims fall into three layers, which simulation can reach to very different degrees:

| Layer | Type of claim | What simulation can do | What simulation **cannot** do |
| :-- | :-- | :-- | :-- |
| **I Arithmetic** | Closed forms, bifurcation locations, stability classification (Eqs. (5.1c)(5.1d)(5.13)(5.15)(5.11), etc.) | Detect computation errors | It does not test whether the theory is true — a self-consistent formula only shows the derivation is sound |
| **II Structural** | Whether a reduction holds, whether a chain's sign follows from the model, whether a classification is exhaustive (Eqs. (5.2)/(5.1a), §5.3/§5.4, §5.6/5.19) | Detect internal inconsistency; detect that "an inference the text claims cannot actually be derived" | It cannot judge whether the real world is like this |
| **III Protocol** | Discriminative power of operational protocols, estimation bias of readings (§8.3, Appendix C H7, the six RIF elements) | Measure false-positive rates and resolution floors | It cannot replace real experiments |

**Explicit statement: this patch does not falsify SRVD, nor does it support SRVD.** It does only three things: (i) find formulas that are miscomputed; (ii) find inferences that are "written but do not follow"; (iii) find protocols that are "written down but cannot be executed". All three force v1.60 to reword — that is the entire value of this patch. Any reading of the form "the simulation supports the theory" goes beyond the evidence this patch can provide, and such wording must not appear in the report.

**Why it is needed**: across the six volumes of v1.59 there are 248 equation numbers and 10 falsifiable predictions, but **not a single line of numerical verification**. Version 0.0 once had an Appendix X, "five-fold recursive numerical simulation", whose conclusion was "in all parameter configurations that lead to structural disintegration, $T_{\mathrm{pred}}$ collapses strictly before $E_{\mathrm{flow}}$ crosses its threshold" — a universal proposition, with parameters hand-picked as one set, no null model, and no power calibration. It could therefore neither be refuted nor count as evidence, and v1.59 has deleted it. What this patch does is precisely to replace that kind of appendix with the kind that **can be refuted**.

## 0.2  On the temporality of "preregistration"

This protocol and the code were produced by the same author in the same working session; **there is no third-party timestamp**. Only two things can be checked: the SHA-256 of the file `01_预注册协议.md` has been written into `results/prereg.sha256`, and that value is written by `sim/run_all.py` **before the first run** and only read afterwards; and all criterion text in `02_simulation_report.md` is verbatim identical to this file. This is **logical preregistration**, not **institutional preregistration**: it prevents "changing the criteria after seeing the results", but it cannot prevent "the author already knew the answer". Readers should discount accordingly.

---

## 1  Module list

| ID | Module | Object of test | Layer | Risk borne |
| :-: | :-- | :-- | :-: | :-- |
| **M0** | Test-power calibration | All criteria in this protocol | — | Whether the tests themselves are valid |
| **M1** | Arithmetic checks (A1–A8) | (5.1c)(5.1d)(5.13)(5.15) three cases of (5.3), (3.11), (3.2) | I | Computation errors |
| **M2** | Reduction equivalence and domain of validity (B1–B2) | §5.1.2 "(5.2) is the image of (5.1a)", the $\varepsilon_{\mathrm{rel}}$ criterion | II | The equivalence claimed in the text fails / the failure criterion takes an inappropriate value |
| **M3** | Path-two sign and the endogenous source term (C1–C2) | §5.3 gap, §5.4 chain step (1) | II | The core narrative does not follow |
| **M4** | Counter-example search for the competitive-dissipation constraint (D1) | §8.4 "unilateral exit from competitive dissipation accelerates one's own collapse" | II/III | The empirical claim is overridden by counter-examples |
| **M5** | Discriminative power of the gating rule (E1) | §8.3 early-warning trigger criterion, Appendix C H7 | III | The protocol cannot discriminate (false positives) |
| **M6** | Resolution floor of rarity readings (F1) | RIF §12.1 readings, the §2.1 $\alpha_0=10^{-3}$ gate | III | The reading protocol is unreachable at finite sample size |

---

## 2  M1  Arithmetic checks: criteria

General conventions: random parameters are drawn from a log-uniform distribution with seed `20261103` and $n=200$ per set; the error is defined as $\lvert\text{numerical}-\text{analytic}\rvert/\lvert\text{analytic}\rvert$ (absolute error is used when dividing by zero).

| ID | Equation tested | Preregistered criterion (pass) | Refutation condition (fail) |
| :-: | :-- | :-- | :-- |
| **A1** | (5.1c) closed form of the positive root | maximum relative error $<10^{-9}$ | $\ge 10^{-9}$ |
| **A2** | (5.1d) $\mu_{\mathcal F}\tau_{\mathrm{decay}}>1$ and the transcritical bifurcation | 100% sign agreement of the criterion; the eigenvalue at $I=0$ changes sign at $\mu\tau=1$ with location error $<10^{-6}$ | at any parameter point "the criterion says yes / the numerics say no"; or a sign-change point off by $>10^{-6}$ |
| **A3** | (5.13) $\chi_{\mathrm c}$ | relative error $<10^{-6}$ | $\ge 10^{-6}$ |
| **A4** | (5.15) explicit solution | maximum absolute error against numerical integration $<10^{-8}$ | $\ge 10^{-8}$ |
| **A5** | (5.3) three-case classification + $V^{*}$ | final classification agreement rate $\ge99\%$; $V^{*}$ relative error $<10^{-3}$ | $<99\%$ or $V^{*}$ error $\ge10^{-3}$ |
| **A6** | Critical algebraic decay $V\sim V_{\max}/((r_{\mathrm v}-\gamma_0)t)$ | linear fit of $1/V$ against $t$ gives $R^2>0.999$, slope relative error $<10^{-3}$ | either condition violated |
| **A7** | (3.11) Price covariance | relative error of $\mathrm d\langle V\rangle/\mathrm dt$ against $\mathrm{Cov}(V,r)$ $<10^{-3}$ | $\ge 10^{-3}$ |
| **A8** | §3.2 "differ by a factor of 4" | ratio $=4\pm10^{-9}$ | deviation of $10^{-9}$ |

**The classification convention for A5 must be fixed in advance** (otherwise the agreement rate can be inflated by tuning the convention): the final reading is $V$ at $t=200$; $V<10^{-3}$ counts as going to zero; $\lvert V-V^{*}\rvert/V^{*}<10^{-2}$ counts as reduced-order; everything else is "undetermined". Any "undetermined" counts as a disagreement and may not be excluded.

## 3  M2  Reduction equivalence and domain of validity: criteria

**B1 (equivalence).** Take (5.1a) ($I_{\mathrm{eq}}=0$) mapped through $V=cI$ and (5.2) ($r_{\mathrm v}=\mu_{\mathcal F}$, $\gamma_0=1/\tau_{\mathrm{decay}}$, $V_{\max}=cI_{\max}(1-\gamma_0/r_{\mathrm v})$), integrate from the same initial condition, and compare the trajectories.
- Pass: maximum relative deviation over the whole interval $<10^{-6}$ (i.e. the two trajectories coincide to numerical precision).
- Fail: $\ge10^{-6}$. If it fails, the phrase "the same trajectory" does not hold and must be rewritten as "linearized equivalence", with the magnitude of the deviation given.

**B2 (the value taken by the $\varepsilon_{\mathrm{rel}}$ criterion).** Inject $\dot T_c/T_c$ and $\dot E_c/E_c$ proportionally, scan $\varepsilon_{\mathrm{rel}}\in[10^{-3},10^{1}]$, and measure the critical value $\varepsilon_{\mathrm{rel}}^{*}$ at which the trajectory relative deviation reaches 10%.
- Pass: $\varepsilon_{\mathrm{rel}}^{*}\ge1$ (the text's "fails when approaching or exceeding 1" holds and is conservative).
- Needs revision: $0.5\le\varepsilon_{\mathrm{rel}}^{*}<1$ (the criterion is too loose; tighten it to the measured $\varepsilon_{\mathrm{rel}}^{*}$).
- Fail: $\varepsilon_{\mathrm{rel}}^{*}<0.5$ (the criterion is off by an order of magnitude).

## 4  M3  Path-two sign and the endogenous source term: criteria

**C1 (the sign of chain step (1)).** Combine (5.1a) (or (5.12)) with (5.14) ($\sigma$ an exogenous constant), scan $\chi\in[0.05,5]\chi_{\mathrm c}$, measure the monotonicity of the equilibrium deviation $\Delta^{*}_{\mathrm{VV}}$ with respect to $\chi$, and fit $\mathrm d\ln\Delta^{*}/\mathrm d\ln\chi$.
- Pre-judgement (written here so as to leave no back door for the result): by §5.3's own algebra, $\Delta^{*}=\sigma/(\alpha_{\mathrm L}I_{\mathrm{net}})$ and $I_{\mathrm{net}}$ rises with $\chi$, so the slope should be negative. **If the measured slope is negative, step (1) of the §5.4 chain ("$V^{\mathrm{virt}}\uparrow\Rightarrow$ deviation amplified") is not an inference of the present model** and must be handled under C2; this pre-judgement is itself the risk this patch "bears" — if the slope turns out to be positive, then my reading of §5.3 is wrong, and the report must say so plainly.
- Criterion: when the fit gives $R^2>0.98$, report the sign and value of the slope; when $R^2\le0.98$, judge "not a power law, undecidable".

**C2 (the minimal form of the endogenous source term).** Let $\sigma=\sigma_0+a(\chi V)^{m}$ and find the critical exponent $m^{*}$ at which $\mathrm d\Delta^{*}/\mathrm d\chi$ turns from negative to positive (located on the scan grid).
- Criterion: report $m^{*}$ and the $\chi$ interval in which it is found; if no sign reversal exists for $m\in[0,4]$, judge "this form cannot support the chain" and a different source term is required.
- Use of the output: $m^{*}$ serves as the **necessary condition** for the new source-term expression in v1.60 (written as "$m>m^{*}$"), together with the testable implication of that condition (the sign of the cross-system correlation between $\Delta_{\mathrm{VV}}$ and $I_{\mathrm{net}}$).

## 5  M4  Counter-example search for the competitive-dissipation constraint: criteria

**Model (specified independently, not generated from the SRVD equations)**: $N=12$ agents, each choosing a dissipation intensity $e_i\ge0$ per period; the contested share is $s_i=e_i/\sum_j e_j$; $I_{\mathrm{net},i}=I_0+s_iR$; $E_{\mathrm{eff},i}=E_{\mathrm{base}}+e_i$; $V_i=I_{\mathrm{net},i}T/E_{\mathrm{eff},i}$; $V_i<V_{\min}$ for 3 consecutive periods means death; the other agents update $e$ by best response (grid search, step 0.05). **The model contains none of SRVD's recursions**; SRVD supplies only one prediction to be tested.

**Treatment**: select a surviving agent and permanently halve its $e$ at period 20; the control group uses the same seed and no intervention. Compare survival times between the two groups (median over 50 seeds).
**Grid**: $I_0/R\in\{0.05,0.2,1,5\}$, cost coefficient $\in\{0.5,1,2,4,8\}$ (20 cells in total).
- Pass (the §8.4 claim holds): $\le20\%$ of the grid shows "longer survival after halving".
- Fail (the domain must be narrowed): $>20\%$. If it fails, the sub-domain conditions under which the claim holds must be given as the domain restriction for v1.60.

## 6  M5  Discriminative power of the gating rule: criteria

**The object under test** is the rule in §8.3 itself (not the theory): "a fall of more than 30% relative to baseline within 3 consecutive rounds" or "a Mann–Kendall trend with $p<0.05$ over $n_{\mathrm{win}}$ consecutive steps".

**Null model (a healthy system with no reward hijacking and no collapse)**: $\gamma_t=\gamma_0(1+\eta_t)$, with $\eta_t$ AR(1), $\rho=0.8$, and the stationary standard deviation $\sigma_\eta$ scanning $\{0.01,0.02,0.05,0.1,0.2,0.5\}$; $T=200$; 2000 repetitions per cell, seed `20261103`.
- Pass: false-positive rate $\le5\%$ in all cells with $\sigma_\eta\le0.1$.
- Fail: $>5\%$ in any cell with $\sigma_\eta\le0.1$. If it fails, judge "the rule cannot discriminate without a declared signal-to-noise condition" and require a signal-to-noise threshold or a control arm.

**Limitation that must be declared**: this module uses a **statistical surrogate** for $\gamma$, not a real reinforcement-learning run. It tests the **operating characteristic of the rule**, not the theoretical content of H7. The report must not describe it as "H7 tested".

## 7  M6  Resolution floor of rarity readings: criteria

**Setting**: the true background is a Zipf distribution ($s=1$) over $K=50$ categories; compute $I_{\mathrm{true}}=-\log_2 p_k$ from the true values; draw $N$ samples from that distribution, estimate $\hat p_k=n_k/N$ with the plugin estimator, and report $I_{\mathrm{plug}}=-\log_2\hat p_k$; also report $I_{\mathrm{good}}$ (with 0.5 smoothing). $N\in\{10^2,10^3,10^4,10^5\}$, with 500 repetitions per cell.
- Pass: median deviation of the rarest 10% categories $\lvert\Delta I\rvert<0.1$ bit (for $N\le10^3$).
- Fail: $\ge0.1$ bit. If it fails, add "resolution floor $\log_2 N$" to the five items of the RIF measurement contract, and give the minimum sample size required for the $\alpha_0$ gate.

---

## 8  Conventions for the verdict summary

Each item receives exactly one of three verdicts: **pass** / **fail (text must be revised)** / **undecidable**. "Undecidable" must state what is missing (samples, compute, independent data); "the trend is consistent" may not be substituted for it.

**Reporting discipline**: every failed item goes into `03_v1.60_revision_notes.md`, and each must carry "the rebuttal evidence required if the author disagrees"; a passed item must not be written as "the theory is verified", but only as "no arithmetic error detected" or "this claim holds within this model family".
