"""M3  Does the short-sighted-runaway chain follow from the model?

C1: with sigma exogenous, the equilibrium mismatch Delta* = sigma/(alpha_L I_net)
    falls as chi rises (because I_net rises).  Chain step (1) of (5.17) claims the
    opposite.  Measure the elasticity d ln Delta*/d ln chi.
C2: add an endogenous source sigma = sigma0 + a (chi V)^m and locate the exponent
    m* at which the elasticity changes sign.
"""
import numpy as np
from scipy.optimize import brentq

from common import rng

ALPHA = 1.5
KAPPA = 1.0
IBAS = 1.0


def V_star(chi, alpha=ALPHA, kappa=KAPPA):
    """lower positive root of h(V)=V^2-kappa(1+chi V)^alpha."""
    h = lambda V: V ** 2 - kappa * (1 + chi * V) ** alpha
    hi = 1.0
    while h(hi) < 0:
        hi *= 2
    if hi > 1e12:
        return np.nan
    # h(0) = -kappa < 0 ; walk up to the first sign change
    lo = 0.0
    step = hi / 2000.0
    x = step
    while x < hi:
        if h(x) > 0:
            return brentq(h, x - step, x, xtol=1e-14, rtol=1e-15)
        x += step
    return brentq(h, 0.0, hi, xtol=1e-14) if h(hi) > 0 else np.nan


def I_star(chi):
    return IBAS * (1 + chi * V_star(chi))


def elasticity(chi_grid, m=None, sigma0=1.0, a=1.0):
    """d ln Delta*/d ln chi, with sigma exogenous (m=None) or endogenous."""
    I = np.array([I_star(c) for c in chi_grid])
    V = np.array([V_star(c) for c in chi_grid])
    if m is None:
        sig = np.full_like(I, sigma0)
    else:
        sig = sigma0 + a * (chi_grid * V) ** m
    D = sig / I
    slope = np.gradient(np.log(D), np.log(chi_grid))
    return D, slope


def c1():
    chi = np.logspace(-1.5, 2.5, 200)
    D, slope = elasticity(chi)
    # asymptotic slope at the largest chi (where the self-referential term dominates)
    s_inf = float(np.median(slope[-20:]))
    r2 = float(np.corrcoef(np.log(chi)[-60:], np.log(D)[-60:])[0, 1] ** 2)
    return dict(chi=[float(c) for c in chi[::10]],
                D=[float(d) for d in D[::10]],
                slope_inf=s_inf, r2_tail=r2,
                sign="负" if s_inf < 0 else "正",
                ok=bool(abs(r2 - 1) < 0.02),   # 只判"是否可判"，符号本身是待报告的发现
                note="C1 判定的是符号与可判性，不预设符号")


def c2(m_grid=None):
    if m_grid is None:
        m_grid = np.linspace(0.0, 2.5, 51)
    chi = np.logspace(0.5, 3.0, 240)
    out = []
    for m in m_grid:
        _, slope = elasticity(chi, m=m)
        out.append(float(np.median(slope[-20:])))
    out = np.array(out)
    sign_change = None
    for i in range(len(m_grid) - 1):
        if out[i] < 0 <= out[i + 1]:
            sign_change = float(m_grid[i] + (0 - out[i]) / (out[i + 1] - out[i]) *
                                (m_grid[i + 1] - m_grid[i]))
            break
    alpha = ALPHA
    expo = 2.0 / (2.0 - alpha)
    return dict(m=[float(x) for x in m_grid[::5]],
                slope=[float(x) for x in out[::5]],
                m_star=sign_change,
                predicted_m_star=1.0,
                I_exponent=float(expo),
                ok=bool(sign_change is not None and abs(sign_change - 1.0) < 0.03))


if __name__ == "__main__":
    print("C1", c1())
    print("C2 m*=", c2()["m_star"], "pred", c2()["predicted_m_star"])
