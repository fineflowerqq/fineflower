"""M5  Discriminating power of the early-warning gate in section 8.3 / H7.

The object under test is the RULE, not the theory:
  (R1) gamma falls more than 30% below baseline within 3 consecutive episodes
  (R2) Mann-Kendall declining trend with p<0.05 over a window of n_win steps

Null model (healthy system, no reward hacking, no collapse): gamma_t =
gamma0*(1+eta_t) with eta_t an AR(1) process.  We measure the false-positive
rate of each rule under this null, as a function of the noise level.
"""
import numpy as np

from common import rng

T = 200
REPS = 2000


def ar1(r, rho, sigma, n):
    e = r.normal(0, sigma, n)
    x = np.empty(n)
    x[0] = e[0]
    for i in range(1, n):
        x[i] = rho * x[i - 1] + e[i] * np.sqrt(1 - rho ** 2)
    return x


def rule1(series, base_len=20, drop=0.30, run=3):
    base = series[:base_len].mean()
    flag = np.zeros_like(series, bool)
    hit = 0
    for i in range(base_len, len(series)):
        if series[i] < (1 - drop) * base:
            hit += 1
            if hit >= run:
                # require the run to be consecutive
                if all(series[i - j] < (1 - drop) * base for j in range(run)):
                    return True
        else:
            hit = 0
    return False


def mann_kendall(x):
    n = len(x)
    s = 0
    for i in range(n - 1):
        s += np.sum(np.sign(x[i + 1:] - x[i]))
    var = n * (n - 1) * (2 * n + 5) / 18.0
    if s == 0:
        return 0.0, 1.0
    z = (s - np.sign(s)) / np.sqrt(var)
    from math import erfc, sqrt
    p = erfc(abs(z) / sqrt(2))
    return float(z), float(p)


def rule2(series, n_win=10, base_len=20):
    for end in range(base_len + n_win, len(series) + 1, 5):
        z, p = mann_kendall(series[end - n_win:end])
        if z < 0 and p < 0.05:
            return True
    return False


def e1():
    r = rng(5)
    sigmas = (0.01, 0.02, 0.05, 0.1, 0.2, 0.5)
    rows = []
    for sig in sigmas:
        f1 = f2 = 0
        for _ in range(REPS // 4):          # 500 reps per cell keeps runtime sane
            eta = ar1(r, 0.8, sig, T)
            g = 1.0 * (1 + eta)
            f1 += rule1(g)
            f2 += rule2(g, n_win=10)
        rows.append(dict(sigma=sig, fpr_rule1=f1 / (REPS // 4),
                         fpr_rule2=f2 / (REPS // 4)))
    # n_win sensitivity for rule 2
    wins = []
    for nw in (5, 10, 20, 40):
        f = 0
        for _ in range(500):
            eta = ar1(r, 0.8, 0.05, T)
            f += rule2(1.0 * (1 + eta), n_win=nw)
        wins.append(dict(n_win=nw, fpr=f / 500))
    bad = [x for x in rows if x["sigma"] <= 0.1 and
           (x["fpr_rule1"] > 0.05 or x["fpr_rule2"] > 0.05)]
    return dict(rows=rows, n_win_sweep=wins,
                threshold=0.05, violations=len(bad),
                ok=bool(len(bad) == 0), reps=REPS // 4, rho=0.8, T=T,
                note="零模型为健康系统的 gamma 序列，非真实 RL 运行")


if __name__ == "__main__":
    r = e1()
    for x in r["rows"]:
        print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in x.items()})
    print("n_win", r["n_win_sweep"])
    print("violations", r["violations"], "ok", r["ok"])
