"""M6  Finite-sample behaviour of the RIF rarity reading.

I_struct = -log2 Pr_B(r).  In practice Pr_B is estimated from N samples with a
plug-in estimator n_k/N.  We measure (i) the bias of the plug-in reading for the
rarest categories, and (ii) the resolution ceiling created by finite N.
"""
import numpy as np

from common import rng

K = 50
S = 1.0


def run():
    r = rng(6)
    w = 1.0 / np.arange(1, K + 1) ** S
    p = w / w.sum()
    I_true = -np.log2(p)

    Ns = (100, 1000, 10000, 100000)
    rows = []
    for N in Ns:
        bias, unseen, plug_max = [], [], []
        for _ in range(500):
            n = r.multinomial(N, p)
            phat = n / N
            keep = phat > 0
            b = (-np.log2(phat[keep])) - I_true[keep]
            bias.append(b)
            unseen.append(1 - keep.mean())
            plug_max.append(-np.log2(phat[keep].min()))
        bias = np.concatenate(bias)
        rare = I_true >= np.quantile(I_true, 0.9)
        rows.append(dict(N=N, n_unseen=float(np.mean(unseen)),
                         bias_median=float(np.median(bias)),
                         bias_rarest=float(np.median(
                             np.concatenate([np.array([0.0])]))),
                         max_reading=float(np.mean(plug_max)),
                         log2N=float(np.log2(N))))
        # bias computed separately for the rarest decile
        bb = []
        for _ in range(500):
            n = r.multinomial(N, p)
            phat = n / N
            keep = phat > 0
            bb.append(((-np.log2(phat[keep])) - I_true[keep])[rare[keep]])
        rows[-1]["bias_rarest"] = float(np.median(np.concatenate(bb))) if bb else float("nan")

    worst = max(abs(x["bias_rarest"]) for x in rows if x["N"] <= 1000)
    return dict(rows=rows, threshold=0.1, worst_bias_smallN=float(worst),
                ok=bool(worst < 0.1),
                note="插件估计 -log2(n_k/N) 对最稀 10% 类别的中位偏差")


if __name__ == "__main__":
    r = run()
    for x in r["rows"]:
        print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in x.items()})
    print("worst", r["worst_bias_smallN"], "ok", r["ok"])
