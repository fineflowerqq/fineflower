"""Common utilities for the v1.59 simulation patch.

All numeric parameters are drawn from log-uniform or specified grids with a
fixed seed; every module writes a JSON block with the pre-registered pass/fail
verdict computed from the thresholds locked in 01_预注册协议.md.
"""
import json
import math
import os
import numpy as np

SEED = 20261103
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "results")
FIG = os.path.join(HERE, "..", "figure")


def rng(offset: int = 0) -> np.random.Generator:
    return np.random.default_rng(SEED + offset)


def logu(r, lo, hi, n):
    return 10 ** r.uniform(np.log10(lo), np.log10(hi), n)


def _json_safe(obj):
    """Replace non-finite floats (inf/nan) with None so the output is strict JSON."""
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    return obj


def save(name: str, payload: dict):
    os.makedirs(RES, exist_ok=True)
    path = os.path.join(RES, name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(_json_safe(payload), f, ensure_ascii=False, indent=2)
    return path


def verdict(ok: bool) -> str:
    return "通过" if ok else "失败"
