"""M4  Counter-example search for the claim in section 8.4:

"两个解码器在同一生态位竞争时 ... 单方面退出竞争性耗散会导致相对存续势下降、
加速自身崩溃"（其自带的反驳条件：某一方大幅减少努力后存续时间显著延长）。

World specified independently of SRVD's recursion; SRVD supplies only the
prediction and the behavioural rule (agents maximise current V, i.e. they are
myopic V-maximisers, which is the paper's own assumption for V^val anchored on
V_obj).

Structure: N agents choose dissipation e; share s_i = e_i/sum(e); the contested
resource R_t is a *commons* that aggregate effort depletes and that recovers
slowly.  Cutting effort loses share now but preserves the resource later -- a
real trade-off, so the sign of the lifetime change is not built in.
depletion=0 recovers the pure private-prize (zero-sum) case.
"""
import numpy as np

N = 8
T = 150
GRID = np.round(np.arange(0, 1.0 + 1e-9, 0.05), 10)
EBASE = 1.0
REC = 0.05


def simulate(I0, R0, depl, seed, vmin, cut_at=20, cut_factor=0.5, do_cut=True,
             iters=4, shock_p=0.05):
    r = np.random.default_rng(seed)
    e = np.full(N, 0.3)
    R = R0
    S = np.zeros(N)
    alive = np.ones(N, bool)
    low_run = np.zeros(N, int)
    life = np.zeros(N)
    B = np.where(r.random(T) < shock_p, 0.3, 1.0)

    for t in range(T):
        pinned = (t >= cut_at) and do_cut
        if t == cut_at and do_cut:
            e[0] *= cut_factor

        for _ in range(iters):
            for i in range(N):
                if (i == 0 and pinned) or not alive[i]:
                    continue
                others = e.sum() - e[i]
                share = GRID / np.maximum(GRID + others, 1e-12)
                V = (I0 + share * R) / (EBASE + GRID)
                e[i] = GRID[np.argmax(V)]

        tot = e.sum()
        share = e / tot if tot > 0 else np.zeros(N)
        V = (I0 + share * R) / (EBASE + e)

        S += (B[t] - e)
        low_run = np.where(V < vmin, low_run + 1, 0)
        dead = (S < -1e-9) | (low_run >= 3)
        newly = dead & alive
        life[newly] = t
        alive &= ~newly
        if not alive.any():
            break

        # commons dynamics: aggregate effort depletes, slow recovery
        R = R + REC * (R0 - R) - depl * tot / N

    life[alive] = T
    return life


def d1(n_seed=20):
    I0_grid = (0.1, 0.5, 2.0)
    depl_grid = (0.0, 0.1, 0.3, 1.0)   # 0 = 私人物品（零和份额），大 = 公地
    vmin = 0.05
    cells, n_better = [], 0
    for I0 in I0_grid:
        for depl in depl_grid:
            wins, dl = 0, []
            for k in range(n_seed):
                lc = simulate(I0, 1.0, depl, 2000 + k, vmin, do_cut=False)[0]
                lt = simulate(I0, 1.0, depl, 2000 + k, vmin, do_cut=True)[0]
                dl.append(lt - lc)
                wins += int(lt > lc)
            frac = wins / n_seed
            n_better += int(frac > 0.5)
            cells.append(dict(I0=I0, depl=depl, win_frac=frac,
                              median_delta=float(np.median(dl)),
                              median_ctrl=float(np.median(
                                  [simulate(I0, 1.0, depl, 2000 + k, vmin, do_cut=False)[0]
                                   for k in range(5)]))))
    frac_cells = n_better / len(cells)
    return dict(cells=cells, frac_cells_better=float(frac_cells),
                threshold=0.20, ok=bool(frac_cells <= 0.20), n_seed=n_seed, vmin=vmin,
                note="win_frac: 干预组存活更久的种子占比；median_delta: 存活时长中位差（期）")


if __name__ == "__main__":
    r = d1()
    for c in r["cells"]:
        print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in c.items()})
    print("frac_cells_better", r["frac_cells_better"], "ok", r["ok"])


def envelope(I0=0.5, R=1.0, n_rep=8):
    """Package: unilateral effort cut costs only second order in V."""
    from numpy.linalg import lstsq
    facs = (1.0, 0.9, 0.8, 0.5, 0.2)
    means = []
    for f in facs:
        Vs = []
        for k in range(n_rep):
            e = np.full(N, 0.3)
            for _ in range(30):
                for i in range(N):
                    oth = e.sum() - e[i]
                    share = GRID / np.maximum(GRID + oth, 1e-12)
                    Vv = (I0 + share * R) / (EBASE + GRID)
                    e[i] = GRID[np.argmax(Vv)]
            ei = e[0] * f
            oth = e.sum() - e[0]
            Vs.append((I0 + ei / (ei + oth) * R) / (EBASE + ei))
        means.append(float(np.mean(Vs)))
    base = means[0]
    rel = [(m - base) / base for m in means]
    # 只用两个最大削减点（f=0.5, f=0.2）判阶：更小的削减落在网格离散噪声之下
    df = np.array([1 - facs[-2], 1 - facs[-1]])
    dvv = np.abs(np.array([rel[-2], rel[-1]]))
    p = float(np.log(dvv[1] / dvv[0]) / np.log(df[1] / df[0]))
    p_all = float(np.polyfit(np.log(np.array([1 - f for f in facs])[1:]),
                             np.log(np.abs(np.array(rel))[1:]), 1)[0])
    return dict(fac=list(facs), V=means, rel=rel, exponent=p, exponent_all=p_all,
                note="dV/V ~ (1-f)^p；p≈2 即包络定理（均衡处 dV/de=0）")
