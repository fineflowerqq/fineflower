"""M2  Is (5.2) really "the same trajectory" as (5.1a), and is the eps_rel
failure criterion calibrated?

B1: integrate (5.1a) with I_eq=0, map V=c*I, compare with (5.2) using the
    coefficient identification quoted in v1.59 section 5.1.2.
B2: inject drift into T_c and E_c and measure the trajectory deviation as a
    function of eps_rel, under two sign conventions (same-sign / opposite-sign).
"""
import numpy as np
from scipy.integrate import solve_ivp

from common import rng


# --------------------------------------------------------------------- B1
def b1(c=2.0, mu=1.3, tau=1.0, Imax=5.0, I0=0.1):
    gamma0 = 1.0 / tau
    rv = mu
    Vmax = c * Imax * (1 - gamma0 / rv)

    t = np.linspace(0, 40, 4001)
    sol_I = solve_ivp(lambda t, I: mu * I[0] * (1 - I[0] / Imax) - I[0] / tau,
                      (0, t[-1]), [I0], t_eval=t, rtol=1e-13, atol=1e-15)
    V_img = c * sol_I.y[0]

    sol_V = solve_ivp(lambda t, V: V[0] * (rv - gamma0) * (1 - V[0] / Vmax),
                      (0, t[-1]), [c * I0], t_eval=t, rtol=1e-13, atol=1e-15)
    V_red = sol_V.y[0]

    denom = np.maximum(np.abs(V_img), 1e-30)
    dev = float(np.max(np.abs(V_img - V_red) / denom))
    return dict(metric=dev, threshold=1e-6, ok=bool(dev < 1e-6),
                Vmax=float(Vmax), I_star=float(Imax * (1 - gamma0 / rv)),
                note="(5.2) 与 (5.1a) 的像是否为同一条轨迹")


# --------------------------------------------------------------------- B2
def _dev(g_scale, eps_a, eps_b, W):
    """relative deviation of V_c from the reduced prediction after time W."""
    return abs(np.exp((eps_a - eps_b) * W) - 1.0)


def b2(g=1.3, W=None, tol=0.10):
    if W is None:
        W = 1.0 / (g - 1.0)          # one relaxation time, r_v-1/tau = 0.3
    eps = np.logspace(-3, 1, 400)

    # opposite-sign drift: a = +eps*g/2, b = -eps*g/2  -> (a-b) = eps*g
    dev_opp = _dev(g, eps * g / 2, -eps * g / 2, W)
    idx = np.argmax(dev_opp >= tol)
    eps_star_opp = float(eps[idx]) if dev_opp.max() >= tol else np.inf

    # same-sign drift: a = b = eps*g/2 -> no deviation at all
    dev_same = _dev(g, eps * g / 2, eps * g / 2, W)
    eps_star_same = float("inf") if dev_same.max() < tol else float(eps[np.argmax(dev_same >= tol)])

    # deviation admitted by the text's own threshold eps_rel = 1
    dev_at_1 = float(np.exp(eps_star_opp * 0 + 1.0 * g * W) - 1)

    return dict(eps_star_opp=eps_star_opp, eps_star_same=eps_star_same,
                W=W, gW=g * W, dev_at_eps1=dev_at_1,
                analytic_eps_star=float(np.log(1 + tol) / (g * W)),
                pred_same=[float(e) for e in eps[::40]],
                dev_same=[float(d) for d in dev_same[::40]],
                pred_opp=[float(e) for e in eps[::40]],
                dev_opp=[float(d) for d in dev_opp[::40]])


if __name__ == "__main__":
    print("B1", b1())
    print("B2", {k: v for k, v in b2().items() if not isinstance(v, list)})
