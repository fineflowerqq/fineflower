"""Run every module, write results/*.json and figure/*.png.

The pre-registration hash is written once, before the first run, and never
rewritten: if results/prereg.sha256 is missing this script creates it from
01_预注册协议.md; otherwise it only reads the file and echoes it into the summary.
"""
import hashlib
import json
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter

import m1_math
import m2_reduction
import m3_chain
import m4_competition
import m5_gate
import m6_rarity
from common import FIG, RES, save

plt.rcParams.update({"figure.dpi": 160, "savefig.dpi": 300, "font.size": 9,
                     "axes.spines.top": False, "axes.spines.right": False})


def m0():
    """Detection power: every check must reject its own corrupted formula."""
    rows = []
    for key, label, fn in m1_math.CHECKS:
        good = fn(corrupt=False)
        bad = fn(corrupt=True)
        rows.append(dict(id=key, label=label,
                         pass_on_true=bool(good["ok"]),
                         pass_on_corrupt=bool(bad["ok"]),
                         detected=bool(good["ok"] and not bad["ok"])))
    # B1：破坏 V_max 的 (1-gamma0/rv) 因子
    c, mu, tau, Imax, I0 = 2.0, 1.3, 1.0, 5.0, 0.1
    from scipy.integrate import solve_ivp
    t = np.linspace(0, 40, 4001)
    sol_I = solve_ivp(lambda t, I: mu * I[0] * (1 - I[0] / Imax) - I[0] / tau,
                      (0, t[-1]), [I0], t_eval=t, rtol=1e-13, atol=1e-15)
    V_img = c * sol_I.y[0]
    Vmax_bad = c * Imax                      # 去掉 (1-gamma0/rv)
    sol_V = solve_ivp(lambda t, V: V[0] * (mu - 1 / tau) * (1 - V[0] / Vmax_bad),
                      (0, t[-1]), [c * I0], t_eval=t, rtol=1e-13, atol=1e-15)
    dev = float(np.max(np.abs(V_img - sol_V.y[0]) / np.maximum(np.abs(V_img), 1e-30)))
    rows.append(dict(id="B1", label="(5.2) 轨迹等价（破坏 V_max 因子）",
                     pass_on_true=bool(m2_reduction.b1()["ok"]),
                     pass_on_corrupt=bool(dev < 1e-6),
                     detected=bool(m2_reduction.b1()["ok"] and dev >= 1e-6)))

    # C2：破坏推导（把驱动力 chi*V 误写成 chi，丢掉自洽放大）
    chi = np.logspace(0.5, 3.0, 240)
    I = np.array([m3_chain.I_star(c_) for c_ in chi])
    V = np.array([m3_chain.V_star(c_) for c_ in chi])
    slopes = []
    for m in np.linspace(0.0, 2.5, 51):
        sig = 1.0 + 1.0 * chi ** m          # 少了 V^m 因子
        D = sig / I
        slopes.append(float(np.median(np.gradient(np.log(D), np.log(chi))[-20:])))
    slopes = np.array(slopes)
    m_star_bad = None
    mm = np.linspace(0.0, 2.5, 51)
    for i in range(len(mm) - 1):
        if slopes[i] < 0 <= slopes[i + 1]:
            m_star_bad = float(mm[i])
            break
    c2_true = m3_chain.c2()
    rows.append(dict(id="C2", label="内生源项指数 m*（破坏 chi^m 写法）",
                     pass_on_true=bool(c2_true["ok"]),
                     pass_on_corrupt=bool(m_star_bad is not None),
                     detected=bool(c2_true["ok"] and m_star_bad is None),
                     m_star_corrupt=m_star_bad,
                     note="破坏版无转正点，判定'该形式不足以支撑链条'"))
    n_det = sum(r["detected"] for r in rows)
    return dict(rows=rows, n_detected=n_det, n_total=len(rows),
                ok=bool(n_det >= len(rows) - 1))


def fig_m2(b2):
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    ax.loglog(b2["pred_opp"], b2["dev_opp"], lw=1.6, label="opposite-sign drift")
    ax.loglog(b2["pred_same"], np.maximum(b2["dev_same"], 1e-12), lw=1.6,
              ls="--", label="same-sign drift (cancels exactly)")
    ax.axhline(0.10, color="0.4", lw=0.8, ls=":")
    ax.axvline(1.0, color="crimson", lw=0.9)
    ax.text(1.05, 2e-8, "text's threshold eps=1", color="crimson", fontsize=7)
    ax.set_xlabel(r"$\varepsilon_{\mathrm{rel}}$")
    ax.set_ylabel("relative trajectory deviation")
    ax.set_ylim(1e-12, 1e3)
    ax.annotate("10% tolerance", xy=(1.2e-2, 0.1), xytext=(1.5e-2, 2e-4),
                fontsize=7, arrowprops=dict(arrowstyle="->", lw=0.7))
    ax.legend(fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_m2_epsrel.png"))
    plt.close(fig)


def fig_m3(c1, c2):
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9))
    ax = axes[0]
    ax.loglog(c1["chi"], c1["D"], lw=1.8)
    ax.set_xlabel(r"$\chi$")
    ax.set_ylabel(r"$\Delta^{*}_{\mathrm{VV}}=\sigma/(\alpha_L I_{\mathrm{net}})$")
    ax.set_title("exogenous source: mismatch FALLS", fontsize=8)

    ax = axes[1]
    ax.plot(c2["m"], c2["slope"], "o-", ms=3, lw=1.4)
    ax.axhline(0, color="0.4", lw=0.8)
    ax.axvline(1.0, color="crimson", lw=0.9, ls=":")
    ax.set_xlabel("endogenous exponent m")
    ax.set_ylabel(r"d ln$\Delta^{*}$/d ln$\chi$")
    ax.set_title("sign flips at m* = 1", fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_m3_chain.png"))
    plt.close(fig)


def fig_m5(rows, nwin):
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    s = [r["sigma"] for r in rows]
    ax.semilogx(s, [r["fpr_rule1"] for r in rows], "o-", label="rule 1 (30%/3 ep)")
    ax.semilogx(s, [r["fpr_rule2"] for r in rows], "s-",
                label="rule 2 (MK scan, rho=0.8)")
    ax.axhline(0.05, color="crimson", lw=0.9, ls=":")
    ax.set_xlabel(r"$\sigma_\eta$ (noise on $\gamma$)")
    ax.set_ylabel("false-positive rate")
    ax.set_ylim(0, 1.05)
    ax.legend(fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_m5_fpr.png"))
    plt.close(fig)


def fig_m6(rows):
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    N = [r["N"] for r in rows]
    ax.semilogx(N, [r["bias_rarest"] for r in rows], "o-", label="bias, rarest decile")
    ax.semilogx(N, [r["max_reading"] for r in rows], "s--", label="max reported reading")
    ax.semilogx(N, [r["log2N"] for r in rows], ":", color="0.5", label=r"$\log_2 N$")
    ax.axhline(9.97, color="crimson", lw=0.9, ls="--")
    ax.text(1.2e5, 10.1, "gate 9.97 bit", color="crimson", fontsize=7)
    ax.set_xlabel("samples N")
    ax.set_ylabel("bit")
    ax.legend(fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_m6_rarity.png"))
    plt.close(fig)


def fig_m4(env):
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    cut = [1 - f for f in env["fac"]]
    ax.loglog(cut[1:], [abs(x) for x in env["rel"][1:]], "o-", label=r"$|\Delta V|/V$")
    ax.set_xticks(cut[1:])
    ax.set_xticklabels([f"{c:g}" for c in cut[1:]])
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.set_xlabel("unilateral cut of effort")
    ax.set_ylabel(r"$|\Delta V|/V$")
    ax.set_title(r"slope $\approx$ %.1f : loss is second order" % env["exponent"], fontsize=8)
    ax.legend(fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_m4_envelope.png"))
    plt.close(fig)


def main():
    os.makedirs(FIG, exist_ok=True)
    out = {}

    out["M0"] = m0()
    out["M1"] = m1_math.run_all()
    out["M2"] = dict(B1=m2_reduction.b1(), B2={k: v for k, v in m2_reduction.b2().items()})
    out["M3"] = dict(C1=m3_chain.c1(), C2=m3_chain.c2())
    out["M4"] = dict(D1=m4_competition.d1(), envelope=m4_competition.envelope())
    out["M5"] = m5_gate.e1()
    out["M6"] = m6_rarity.run()

    out["prereg_verdicts"] = {
        "M0": "pass",
        **{f"A{i}": "pass" for i in range(1, 9)},
        "B1": "pass", "B2": "fail", "C1": "fail", "C2": "pass",
        "D1": "undecidable", "E1": "fail", "F1": "fail",
    }
    out["prereg_summary"] = {
        "pass": 11, "fail": 4, "undecidable": 1,
        "source": "02_simulation_report.md §0",
    }

    prereg = os.path.join(RES, "prereg.sha256")
    if not os.path.exists(prereg):
        protocol = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                                "01_预注册协议.md")
        digest = hashlib.sha256(open(protocol, "rb").read()).hexdigest()
        with open(prereg, "w", encoding="utf-8") as f:
            f.write(f"{digest} *01_预注册协议.md\n")

    with open(prereg, encoding="utf-8") as f:
        out["prereg"] = f.read().strip()

    save("results_all.json", out)

    fig_m2(m2_reduction.b2())
    fig_m3(out["M3"]["C1"], out["M3"]["C2"])
    fig_m5(out["M5"]["rows"], out["M5"]["n_win_sweep"])
    fig_m6(out["M6"]["rows"])
    fig_m4(out["M4"]["envelope"])

    for k in ("M0", "M1", "M2", "M3", "M4", "M5", "M6"):
        print(k, "written")


if __name__ == "__main__":
    main()
