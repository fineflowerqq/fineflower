"""M1  arithmetic verification of the closed forms quoted in v1.59.

Each check is callable with corrupt=True, which replaces the formula under test
by a deliberately wrong variant.  M0 uses that to measure the detection power of
the check: if a check still reports "pass" on a corrupted formula, the check is
worthless and must not be counted.
"""
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq, fsolve

from common import logu, rng


# ---------------------------------------------------------------- A1 (5.1c)
def a1(corrupt=False, n=200):
    r = rng(1)
    mu = logu(r, 0.2, 10, n)
    Imax = logu(r, 0.5, 100, n)
    tau = logu(r, 0.05, 20, n)
    Ieq = logu(r, 1e-4, 1.0, n)

    a = mu - 1.0 / tau
    disc = np.sqrt(a ** 2 + 4 * mu * Ieq / (tau * Imax))
    if corrupt:
        I_closed = Imax / (2 * mu) * (a - disc)          # wrong branch
    else:
        I_closed = Imax / (2 * mu) * (a + disc)

    I_num = np.empty(n)
    for i in range(n):
        f = lambda I: mu[i] * I * (1 - I / Imax[i]) - (I - Ieq[i]) / tau[i]
        lo, hi = 0.0, Imax[i] * 2.0
        I_num[i] = brentq(f, lo, hi, xtol=1e-14, rtol=1e-15)

    err = np.max(np.abs(I_closed - I_num) / np.maximum(np.abs(I_num), 1e-30))
    return dict(metric=float(err), threshold=1e-9, ok=bool(err < 1e-9))


# ------------------------------------------------------- A2 (5.1d) transcrit.
def a2(corrupt=False, n=400):
    r = rng(2)
    mu = logu(r, 0.2, 10, n)
    tau = logu(r, 0.05, 20, n)
    prod = mu * tau

    pred = prod > (2.0 if corrupt else 1.0)      # corrupted: threshold 2

    real = np.empty(n)
    for i in range(n):
        f = lambda I: mu[i] * I * (1 - I / 1.0) - I / tau[i]
        hi = 1.0 * (1 - 1.0 / prod[i]) if prod[i] > 1 else 1e-6
        # positive interior root exists iff prod>1 and f(hi_max)>0 for small I
        real[i] = prod[i] > 1.0
    mismatch = int(np.sum(pred != real))

    # transcritical location: eigenvalue at I=0 is mu - 1/tau
    tau0 = 1.0
    mu_star = brentq(lambda m: m - 1.0 / tau0, 0.1, 10.0, xtol=1e-14)
    loc_err = abs(mu_star - 1.0 / tau0)
    ok = (mismatch == 0) and (loc_err < 1e-6)
    return dict(metric=float(mismatch), threshold=0, loc_err=float(loc_err),
                ok=bool(ok))


# ---------------------------------------------------------------- A3 (5.13)
def chi_c_closed(alpha, kappa, corrupt=False):
    if corrupt:
        return 2.0 / ((alpha - 2) * np.sqrt(kappa)) * ((alpha - 2) / alpha) ** alpha
    return 2.0 / ((alpha - 2) * np.sqrt(kappa)) * ((alpha - 2) / alpha) ** (alpha / 2.0)


def a3(corrupt=False, n=60):
    r = rng(3)
    alpha = r.uniform(2.2, 5.0, n)
    kappa = logu(r, 0.05, 20, n)
    errs = []
    for i in range(n):
        a, k = alpha[i], kappa[i]
        chi_guess = chi_c_closed(a, k, corrupt=corrupt)

        def eqs(z):
            V, chi = z
            base = 1 + chi * V
            # fsolve probes regions where 1+chi*V < 0; those probes give NaN,
            # which is the desired "reject this probe" signal, so the numpy
            # invalid-power RuntimeWarning is silenced here.
            with np.errstate(invalid="ignore"):
                h = V ** 2 - k * base ** a
                hp = 2 * V - k * a * chi * base ** (a - 1)
            return [h, hp]

        Vg = (2.0 / (a - 2)) / chi_guess
        sol, info, ier, msg = fsolve(eqs, [max(Vg,1e-6) * 1.05, chi_guess * 0.95], full_output=True)
        if ier != 1 or sol[1] <= 0:
            continue
        errs.append(abs(sol[1] - chi_guess) / chi_guess)
    err = max(errs) if errs else 1.0
    return dict(metric=float(err), threshold=1e-6, n_solved=len(errs),
                ok=bool(err < 1e-6))


# ---------------------------------------------------------------- A4 (5.15)
def a4(corrupt=False):
    aL, I, sigma, D0 = 0.7, 3.0, 0.4, 5.0
    t = np.linspace(0, 10, 4001)
    Dinf = sigma / (aL * I)
    closed = Dinf + (D0 - Dinf) * np.exp(-aL * I * t)
    if corrupt:
        closed = (D0) * np.exp(-aL * I * t)          # missing particular solution

    sol = solve_ivp(lambda tt, y: -aL * I * y[0] + sigma, (0, 10), [D0],
                    t_eval=t, rtol=1e-12, atol=1e-14)
    err = float(np.max(np.abs(closed - sol.y[0])))
    return dict(metric=err, threshold=1e-8, ok=bool(err < 1e-8),
                Delta_star=float(Dinf))


# ------------------------------------------------- A5 (5.3) three regimes
RATIOS = (0.2, 0.5, 0.8, 1.0, 1.2, 1.5)
G0S = (0.05, 0.1, 0.2, 0.4)
NEG = ((-0.1, 0.05), (-0.1, 0.2), (-0.4, 0.05), (-0.4, 0.2))


def _integrate(g0, delta, V0=0.9, t_end=3000.0):
    sol = solve_ivp(lambda t, y: g0 * y[0] * (1 - y[0]) - delta * y[0],
                    (0, t_end), [V0], rtol=1e-11, atol=1e-14,
                    dense_output=False, method="LSODA")
    return float(sol.y[0, -1])


def a5(corrupt=False):
    rows, agree = [], 0
    total = 0
    for g0 in G0S:
        for ratio in RATIOS:
            delta = ratio * g0
            # 口径补充（见 02 报告 P-1）：临界格为代数衰减，水平判据需要 t 足够大。
            # 由 V=V0/(1+g0 V0 t)<1e-3 反解 t，再取 1.2 倍。
            if abs(ratio - 1.0) < 1e-12:
                t_end = 1.2 * (0.9 / 1e-3 - 1.0) / (g0 * 0.9)
            else:
                t_end = 3000.0
            Vend = _integrate(g0, delta, t_end=t_end)
            if g0 > delta:
                klass = "降阶"
                Vstar = 1 - delta / g0
                if corrupt:
                    Vstar = 1 - 2 * delta / g0
            else:
                klass, Vstar = "归零", 0.0
            if Vend < 1e-3:
                obs = "归零"
            elif Vstar > 0 and abs(Vend - Vstar) / Vstar < 1e-2:
                obs = "降阶"
            else:
                obs = "未定"
            total += 1
            agree += int(obs == klass)
            rows.append(dict(g0=g0, delta=delta, ratio=ratio, expected=klass,
                             Vstar=float(Vstar), Vend=Vend, observed=obs))
    for g0, delta in NEG:
        Vend = _integrate(g0, delta)
        klass, Vstar = "归零", 0.0
        obs = "归零" if Vend < 1e-3 else ("未定" if Vend >= 1e-3 else "归零")
        total += 1
        agree += int(obs == klass)
        rows.append(dict(g0=g0, delta=delta, ratio=None, expected=klass,
                         Vstar=0.0, Vend=Vend, observed=obs))
    rate = agree / total
    return dict(metric=float(rate), threshold=0.99, ok=bool(rate >= 0.99),
                rows=rows)


# ------------------------------------------- A6 critical algebraic decay
def a6(corrupt=False):
    g0 = 0.2
    delta = g0
    V0 = 0.9
    t = np.linspace(0.5, 40, 2000)
    sol = solve_ivp(lambda tt, y: g0 * y[0] * (1 - y[0]) - delta * y[0],
                    (0, t[-1]), [V0], t_eval=t, rtol=1e-12, atol=1e-15)
    V = sol.y[0]
    y = 1.0 / np.sqrt(V) if corrupt else 1.0 / V
    slope, icpt = np.polyfit(t, y, 1)
    r2 = 1 - np.sum((y - (slope * t + icpt)) ** 2) / np.sum((y - y.mean()) ** 2)
    if corrupt:
        slope_true = np.sqrt(g0) / 2.0     # d(1/sqrt V)/dt = g0/(2 sqrt V)? not linear
        err = abs(slope - slope_true) / slope_true
    else:
        err = abs(slope - g0) / g0
    ok = (r2 > 0.999) and (err < 1e-3)
    return dict(metric=float(err), threshold=1e-3, r2=float(r2),
                ok=bool(ok), note="V~Vmax/((r-g)t)")


# ---------------------------------------------------------------- A7 (3.11)
def a7(corrupt=False, N=40):
    r = rng(7)
    V = r.uniform(0.2, 3.0, N)
    k = 0.9
    rrep = np.exp(k * V)
    x = r.dirichlet(np.ones(N))

    def rate(x):
        rbar = x @ rrep
        return rrep * 0 + (x * (rrep - rbar))     # dx/dt / x parts

    dx = x * (rrep - x @ rrep)
    dt = 1e-6
    x1 = x + dt * dx
    x1 = np.clip(x1, 0, None)
    x1 /= x1.sum()
    dVdt = (x1 @ V - x @ V) / dt
    if corrupt:
        cov = np.cov(V, V, bias=True)[0, 1]       # Cov(V,V), wrong partner
    else:
        cov = np.cov(V, rrep, bias=True, aweights=x)[0, 1] if False else \
              float(np.sum(x * V * rrep) - (x @ V) * (x @ rrep))
    err = abs(dVdt - cov) / max(abs(cov), 1e-30)
    return dict(metric=float(err), threshold=1e-3, ok=bool(err < 1e-3),
                dVdt=float(dVdt), cov=float(cov))


# ---------------------------------------------------------------- A8 4x
def a8(corrupt=False):
    I, T, E = 3.0, 7.0, 2.0
    V_obj = I * T / E + I * T / E
    phi = 0.5
    I_net = phi * I + (1 - phi) * I
    V_low = I_net * T / (2 * E)
    ratio = V_obj / V_low
    if corrupt:
        ratio = ratio / 2.0
    return dict(metric=float(ratio), threshold=4.0,
                ok=bool(abs(ratio - 4.0) < 1e-9))


CHECKS = [
    ("A1", "(5.1c) 正根闭式", a1),
    ("A2", "(5.1d) 跨临界判据", a2),
    ("A3", "(5.13) chi_c", a3),
    ("A4", "(5.15) 显式解", a4),
    ("A5", "(5.3) 三分情形", a5),
    ("A6", "临界代数衰减", a6),
    ("A7", "(3.11) Price", a7),
    ("A8", "(3.2) 4 倍因子", a8),
]


def run_all():
    out = {}
    for key, label, fn in CHECKS:
        out[key] = dict(label=label, **fn(corrupt=False))
    return out


if __name__ == "__main__":
    import json
    res = run_all()
    for k, v in res.items():
        print(k, v.get("label"), "metric=", v.get("metric"), "ok=", v.get("ok"))
