# Simulation patch (numerical-verification input for v1.59 → v1.60)

**LiangRuifeng** | 2026 | companion to `13_v1.59/`, not merged into v1.59

---

## In one sentence

This patch adds no theoretical claim. It does the one thing v1.59 did not do: **it takes the formulas that could be miscomputed, the inferences that may not follow, and the protocols that may not be executable in the six volumes, puts each of them in a position where it can fail, runs it, and discloses which ones actually failed.**

## 1. Why v1.59 needs a patch of this kind

v1.59 has 248 numbered equations and 10 falsifiable predictions (Volume I, Appendix C); the words "testable" and "falsifiable" appear densely in the text, yet **there is not a single numerical check**. This is not an oversight but a trade-off: the preprint's space went entirely into stating the strength of each claim precisely (each with a three-line summary and failure conditions), which is the methodologically scarcer work.

The cost is that the other job was left undone: **a carefully written formula can still be wrong.** A copied coefficient in a closed form, a sign flipped in a bifurcation criterion, a term dropped in a reduction — none of these are caught by a "three-line summary"; they are caught only by substituting numbers and computing. Version 0.0 once had "Appendix X: five-fold recursive numerical simulation", with three conclusions, one hand-picked parameter set, no null model, and no power calibration; it could neither be refuted nor count as evidence, and v1.59 deleted it — correctly. What this patch does is replace **that kind** of simulation with the kind that **can be refuted**.

## 2. Three hard constraints (the line separating this from decoration)

| Constraint | Requirement | Counter-example (approach rejected here) |
| :-- | :-- | :-- |
| **Must be able to fail** | For every test, state first "what result counts as failure"; the failure and pass criteria are mutually exclusive | Produce a figure → look at it → declare "consistent with theory" |
| **Must have test power** | Deliberately corrupt the claim under test; if the test still passes, the test is void (calibrated uniformly by M0) | Run the correct formula once and note that the error is naturally tiny |
| **Layered reporting** | A pass may only be reported as "no arithmetic error detected", never as "the theory is verified" | Present arithmetic checking as empirical support for the theory |

M0 corrupts each of the 10 tests once (sign flip, exponent change, removal of a key factor, change of the driving-force form); **10/10 are detected** (`results/results_all.json` → `M0`). This item is a precondition for every conclusion below: without it, the "passes" cannot be interpreted.

## 3. What it can and cannot do

| Layer | Simulation can | Simulation cannot | Corresponding modules in this patch |
| :-- | :-- | :-- | :-- |
| I Arithmetic | Detect computation errors | Test whether the theory is true | M1 (8 items) |
| II Structural | Detect internal inconsistency and "written but not derivable" | Judge whether reality is like this | M2, M3, M4 |
| III Protocol | Measure false-positive rates and resolution limits | Replace real experiments | M5, M6 |

**This patch neither falsifies nor supports SRVD.** What it provides is five places that **must be reworded** (R-1—R-5, ordered by severity), four places that **must carry a caveat** (R-6 precondition, R-7 dual provenance, R-8 universal statement, R-9 Appendix F), and a reproducible arithmetic working paper. Any reading of this as "numerically validating the framework" goes beyond the evidence it can supply.

## 4. Directory layout and reproduction

```
batch_A/
├─ 00_batch_notes.md         this file
├─ 01_预注册协议.md          criteria, thresholds, seeds (written before running; hash in results/prereg.sha256)
├─ 02_simulation_report.md   results, verdicts, protocol-deviation disclosure
├─ 03_v1.60_revision_notes.md  R-1—R-9, each a directly replaceable edit
├─ sim/                      code (7 modules + runner)
├─ results/results_all.json  all numerical outputs
└─ figure/                   5 figures (English labels, for typesetting)
```

Reproduction:

```bash
cd sim && python run_all.py      # Python 3.13 / numpy 2.5 / scipy 1.18 / matplotlib 3.11
```

The full pipeline takes about 75 seconds, with no external data, no network, and no unseeded randomness (seed `20261103`, with per-module offsets). `results/prereg.sha256` was created before the first run; `run_all.py` creates it only if it is missing and otherwise never rewrites it, so the criterion text can be checked for post-hoc edits.

The hash-locked protocol `01_预注册协议.md` still uses the original file names: `02_仿真报告.md` is now `02_simulation_report.md`, and `03_v1.60修改意见.md` is now `03_v1.60_revision_notes.md`.

## 5. Summary of conclusions

**Distribution of preregistered verdicts**: 11 pass (M0 test-power calibration + A1—A8 arithmetic checks + B1 reduction equivalence + C2 remediation form), 4 fail (B2 criterion, C1 chain sign, M5 gating, M6 resolution), 1 undecidable (M4: insufficient power + grid change; see P-2 and P-3 in §8 of the report). The C1 failure is at the **level of the theoretical text** (step (1) of the chain does not follow within this model), whereas B2, M5, and M6 are at the **criterion/protocol level**.

The five places that must be reworded, ordered by severity:

| ID | Location | In one sentence | Severity |
| :-: | :-- | :-- | :-- |
| **R-1** | Vol. I, end of §5.1.2 ($\varepsilon_{\mathrm{rel}}$) | The criterion uses the wrong quantity (a sum instead of a difference), and the threshold "${\approx}1$" tolerates a 75-fold deviation | Would mark a usable reduction as invalid, and also let a genuinely invalid one pass |
| **R-2** | Vol. I, §5.3 gap, §5.4 chain step (1) | Under an exogenous source term the deviation **decreases** with $\chi$ (elasticity $-2/(2-\alpha_{\mathrm{eff}})$); the chain requires source exponent $m>1$ | The core narrative is currently not a model inference |
| **R-3** | Vol. I, §8.4 competitive-dissipation constraint | Missing the premise that "the contested resource is a private good and the released energy has no survival value"; the envelope argument shows the claim depends on strong premises | Its own refutation condition would trigger under a commons or storable budget |
| **R-4** | Vol. I, §8.3 + Appendix C H7 | The gating rule's false-positive rate can reach 100% (multiple testing + the iid assumption of MK + $n_{\mathrm{win}}$ not locked) | H7 is therefore **unfalsifiable** — its refutation condition can hardly ever hold |
| **R-5** | Vol. I, §2.1 measurement contract and the $\alpha_0$ gate | The resolution ceiling for plugin rarity is $\log_2N$; $\alpha_0=10^{-3}$ (9.97 bit) is unreachable at $N=10^3$ | A gate written into the main text cannot be measured under this protocol |

R-6—R-9 change no conclusion; they only affect how readers use the conclusions and the numbers. R-9 institutionalizes the arithmetic checks to prevent transcription errors in later versions.

## 6. Relation to the version chain

- This patch **modifies not a single byte** of `13_v1.59/`; the scope of `SHA256SUMS.txt` does not include this directory.
- Its output is an **input** to v1.60, not part of v1.60. Whether to merge, and how many items, is for the next version to decide by the v1.59 merge standard: **merge only items that depend on no uncalibrated parameter and that either reduce degrees of freedom or correct an error**. R-1, R-4, and R-5 qualify; R-2 qualifies (narrowing "no source term given" to "no lower bound on the exponent given"); R-3 requires a decision on whether to accept its premise first.
- If reproduction fails (the reader's numbers differ from this report), **the code and seeds govern**, not the numbers in the report; please attach the location of the discrepancy in `results_all.json`.

---

*Criteria are in `01_预注册协议.md`, per-item results and deviation disclosure in `02_simulation_report.md`, and the proposed edits in `03_v1.60_revision_notes.md`.*
