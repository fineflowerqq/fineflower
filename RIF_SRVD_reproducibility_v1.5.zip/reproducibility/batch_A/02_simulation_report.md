# Simulation report (v1.59 patch)

**LiangRuifeng** | 2026 | criteria in `01_预注册协议.md`

---

## 0  Verdict summary

| ID | Object of test | Layer | Criterion | Measured | Verdict |
| :-: | :-- | :-: | :-- | :-- | :-: |
| **M0** | Test-power calibration (10 items) | — | Corruption must be detected | 10/10 detected | **Pass** |
| **A1** | (5.1c) closed form of the positive root | I | relative error $<10^{-9}$ | $1.6\times10^{-10}$ | Pass |
| **A2** | (5.1d) transcritical criterion | I | 100% sign agreement; sign-change location error $<10^{-6}$ | 0 disagreements; location error $0$ | Pass |
| **A3** | (5.13) $\chi_{\mathrm c}$ | I | relative error $<10^{-6}$ | $2.9\times10^{-10}$ (60 cases) | Pass |
| **A4** | (5.15) explicit solution | I | max absolute error $<10^{-8}$ | $1.0\times10^{-12}$ | Pass |
| **A5** | (5.3) three-case classification + $V^{*}$ | I | agreement rate $\ge99\%$; $V^{*}$ error $<10^{-3}$ | $28/28$; $V^{*}$ error $<10^{-15}$ | Pass |
| **A6** | Critical algebraic decay | I | $R^2>0.999$; slope error $<10^{-3}$ | $R^2=1.000$; $1.8\times10^{-13}$ | Pass |
| **A7** | (3.11) Price covariance | I | relative error $<10^{-3}$ | $1.4\times10^{-10}$ | Pass |
| **A8** | §3.2 "differ by a factor of 4" | I | $=4\pm10^{-9}$ | $4.000000000$ | Pass |
| **B1** | (5.2) is the image of (5.1a) | II | trajectory deviation $<10^{-6}$ | $5.3\times10^{-12}$ | Pass |
| **B2** | $\varepsilon_{\mathrm{rel}}$ failure criterion | II | $\varepsilon_{\mathrm{rel}}^{*}\ge1$ | $0.022$ | **Fail** |
| **C1** | §5.4 chain step (1) | II | report elasticity sign and decidability | $-4.00$ ($R^2=0.99999999999$) | **Fail** |
| **C2** | Critical exponent $m^{*}$ of an endogenous source | II | agrees with the analytic value $1.00$ | $1.000$ | Pass |
| **D1** | §8.4 competitive-dissipation constraint | II/III | counter-example cells $\le20\%$ | see §4 (insufficient power + grid change) | **Undecidable** |
| **E1** | §8.3 gating rule | III | FPR $\le5\%$ when $\sigma_\eta\le0.1$ | rule 1: $3.6\%$ / rule 2: $100\%$ | **Fail** |
| **F1** | Resolution of rarity readings | III | rarest 10% deviation $<0.1$ bit | $1.14$ bit ($N=10^2$) | **Fail** |

**11 pass, 4 fail, 1 undecidable.** Among the passes, M0 is a meta-test and 8 items are at the arithmetic layer — the arithmetic layer shows only that nothing was miscomputed, not that anything is correct; B1 and C2 are at the structural layer, showing respectively that "the reduction equivalence holds" and that "the remediation form has a sign-reversal point".

**Reading `results_all.json`.** The `ok` flags inside individual modules are local numerical checks (for example, whether a closed form matches its numerical solution); they are not preregistered verdicts. The preregistered verdict for each item is given by the table above and mirrored in the `prereg_verdicts` / `prereg_summary` fields of `results_all.json`. In particular, C1 has `ok: true` while its preregistered verdict is Fail, because the check confirms the sign that the report records, not the claim; B2 has no `ok` flag; D1 is Undecidable.

---

## 1  M0  Test-power calibration (read this section first)

Corrupt the formula under test in each check on purpose and see whether the test raises an alarm:

| Corruption | Item | Still passes after corruption? | Detected |
| :-- | :-: | :-: | :-: |
| (5.1c) take the minus branch (negative root) | A1 | No | ✓ |
| (5.1d) threshold changed from 1 to 2 | A2 | No | ✓ |
| (5.13) exponent $\alpha/2\to\alpha$ | A3 | No (solved $\chi_{\mathrm c}$ off by 488%) | ✓ |
| (5.15) drop the particular-solution term $\sigma/(\alpha_{\mathrm L}I)$ | A4 | No | ✓ |
| $\delta/(r_{\mathrm v}-\gamma_0)\to2\delta/(r_{\mathrm v}-\gamma_0)$ in $V^{*}$ | A5 | No | ✓ |
| Critical decay fitted as $1/\sqrt{V}$ | A6 | No | ✓ |
| $\operatorname{Cov}(V,r)\to\operatorname{Cov}(V,V)$ | A7 | No | ✓ |
| 4-fold factor written as 2-fold | A8 | No | ✓ |
| Drop the $(1-\gamma_0/r_{\mathrm v})$ factor from $V_{\max}$ | B1 | No | ✓ |
| Source driving force $\chi V\to\chi$ | C2 | No (no sign-reversal point) | ✓ |

10/10 detected. **This table is the passport for every "pass" below**: without it, an identically zero error could be read as "strong agreement".

---

## 2  M1  Arithmetic checks

Except for A5 and A6, all figures are maximum errors over 200—400 random parameter sets (log-uniform, seed `20261103`). Key points:

- **(5.1c) and (5.1d) agree**: the closed form for $I^{*}$ and numerical root-finding agree to within $10^{-10}$; the eigenvalue with $I=0$ does change sign at $\mu_{\mathcal F}\tau_{\mathrm{decay}}=1$, and that point is indeed the transcritical bifurcation point, consistent with the text's statement that it is "not a saddle-node".
- **(5.13) can be re-derived**: on 60 sets of $(\alpha_{\mathrm{eff}},\kappa)$, solving $h(V)=h'(V)=0$ independently for the saddle-node location differs from the closed form by $<3\times10^{-10}$. The derivation can be checked by hand: from $u=\chi V$ and $2=\alpha_{\mathrm{eff}}u/(1+u)$ one gets $u=2/(\alpha_{\mathrm{eff}}-2)$, and back-substitution gives (5.13).
- **The three cases are exhaustive**: the reduced cell with $g_0>0$ converges to $V^{*}=1-\delta/g_0$ (error $<10^{-15}$), $g_0\le\delta$ goes to zero, and $g_0<0$ accelerates to zero; at the critical cell $g_0=\delta$ the algebraic decay slope differs from $g_0$ by $1.8\times10^{-13}$, and the $1/V$ linearity gives $R^2=1.000$.
- **(3.11) is an identity**: the numerical replicator derivative differs from $\operatorname{Cov}(V,r)$ by $10^{-10}$; replacing $r$ with a non-monotone function does make the relation fail (not tabulated; see the control branch of `a7` in the code).
- **The 4-fold factor**: the ratio of $2IT/E$ to $I_{\mathrm{net}}T/E_{\mathrm{eff}}$ is exactly 4.

**What this section proves**: the 8 core formulas of v1.59 contain no arithmetic error and can safely be cited by later literature.
**What it does not prove**: self-consistency of a formula does not mean its premises hold. A1—A8 all passing says nothing about whether SRVD describes the world.

---

## 3  M2  Reduction equivalence and $\varepsilon_{\mathrm{rel}}$

### B1  Equivalence holds (pass)

With $c=2$, $\mu_{\mathcal F}=1.3$, $\tau_{\mathrm{decay}}=1$, $I_{\max}=5$, $I_{\mathrm{eq}}=0$, and the v1.59 coefficient mapping $r_{\mathrm v}=\mu_{\mathcal F}$, $\gamma_0=\tau_{\mathrm{decay}}^{-1}$, $V_{\max}=cI_{\max}(1-\gamma_0/r_{\mathrm v})=2.3077$, integrating for 40 time units gives a maximum relative deviation of $5.3\times10^{-12}$ between the two trajectories.

**The core assertion of 0-1/0-3, that "the two forms give the same trajectory within this window", holds numerically.** This is worth recording because it is refutable: if $V_{\max}$ lacked the $(1-\gamma_0/r_{\mathrm v})$ factor, the deviation immediately rises to $O(1)$ (see M0).

### B2  The failure criterion takes an inappropriate value (fail)

The design intent of $\varepsilon_{\mathrm{rel}}$ is "how large is the drift of time and energy through the causal channel relative to the drift of $I_c$". Two measurements:

| Drift direction | Measured $\varepsilon_{\mathrm{rel}}^{*}$ corresponding to a 10% deviation | Text threshold |
| :-- | --: | --: |
| $\dot T_c/T_c$ and $\dot E_c/E_c$ of **opposite sign** | $0.0220$ | $\approx1$ |
| Same sign, same magnitude | does not exist (deviation is identically 0) | $\approx1$ |

- For opposite signs, the text threshold of 1 tolerates a deviation of $e^{gW}-1=75.2$ fold ($gW=4.33$). The analytic expression $\varepsilon_{\mathrm{rel}}^{*}=\ln(1+\delta)/(gW)$ differs from the measurement by $0.2\%$.
- For the same sign, $V_c\propto I_cT_c/E_c$ depends only on the **difference** $\dot T_c/T_c-\dot E_c/E_c$, so the deviation is identically zero; yet the text criterion uses the **sum of absolute values**, which reports "failure" in this case — misjudging a usable reduction as invalid.

**Cause**: $V_c$ depends on the ratio $T_c/E_c$, not on a sum. The criterion treats "the drifts of two quantities" as "the sum of the drifts of each", discarding the direction information. The fix is R-1.

---

## 4  M3  The sign of path two and the endogenous source term

### C1  Step (1) of the chain does not follow (fail)

By §5.3's own algebra, $\Delta^{*}_{\mathrm{VV}}=\sigma/(\alpha_{\mathrm L}I_{\mathrm{net}})$. In the $I$–$V$ subsystem of Eq. (5.12), with $\alpha_{\mathrm{eff}}=1.5$, $\kappa=1$, scanning $\chi\in[10^{-1.5},10^{2.5}]$, the tail elasticity of the equilibrium deviation with respect to $\chi$ is:

$$
\frac{\mathrm d\ln\Delta^{*}_{\mathrm{VV}}}{\mathrm d\ln\chi}\;\longrightarrow\;-\frac{2}{2-\alpha_{\mathrm{eff}}}=-4.00
\quad(\text{measured }-3.99999999,\ R^2=0.99999999999)
$$

As $\chi$ rises from $0.032$ to $208$, $\Delta^{*}$ falls monotonically from $0.97$ to $5.3\times10^{-10}$ (left panel of `fig_m3_chain.png`; the slope is constantly $-4$ on log–log axes). That is: **the stronger the self-referential coupling, the smaller the equilibrium decoupling deviation**. This is opposite in direction to step (1) of (5.17), which says "$V^{\mathrm{virt}}\uparrow\Rightarrow$ deviation amplified".

The closing paragraph of §5.3 already notes this itself ("$\chi$ amplifies $I_{\mathrm{net}}$ yet lowers the equilibrium deviation… this is not an inference of the present model"); this patch merely turns it from "a gap acknowledged by the author" into "a quantitative conclusion supported by both numerical and analytic evidence", and gives the necessary condition for remediation (C2).

### C2  The minimal form required for remediation (pass)

Make the source term endogenous: $\sigma=\sigma_0+a(\chi V)^{m}$, then

$$
\frac{\mathrm d\ln\Delta^{*}}{\mathrm d\ln\chi}=\underbrace{\frac{2m}{2-\alpha_{\mathrm{eff}}}}_{\text{source term}}\;-\;\underbrace{\frac{2}{2-\alpha_{\mathrm{eff}}}}_{\text{denominator }I_{\mathrm{net}}}\;=\;\frac{2}{2-\alpha_{\mathrm{eff}}}(m-1)
$$

**The sign-reversal point is $m^{*}=1$, independent of $\alpha_{\mathrm{eff}}$.** The numerical scan gives $m^{*}=1.000$, with the slope exactly $4(m-1)$ (right panel). If the driving force is miswritten as $\chi$ (dropping the self-consistent amplification $V$), no sign-reversal point exists — this is exactly the corruption test for C2 in M0.

**Implication**: a necessary condition for step (1) of (5.17) is that **the endogenous source term is superlinear in the self-referential drive** ($m>1$). This is not sufficient, and $m$ cannot be derived from the existing parameters; its value lies in narrowing the gap "no source term given" to "no lower bound given on the source exponent", which is a net reduction in degrees of freedom. The testable implication is in R-2.

---

## 5  M4  Competitive-dissipation constraint (undecidable)

### Preregistered verdict: undecidable

- Under the preregistered protocol ($V_{\min}$ death for 3 consecutive periods, other agents best-responding), running 12 cells × 20 seeds: **the share of seeds in which the intervention group survives longer is $\le10\%$ in every cell**, the counter-example cell fraction is $0/12$, which on the surface means "the claim holds".
- But **the power is insufficient**: in 11 of the 12 cells the median survival time equals the cap $T=150$ (no one dies), so the comparison degenerates to $150$ versus $150$. Death occurs only in the cell $(I_0,\text{commons intensity})=(0.1,0)$ (control median 11 periods), where the intervention group's win rate is $10\%$.
- Moreover, the grid was changed during execution (see P-3), so this module **yields no verdict**, only two observations.

### Observation 1: the envelope argument (post hoc, not preregistered)

At a symmetric interior equilibrium, each agent is by definition located at $\partial V/\partial e=0$. Hence a unilateral cut in effort reduces $V$ only to **second order**, whereas the energy budget released is **first order**. Measured ($I_0=0.5$, $R=1$, averaged over 8 repetitions):

| Effort cut | $1$ | $10\%$ | $20\%$ | $50\%$ | $80\%$ |
| :-- | --: | --: | --: | --: | --: |
| $V$ | $0.521212$ | $0.521193$ | $0.520833$ | $0.517304$ | $0.509031$ |
| $\Delta V/V$ | $0$ | $-4\times10^{-5}$ | $-7.3\times10^{-4}$ | $-7.5\times10^{-3}$ | $-2.3\times10^{-2}$ |

Cutting effort by 50% lowers $V$ by only **0.75%**; cutting by 80% lowers it by 2.3% (fitted order 2.42, limited by grid discretization; the magnitude is 2). The energy budget released is 50% and 80%.

### Observation 2: one line of algebra (analytic, not simulation)

$$
V^{\text{stay}}=\frac{I_0+sR}{E+e},\qquad V^{\text{exit}}=\frac{I_0}{E}
$$

Exit is fatal $\iff I_0/E<V^{\text{stay}}$, i.e. **the contested resource must be necessary for survival**. This condition appears in §5.5 "coexistence game" ("if resources are abundant, no conquest occurs"), but is **absent** from the prediction in §8.4.

**Conclusion**: the §8.4 prediction is missing a premise, not wrong. The missing premise is precisely that "the contested resource is a private good (rival and excludable) and the energy released has no survival value (not storable, not divertible)". In a world of commons or a storable budget, exit both saves cost and keeps the resource, so its built-in refutation condition ("survival time lengthens markedly after reducing effort") would be met. The fix is R-3.

---

## 6  M5  Discriminative power of the gating rule (fail)

The object under test is the **rule** in §8.3, not the theoretical content of H7. Null model: the $\gamma_{\mathrm{RL}}$ series of a healthy system, $\gamma_t=\gamma_0(1+\eta_t)$, with $\eta$ AR(1), $\rho=0.8$.

| Noise $\sigma_\eta$ | $0.01$ | $0.02$ | $0.05$ | $0.1$ | $0.2$ | $0.5$ |
| :-- | --: | --: | --: | --: | --: | --: |
| Rule 1 (30% drop over 3 rounds) FPR | $0$ | $0$ | $0$ | $0.036$ | $\mathbf{0.676}$ | $\mathbf{0.988}$ |
| Rule 2 (MK scan, $n_{\mathrm{win}}=10$) FPR | $1.0$ | $1.0$ | $1.0$ | $1.0$ | $1.0$ | $1.0$ |

The $100\%$ for rule 2 comes from two independent causes acting together; measured separately:

| Condition | $n_{\mathrm{win}}=5$ | $10$ | $20$ | $40$ |
| :-- | --: | --: | --: | --: |
| Single window, $\rho=0$ (iid) | — | $0.021$ | $0.020$ | $0.019$ |
| Single window, $\rho=0.8$ | — | $\mathbf{0.173}$ | $\mathbf{0.223}$ | $\mathbf{0.241}$ |
| Full-series scan, $\rho=0.8$ | $0.832$ | $1.000$ | $1.000$ | $0.996$ |

- **Autocorrelation**: the Mann–Kendall variance formula assumes independent samples; with $\rho=0.8$ in the $\gamma$ series, the nominal $5\%$ becomes $17\%$—$24\%$.
- **Multiple testing**: scanning a 200-step series with a 5-step sliding window gives 35 tests at $5\%$ each, for a family-wise error rate of about $1-0.95^{35}=83\%$; the text locks neither the test time nor $n_{\mathrm{win}}$, and the more frequently one scans, the higher the false-positive rate.

**Consequence (the most important sentence in this section)**: the refutation condition of H7 is "the system collapses but no decline was detected beforehand". When the false-positive rate of "detection" is 100%, **the refutation condition can hardly ever hold**, so H7 is not a falsifiable prediction but a tautology. The direction favours the theory, which is why it is easiest to overlook. The fix is R-4.

---

## 7  M6  Resolution of rarity readings (fail)

True background $K=50$, Zipf($s=1$), 500 resamples per cell:

| $N$ | Share of unobserved categories | Median deviation of the rarest 10% categories | Max reportable reading (bit) | $\log_2N$ |
| --: | --: | --: | --: | --: |
| $10^2$ | $36.5\%$ | $-1.14$ | $6.64$ | $6.64$ |
| $10^3$ | $0.2\%$ | $+0.15$ | $9.26$ | $9.97$ |
| $10^4$ | $0$ | $+0.009$ | $8.07$ | $13.29$ |
| $10^5$ | $0$ | $-0.002$ | $7.85$ | $16.61$ |

Three readings:

1. **The ceiling is first capped by $\log_2N$ and then inflated by small counts**: at $N=10^2$ the maximum reportable reading is $6.64=\log_2 100$, 1.2 bit below the true rarest value $7.85$; at $N=10^3$ the ceiling rises to $9.26$, now 1.4 bit above the true value (categories with a count of 1 make the probability underestimate); at $N\ge10^4$ it falls back and converges to $7.85$. The two errors point in opposite directions and both are of order 1 bit, so **they can be neither removed unilaterally by "taking more samples" nor left unlabelled in a report**.
2. **The deviation is two-sided**: at $N=10^2$ it is low by 1.14 bit (unobserved categories are dropped, leaving only the high-frequency ones), at $N=10^3$ it is high by 0.15 bit (small counts underestimate the probability), and only at $N\ge10^4$ does it converge to within $0.01$ bit.
3. **The gate is unreachable**: $\alpha_0=10^{-3}$ in §2.1 corresponds to a threshold of $-\log_2\alpha_0=9.97$ bit; the measured ceiling at $N=10^3$ is $9.26$ bit, **below the threshold**, so at that sample size the gate would never trigger. To reach 9.97 bit one needs at least $N\approx2^{10}$ with an expected count of the rarest categories of $\gtrsim10$, i.e. $N\sim10^4$.

The fix is R-5. **Note that this item involves no dynamics of SRVD**: it constrains the RIF reading protocol, and applies wherever a $-S\log S$-type estimator is used for rarity reporting.

---

## 8  Disclosure of protocol deviations

The entire value of preregistration lies in "not changing the criteria after seeing the results". Five changes were made during execution; all are listed so readers can discount accordingly:

| ID | Change | When | Impact |
| :-: | :-- | :-- | :-- |
| **P-1** | Final reading for A5: the integration time of the critical cell ($g_0=\delta$) was enlarged from $t=200$ to $1.2(V_0/10^{-3}-1)/(g_0V_0)$ | After seeing the 25/28 agreement rate | The critical cell decays algebraically, so no finite $t$ reaches $10^{-3}$. After enlarging, 28/28. **Without the enlargement A5 would have been misjudged as a failure**, so this is a defect in the criterion wording, not in the theory |
| **P-2** | Added a commons term to the M4 world ($R$ depleted by total effort) | After the first version produced "all survive" | The preregistered verdict uses only the three cells with commons intensity $=0$; the other nine cells and the envelope check are all labelled "post hoc" |
| **P-3** | The M4 grid was changed from (I₀/R × cost coefficient) 4×5 to (I₀ × commons intensity) 3×4 | Same as above | In the original grid the two axes were collinear (cost coefficient and R move together). The change makes M4 "undecidable" rather than "pass" |
| **P-4** | Repetitions per cell for M5 reduced from 2000 to 500 | Runtime | Affects only precision near $5\%$ ($\pm2\%$); the $100\%$ and $67.6\%$ at the conclusions are unaffected |
| **P-5** | M6's "rarest 10%" defined by true-value quantiles; deviations counted only over observed categories | After the first run | This convention is itself part of the finding: unobserved categories have no reading under the plugin estimator, which is precisely the source of the deviation |

**Self-assessment**: P-2 and P-3 downgrade M4 from a "preregistered test" to an "exploratory observation"; this is the weakest link in the patch. The two conclusions of M4 (the second-order nature of the envelope, $V^{\text{exit}}=I_0/E$) do not depend on simulation and can be checked independently, so R-3 still stands, but its evidence grade should be recorded as "analytic derivation + non-preregistered numerical example".

---

## 9  What this report cannot prove

- **It cannot prove SRVD true.** All of M1 passing shows only that 8 formulas were not miscomputed; a completely wrong physical setting can have perfectly self-consistent mathematics.
- **It cannot prove SRVD false.** C1, B2, E1, and F1 all point at the **text and the protocol**; none points at "the world is not like this". A genuine falsification requires running H1—H10 of Appendix C on real systems.
- **It cannot decide for the author how many items to merge.** R-1, R-4, and R-5 are "written but unachievable / written wrongly"; the fix is unique and merging is recommended; R-2 is "missing a necessary condition", and merging it adds a new symbol $m$, so the author must judge whether it is worth it; R-3 requires accepting a premise, which is a substantive trade-off.
- **It cannot replace review.** The code is an implementation of the criteria, not the criteria themselves; if a reader believes a criterion is itself misstated, change `01` and rerun first — do not bend the code to fit.

---

*Figures: `figure/fig_m2_epsrel.png` (two-direction deviations of $\varepsilon_{\mathrm{rel}}$), `fig_m3_chain.png` ($\Delta^{*}$ falls with $\chi$; $m^{*}=1$), `fig_m4_envelope.png` (second-order loss), `fig_m5_fpr.png` (false-positive rate), `fig_m6_rarity.png` ($\log_2N$ ceiling).*
